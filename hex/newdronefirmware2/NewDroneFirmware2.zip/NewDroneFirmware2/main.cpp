#include <math.h>
#include <stdio.h>
#include <string.h>

#include "stm32g4xx.h"

#include "gpio.h"
#include "led.h"
#include "tim.h"
#include "tick.h"
#include "i2c.h"
#include "uart.h"
#include "spi.h"
#include "pwm.h"
#include "flash.h"
#include "adc.h"

#include "imu.h"
#include "bar.h"
#include "tof.h"
#include "flow.h"
#include "gps.h"
#include "mag.h"
#include "eep.h"

#include "sbus.h"

#include "INS/IRS.h"

#include "INS/device/GPS.h"
#include "INS/device/Barometer.h"
#include "INS/device/Range.h"
#include "INS/device/OpticalFlow.h"
#include "INS/device/Compass.h"

#include "INS/cont/Attitude.h"
#include "INS/cont/Velocity.h"
#include "INS/cont/Engine.h"

#include "Autopilot.h"
#include "Settings.h"

#define LED_TIMER 100 // ms

constexpr long TIM_PRIORITY=2;

static bool BLINK_LED = true;

IMU_Data DataIMU;
BAR_Data DataBAR;
MAG_Data DataMAG;

struct GPS_Data
{
  bool Init;
  bool Valid;
  float X, Y, Z;
  float AbsAlt;
  Point Zero;
  
  bool Update;
};

struct TOF_Data
{
  bool Valid;
  float Alpha;
  float Range;
  float Strength;
  
  bool Update;
};

struct FLOW_Data
{
  bool Valid;
  float Quality;
  Vector2 OF;
  
  bool Update;
};

FLOW_Data DataFLOW;
TOF_Data DataTOF;
GPS_Data DataGPS;

IRS MainIRS;

GPS MainGPS(MainIRS.RecordPosit, MainIRS.RecordSpeed);
Barometer MainBar(MainIRS.RecordPosit, MainIRS.RecordSpeed, MainIRS.RecordQuat);
Range MainLen(MainIRS.RecordPosit, MainIRS.RecordSpeed, MainIRS.RecordQuat);
OpticalFlow MainOF(MainIRS.RecordGyro, MainIRS.RecordSpeed, MainIRS.RecordPosit, MainIRS.RecordQuat);
//Compass MainCompas(MainOF.RecordOF, MainIRS.RecordGyro, MainIRS.RecordQuat);

Attitude MainAtt;
Velocity MainVel(MainIRS.OriQuat);
Engine MainEng(MainIRS.OriPRT);

SBUS_Data Joypad;
bool MainActive=false;
float BAT_VAL;

unsigned long TimeManualActive = 0;

ButterworthCascadeFilter ButterBaroFilt(IRS::Freq);

float GetCurrentTime()
{
  return ((float)TICK_GetCount())/1000.0f;
}

void UpdateRange(float range, bool Valid) // Приоритет 4
{
  //return;
  
  static float alpha_range=1.0f;
  
  if (!Valid)
  {
    MainLen.SetRange(0);
    
    MainIRS.SetGroundHeight(nullptr, MainLen.MaxHeight, 0.001f);
    
    alpha_range=1.0f;
    
    return;
  }
  
  static float filt_range=0;
  
  filt_range=filt_range*(1.0f-alpha_range) + range*alpha_range;
  
  alpha_range-=0.01;
  if (alpha_range < 0.1f) alpha_range = 0.1f;
  
  float len = MainLen.SetRange(&filt_range);
  
  if (len>0) MainIRS.SetGroundHeight(&len, MainLen.MaxHeight, 0.01f);
  else MainIRS.SetGroundHeight(nullptr, MainLen.MaxHeight, 0.001f);
  
  float pos, spd;
  if (MainLen.GetShift(pos, spd))
  {
    MainIRS.UpdatePositionSpeed({ 0.0f, 0.0f, pos }, { 0.0f, 0.0f, spd });
  }
}

void UpdateFlow(Vector2& of, float range, bool valid, float alpha) // Приоритет 3
{
  //return;
  
  if(!valid || USE_GPS)
  {
    MainOF.SetMove(0, 0, 0);
    return;
  }
  
  MainOF.SetMove(&of, range, alpha);
  
  //MainCompas.UpdateAverageOF();
  
  Vector2 pos, spd;
  if (MainOF.GetShift(pos, spd))
  {
    //if (DataGPS.Valid || !ExternalGPSOff) pos = {0.0f, 0.0f};
    MainIRS.UpdatePositionSpeed(pos, spd);
  }
}

void UpdateBar(float pressure, float temp, bool Valid)  // Приоритет 2
{  
  //return;
  
  if(!Valid) 
  {
    MainBar.SetPressure(0, 0);
    return;
  }
  
  
  pressure = ButterBaroFilt.process(pressure);
  pressure = BaroFilt.update2(pressure);
  
  MainBar.SetPressure(&pressure, &temp);
 
  float pos, spd;
  if (MainBar.GetShift(pos, spd))
  {
    MainIRS.UpdatePositionSpeed({ 0.0f, 0.0f, pos }, { 0.0f, 0.0f, spd });
  }
}

void UpdateGPS(Vector3& local, float time, bool Valid)  // Приоритет 1
{
  //return;
  if((!Valid) || ExternalGPSOff)
  {
    MainGPS.SetPosition(0, time);
    //ShiftGPS.Active = false; // инидикатор ЖПС фе для протокола (можно на что-то другое заменить)
    return;
  }
  
  MainGPS.SetPosition(&local, time);
  MainBar.UpdateZeroHeight(local.Z, 0.01f);
  
  Vector3 pos, spd;
  if (MainGPS.GetShift(pos, spd))
  {
    MainIRS.UpdatePositionSpeed(pos, spd);
  }
  
  //Vector3 crs;
  //MainGPS.GetPositionSpeed(nullptr, &crs);
  //MainCompas.SetCourseGPS(crs, time);
  //ShiftGPS.Active = true; // индикатор ЖПС ок для протокола (можно на что-то другое заменить)
}

void AutoControl(Vector3 gyro)
{
  Vector3 pos, spd, acc; float gnd;
  MainIRS.GetInertial(&pos, &spd, &acc, &gnd);
  MainVel.UpdateMoveSpeed(pos, spd, acc, gnd);
  
  MainAtt.UpdateRegPRY(MainIRS.OriQuat, gyro);
  
  float thr_JOY = ((float)Joypad.Z)/2000.0f;
  
  float fly;
  
  static float joy_yaw;
  
  Vector3 pry;
  MainIRS.GetPitchRollYaw(pry);
  
  if (MainDrone.engine == ENGINE_STATUS::disable)
  {
    CalibDataIMU.AllowedCalib = true;
    BLINK_LED = true;
    MainIRS.Inertial.Pos = 0;
    MainIRS.Inertial.Spd = 0;
    PWM_SetAll(900);
    MainDrone.MainActive = false;
    joy_yaw=pry.Z;
    DroneNullPoint.saved = 0;
    return;
  }
  
  CalibDataIMU.AllowedCalib = false;
  
  if (((thr_JOY < 0.01f) || !MainDrone.MainActive ) && MainDrone.ManualInputAllowed)
  {
    PWM_SetAll(1050);
    joy_yaw=pry.Z;
    BLINK_LED = true;
    if (!MainDrone.AutoPilotActive)
    {
      if (TimeManualActive == 0) TimeManualActive = TICK_GetCount();
      if (TICK_GetCount() - TimeManualActive > 3000)
      {
        MainDrone.MainActive = false;
        MainDrone.engine = ENGINE_STATUS::disable;
        TimeManualActive = 0;
      }
    }
    return;
  }
  
  TimeManualActive = 0;
  
  BLINK_LED = false;
  
  if (!MainDrone.AutoPilotActive)
  {
    LED_Set(true);
    MainDrone.AltChangeAllowed = false;
    bool spd = false;
    
    joy_yaw-=(float)(Joypad.W - JOY_MID)/440.0f;
    
    
    Vector3 pry = { (float)(JOY_MID - Joypad.Y)/22.0f, (float)(Joypad.X - JOY_MID)/22.0f, joy_yaw};
    pry /= 57.2957795f;
    Quaternion q_pry = Quaternion::CreateYawPitchRoll(pry);
    
    MainAtt.SetAnglePRY(&thr_JOY, &q_pry, &spd);
    fly = 0.0f;
    
    // Тест зависания;
    {
      DroneGoal.Position = pos;
      if (MainVel.GroundMode) DroneGoal.Position.Z = MainIRS.Inertial.Pos.Z - MainIRS.GroundShift;
      DroneGoal.Speed = 1.0f;
      DroneGoal.New = true;
      DroneGoal.Yaw = true;
      DroneGoal.PRY.Z = pry.Z;
    }

  }
  else
  {
    LED_Set(false);
    
    float newY = (float)(Joypad.Y - JOY_MID)/100000.0f;
    float newX = (float)(Joypad.X - JOY_MID)/100000.0f;
    float newZ = 0.0f;
    
    //if (fabs(Joypad.Z - JOY_MID) < 450) MainDrone.AltChangeAllowed = true;
    //if(fabs(Joypad.Z - JOY_MID) > 500) newZ = (float)(Joypad.Z - JOY_MID)/100000.0f;
    if (((newY != 0.0f) || (newX != 0.0f) || ((newZ != 0.0f) && MainDrone.AltChangeAllowed)) && MainDrone.ManualInputAllowed)
    {
      if (MainDrone.Mode != SYS_MODE::hold)
      {
        MainDrone.Mode = SYS_MODE::hold;
        DroneGoal.Position = pos;
      }
      DroneGoal.Position.Y += newY;
      DroneGoal.Position.X += newX;
      DroneGoal.Position.Z += newZ;
      DroneGoal.New = true;
    }
   
   float yaw = DroneGoal.PRY.Z;
   MainVel.SetManualYaw(DroneGoal.Yaw,&yaw);
   if(DroneGoal.New)
   {
     Vector3* PointBegin = nullptr;
     if (MainDrone.PointBeginNeed)
     {
       PointBegin = &DroneInertial.Pos;
       MainDrone.PointBeginNeed = false;
     }
     MainVel.SetDistanceSpeed(PointBegin, &DroneGoal.Position, &DroneGoal.Speed);
     DroneGoal.New = false; // Не задавать если уже получена !!!!!!!!!!!!!!!!!
   }
   else MainVel.SetDistanceSpeed(nullptr, nullptr, &DroneGoal.Speed);
   
   bool s = false;
   float throt;
   Quaternion q_pry;
   MainVel.GetThrotAnglePRY(throt, q_pry);
   MainAtt.SetAnglePRY(&throt, &q_pry, &s);
   fly = 0.25f;
   
   if (DroneGoal.Stop)
   {
     DroneGoal.Stop = false;
      MainVel.Stop(nullptr);
   }
   Vector3 pos, spd, acc; float gnd;
   MainIRS.GetInertial(&pos, &spd, &acc, &gnd);
   MainVel.UpdateMoveSpeed(pos, spd, acc, gnd);
  }
  
  float throt;
  Vector3 pow;
  MainAtt.GetPowerPRY(&throt, &pow);
  MainEng.SetPowerPRY(pow, throt + fly);
  
  float thrust[4];
  MainEng.GetQuadX(thrust);
  
  float motor[4] = { thrust[Engine::QuadSchemeX[0]], thrust[Engine::QuadSchemeX[1]], thrust[Engine::QuadSchemeX[2]], thrust[Engine::QuadSchemeX[3]] };
  
  short power[4] = { (short)(motor[0]*1000.0f), (short)(motor[1]*1000.0f), (short)(motor[2]*1000.0f), (short)(motor[3]*1000.0f) };
  
  
  //power[0]=power[1]=power[2]=power[3]=Joypad.Z/2;
  
  static short testPower[4];
  testPower[0] = power[0];
  testPower[1] = power[1];
  testPower[2] = power[2];
  testPower[3] = power[3];
  
  //PWM_SetQuad(power, 1100, 2000);
}

float GPSNoiz = 0;
float GPSNoizPast = 0.1f;
unsigned long GPSNoizTime = 3000;
float GPSNoizDelta = 15.0f;

struct StructNoiseGPS
{
  static constexpr float Freq = 100;
  static constexpr float Past = 0.5f; // Максимальная запись прошлых данных
  static constexpr unsigned long Count = Freq * Past + 1;
  float Buffer[Count];
  Record<float> Rec;
} NoiseGPS;

void ReadStateINS()
{
  static Vector3 pry;
  MainIRS.GetPitchRollYaw(pry);
  DroneOrintation.PRY = pry;
  
  static Vector3 iner_acc, iner_spd, iner_pos;
  MainIRS.GetInertial(&iner_pos, &iner_spd, &iner_acc, nullptr);
  
  static GPS_BaseInfo gpsInfo;
  bool gps_valid = DataGPS.Valid;
  GPS_GetBaseInfo(gpsInfo);
  
  NoiseGPS.Rec.Add(gpsInfo.noise);
  //GPSNoiz = fabsf(gpsInfo.noise-NoiseGPS.Rec.Past(GPSNoizPast));
  GPSNoiz = gpsInfo.noise;
  
  //DroneOrintation.Iner = acc;
  DroneInertial.Spd = iner_spd;
  DroneInertial.Acc = iner_acc;
  DroneInertial.Pos = iner_pos;
  
  float current_A = 0.0f;
  //
  { //SYS INFO
    ProtoDataSysInfo sys;
    sys.engineCount = sizeof(MainEng.QuadSchemeX); //
    sys.pressureBaro = MainBar.Bar;
    sys.tempBaro = MainBar.Temp;

    //
    sys.engineStatus = MainDrone.engine;
    
    float thrust[sizeof(MainEng.QuadSchemeX)];
    MainEng.GetQuadX(thrust);
    
    float AvgEngineThrust = 0.0f;
    for (int i = 0; i < sys.engineCount; i++)
    {
      EnginePowerInfo eng;
      eng.current = thrust[Engine::QuadSchemeX[i]] * 20.0f;
      AvgEngineThrust += thrust[Engine::QuadSchemeX[i]];
      eng.engineSpeed = thrust[Engine::QuadSchemeX[i]] * 1000;
      eng.power = eng.engineSpeed / 10;
      eng.temp = 65.0f;
      eng.voltage = BAT_VAL;
      sys.enginePower[i] = eng;
      current_A += thrust[Engine::QuadSchemeX[i]] * thrust[Engine::QuadSchemeX[i]] * 20.0f;
    }
    ProtoDataWriteReadSysInfo(sys, false);
    
    if (AvgEngineThrust > 0.0f) MainDrone.AvgEngineThrust = AvgEngineThrust / sizeof(MainEng.QuadSchemeX);
    else MainDrone.AvgEngineThrust = 0.0f;
  }

  { //Battery
    static float MAX_POWER;
    static float onePerVal = 100.0f/(BAT_MAX_VAL-BAT_MIN_VAL);
    
    MAX_POWER = ((float)BAT_CONS / 1000.f) * BAT_VAL;
    
    ProtoDataBattery bat;
    bat.voltage = BAT_VAL;
    bat.amperage = 0.5f + current_A;
    bat.perCharge = 0;
    if (bat.voltage > 1e-12f)
    {
      if (bat.voltage < BAT_MIN_VAL) bat.perCharge = 0;
      else bat.perCharge = onePerVal*(bat.voltage - BAT_MIN_VAL);
    }
    
    //bat.perCharge = 90;
    
    bat.temp = 36.6f;
    bat.totalPower = bat.amperage * bat.voltage;
    //if (bat.totalPower > 1e-12f) bat.timeRemaining = (unsigned long long)((MAX_POWER/bat.totalPower) * 3600);
    //else bat.timeRemaining  = 0;
    bat.timeRemaining = (unsigned long long)((BAT_CONS/(bat.amperage * 1000.0f)) * 0.7f * 3600);
    //-------------------------------------------------------------------------------
    ProtoDataWriteReadBattery(bat, false);
  }

  { // GYR
    ProtoDataGyroInfo gyr;
    gyr.pitchGyroVel = DataMAG.RawX; //
    gyr.rollGyroVel = DataMAG.RawY; //
    gyr.yawGyroVel = DataMAG.RawZ; //
    ProtoDataWriteReadGyroInfo(gyr, false);
  }

  { // ACC
    ProtoDataAccelInfo acc;
    acc.aX = DroneInertial.Acc.X;//DataIMU.RawGyr.X;
    acc.aY = DroneInertial.Acc.Y;//DataIMU.RawGyr.Y;
    acc.aZ = DroneInertial.Acc.Z;//DataIMU.RawGyr.Z;
    acc.pitchAccelVel = DataIMU.RawAcc.X; //
    acc.rollAccelVel = DataIMU.RawAcc.Y; //
    acc.yawAccelVel = DataIMU.RawAcc.Z; //
    acc.tempAccel = 34.5f; //
    ProtoDataWriteReadAccelInfo(acc, false);
  }
  
  { // GPS
    ProtoDataGpsInfo gps;
    float lat, lon, alt, r_alt;
    
    if (gps_valid)
    {
      lat = gpsInfo.lat;
      lon = gpsInfo.lon;
      alt = gpsInfo.absAlt;
      r_alt = DataGPS.Z;
    }
    else
    {
      lat = 0.0f;
      lon = 0.0f;
      alt = 0.0f;
      r_alt = 0.0f;
    }
    gps.lat = lat;
    gps.lon = lon;
    gps.absAlt = alt;
    gps.realAlt = r_alt;
    gps.hdop = gpsInfo.hdop;
    gps.vdop = gpsInfo.vdop;
    gps.pdop = gpsInfo.pdop;
    gps.jamming = gpsInfo.jamming; // jamming indicator ublox.
    gps.noise = gpsInfo.noise;
    gps.satVisible = gpsInfo.satVisible;
    gps.satUsed = gpsInfo.satUsed;
    gps.speed = gpsInfo.speed;
    gps.fixType = gpsInfo.fixType;
    gps.timeUTC = gpsInfo.timeUTC;
    ProtoDataWriteReadGpsInfo(gps, false);
  }

  {// INNER
    ProtoDataInertialInfo inner;
    inner.x = DroneInertial.Pos.X;
    inner.y = DroneInertial.Pos.Y;
    inner.z = DroneInertial.Pos.Z;
    inner.baroAlt = MainBar.LastPos;
    inner.pitch = DroneOrintation.PRY.X;
    inner.roll = DroneOrintation.PRY.Y;
    inner.yaw = DroneOrintation.PRY.Z;
    inner.headingDeg = DroneOrintation.PRY.Z;
    //inner.speed = sqrtf(DroneInertial.Spd.X * DroneInertial.Spd.X + DroneInertial.Spd.Y * DroneInertial.Spd.Y);
    
    inner.speed = MainVel.XY_TEST.Y;//DroneInertial.Spd.Z;

    inner.pitchVel = MainOF.TESTS_XY_OF.X;//DroneInertial.Spd.X;//MainVel.PointBegin.X;//PointLand.X; //MainBar.RegShift.Test;
    
    inner.yawVel = MainOF.TESTS_XY_OF.Z;//DataGPS.Z;// / MainOF.RegShift.Accuracy;//MainIRS.Inertial.Spd.Z;//DroneInertial.Spd.Y;
    inner.rollVel = MainOF.TESTS_XY_OF.Y;//DroneInertial.Spd.Y;//MainVel.PointBegin.Y;//PointLand.Y; //DataGPS.X;//MainGPS.Shift.Dyn.Y / MainGPS.RegShift.Accuracy;//
    
    
    ProtoDataWriteReadInertialInfo(inner, false);
  }
  
  if(MainDrone.NeedSendRawCalibData)
  {// Raw calibration data
    ProtoDataRawCalib calibData;
    switch (MainDrone.Sensor)
    {
      case SENSOR_ID::ACC:
      {
        calibData.X = DataIMU.RawAcc.X;
        calibData.Y = DataIMU.RawAcc.Y;
        calibData.Z = DataIMU.RawAcc.Z;
        break;
      }
      case SENSOR_ID::IMU_MAG:
      {
        calibData.X = DataIMU.RawMag.X;
        calibData.Y = DataIMU.RawMag.Y;
        calibData.Z = DataIMU.RawMag.Z;
        break;
      }
      case SENSOR_ID::EXTERNAL_MAG:
      {
        calibData.X = DataMAG.RawX;
        calibData.Y = DataMAG.RawY;
        calibData.Z = DataMAG.RawZ;
        break;
      }
      case SENSOR_ID::LEVEL_HOR:
      {
        calibData.X = DroneOrintation.PRY.X;
        calibData.Y = DroneOrintation.PRY.Y;
        calibData.Z = DroneOrintation.PRY.Z;
        break;
      }
    }
    ProtoDataWriteReadRawCalib(calibData, false);
  }
  
  // Проверка надо ли калибровать датчики
  //if (!MainDrone.MainActive)
  //{
    //acc
    //if (CalibDataIMU.Data.Mag.
  //}
}

void DoneProcIMU(IMU_Data& Data)
{
  DataIMU = Data;
}

void DoneProcBAR(bool Ready, BAR_Data& Data)
{
  if(Ready) DataBAR=Data;
}

bool MagReady=false;

void DoneProcMag(MAG_Data& Data)
{
  DataMAG = Data;
  MagReady=true;
}

void TimerUpdateSensor()
{
  IMU_GetAsunc(DoneProcIMU);
  BAR_GetAsunc(DoneProcBAR);
  //MAG_GetAsunc(DoneProcMag);
}

void TimerUpdateMain()
{
  float time = GetCurrentTime();
  
  Vector3 gyr = {(float)DataIMU.Gyr.X, (float)DataIMU.Gyr.Y, (float)DataIMU.Gyr.Z};
  Vector3 acc = {(float)DataIMU.Acc.X, (float)DataIMU.Acc.Y, (float)DataIMU.Acc.Z};
  //Vector3 mag = {(float)DataIMU.Mag.X, (float)DataIMU.Mag.Y, (float)DataIMU.Mag.Z};
  Vector3 mag = {(float)DataMAG.X, (float)DataMAG.Y, (float)DataMAG.Z};
  
  MainIRS.UpdateGyro(gyr);
  MainIRS.UpdateAccel(acc);
  if(MagReady)
  {
    MagReady=false;
    MainIRS.UpdateMagnet(mag);
  }
  
  MainGPS.UpdateAverage(time);
  MainBar.UpdateAverage();
  MainOF.UpdateAverage(IRS::Period);
  MainLen.UpdateAverage();
  
  if(DataFLOW.Update)
  {
    DataFLOW.Update=false;
    UpdateFlow(DataFLOW.OF, MainIRS.Inertial.Pos.Z - MainIRS.GroundShift, DataFLOW.Valid, DataFLOW.Quality);
  }
  
  if(DataTOF.Update)
  {
    DataTOF.Update=false;
    UpdateRange(DataTOF.Range, DataTOF.Valid && DataTOF.Range>0.05f && DataTOF.Strength>200.0f);
  }
  
  UpdateBar(DataBAR.Pressure, DataBAR.Temp, DataBAR.Pressure>0.0f);
  
  if(DataGPS.Update)
  {
    DataGPS.Update=false;
    Vector3 gps = { DataGPS.X, DataGPS.Y, DataGPS.Z };
    UpdateGPS(gps, time, DataGPS.Valid);
  }
  
  Vector3 pos;
  MainIRS.RestoreAllShift(pos);
  
  AutoControl(gyr);
  
  ReadStateINS();
  
  //MAG_GetAsunc(DoneProcMag);
}

void TimerUpdateOptics()
{
  { // Range
    float range, strength;
    DataTOF.Valid = TOF_GetRange(range, strength);
    DataTOF.Range = range;
    DataTOF.Strength=strength;
    DataTOF.Alpha = 1.0f;
    DataTOF.Update = true;
  }
  
  { // Flow
    short dx, dy;
    unsigned char quality;
    bool done = FLOW_GetMotion(dx, dy, quality);
    DataFLOW.OF = {(float)dx, (float)dy};
    
    const float min = 20;
    DataFLOW.Valid = quality>min && done;
    DataFLOW.Quality = ((float)quality)/255.0f; // Качество поверхности
    DataFLOW.Update=true;
  }
}

void InitPDI()
{
  // Они плохо настроены, но летает и можно тестить остальное

  //                      Period     Limit    P      D       IL    IP    ID    Lock I
  MainAtt.RegAngleP = { IRS::Period, 0.50f, 0.5f, 0.0006f, { 0.0f, 0.0f, 0.0f }, true };
  MainAtt.RegAngleR = { IRS::Period, 0.50f, 0.5f, 0.0006f, { 0.0f, 0.0f, 0.0f }, true };
  MainAtt.RegAngleY = { IRS::Period, 1.00f, 1.0f, 0.002f, { 0.0f, 0.0f, 0.0f }, true };
                                                                                      
  MainAtt.RegSpeedP = { IRS::Period, 0.50f, 0.005f};
  MainAtt.RegSpeedR = { IRS::Period, 0.50f, 0.005f};
  MainAtt.RegSpeedY = { IRS::Period, 1.00f, 0.01f};
                                                                                                                                           
  MainVel.RegSpeedX = { IRS::Period, 0.50f, 0.4f,  0.02625f};
  MainVel.RegSpeedY = { IRS::Period, 0.50f, 0.4f,  0.02625f};
  MainVel.RegSpeedT = { IRS::Period, 0.50f, 0.4f,  0.05f};
  
  
  // GPS              Restore    Accuracy    Power
  MainGPS.RegShift = { 30.0f,      2.0f,     4.0f };
  //                 Alpha    Power   Dynamic,   Distance
  MainGPS.RegSpd = { 0.3f,    2.0f,   0.1f,      10.0f };
  MainGPS.RegPos = { 0.3f,    2.0f,   0.1f,      10.0f };
  MainGPS.AlphaHeight = 0.1;
  

  // OF               Restore    Accuracy    Power
  MainOF.RegShift = { 30.0f,      1.0f,     2.0f };
  //                Alpha       Power      Dynamic,   Distance
  MainOF.RegSpd = { 0.5f,       2.0f,      0.25f,      2.0f };
  
  
  // BAR              Restore    Accuracy    Power
  MainBar.RegShift = { 1.0f,       0.1f,      2.0f };
  //                 Alpha    Power    Dynamic,   Distance
  MainBar.RegSpd = { 0.1f,    2.0f,     0.001f,      2.0f };
  MainBar.RegPos = { 0.1f,    2.0f,     0.001f,      2.0f };
  
               
  // ToF              Restore    Accuracy    Power
  MainLen.RegShift = { 10.0f,       0.5f,      2.0f };
  //                 Alpha    Power    Dynamic,   Distance
  MainLen.RegSpd = { 0.1f,    2.0f,     0.02f,      2.0f };
}

void MEM_Save() // Записать всё во флеш 
{
  FLASH_Erase(63);
  
  unsigned char* mem = (unsigned char*)0x0801F800UL;
  
  unsigned long count=sizeof(Settings::MenuParameters)/sizeof(ParameterData*);
  bool FirstBytes = true;
  for(int a=0; a<count; a++)
  {
    const unsigned long max = 512;
    unsigned char buffer[max];
    unsigned long len = 0;
    
    if (FirstBytes) //Харним во флеше CRC дерева параметров
    {
      unsigned short crc = sizeof(Settings::MenuPIDParameters) + sizeof(Settings::MenuEngineParameters) + sizeof(Settings::MenuAutoPilotParameters) + sizeof(Settings::MenuSensorsParameters);
      memcpy(buffer, &crc, 2);
      len = 2;
      FirstBytes = false;
    }
    
    int sub=Settings::MenuParametersCount[a];
    for(int b=0; b<sub; b++)
    {
      const ParameterData& param = Settings::MenuParameters[a][b];
      
      unsigned long size=Settings::GetTypeSize(param.type);
      
      if(size) memcpy(buffer+len, param.value, size);
      len+=size;
    }
    
    if(len) 
    {
      FLASH_Write((unsigned long)mem, buffer, len);
      if(len & 7) len=(len & ~7)+8;
      mem+=len;
    }
  }
  MainDrone.FLASHSaved = true;
}

void MEM_Restore() // Восстановить всё из флеша
{
  unsigned char* mem = (unsigned char*)0x0801F800UL;
  
  unsigned long count=sizeof(Settings::MenuParameters)/sizeof(ParameterData*);
  
  bool FirstBytes = true;
  unsigned short crc = sizeof(Settings::MenuPIDParameters) + sizeof(Settings::MenuEngineParameters) + sizeof(Settings::MenuAutoPilotParameters) + sizeof(Settings::MenuSensorsParameters);
  unsigned short crs_in_mem = 0;
  memcpy(&crs_in_mem, mem, 2);
  
  if(crs_in_mem != crc) MEM_Save(); //Проверяем CRC дерева параметров
  
  for(int a=0; a<count; a++)
  {
    unsigned long len = 0;
    
    if(FirstBytes)
    {
      len = 2;
      FirstBytes = false;
    }
    
    int sub=Settings::MenuParametersCount[a];
    for(int b=0; b<sub; b++)
    {
      const ParameterData& param = Settings::MenuParameters[a][b];
      
      unsigned long size=Settings::GetTypeSize(param.type);
      
      if(size) memcpy(param.value, mem+len, size);
      len+=size;
    }
    
    if(len) 
    {
      if(len & 7) len=(len & ~7)+8;
      mem+=len;
    }
  }
}

void DoneProcEEPROM(bool Ready, EEP_Data& Data)
{
  if(Ready)
  {
    // есть чтение
    CalibDataIMU.Data = *(XYZ_IMU_DATA*)(Data.Data);
    if (CalibDataIMU.Data.Writed != sizeof(XYZ_IMU_DATA)) CalibDataIMU.CalibNeed = true;
  }
  else
  {
    MainDrone.EEPROMSaved = true;
    // была запись
  }
}

void EEPROM_Save() // Пример сохранения
{
  CalibDataIMU.Data.Writed = sizeof(XYZ_IMU_DATA);
  EEP_SetAsunc(0, &CalibDataIMU.Data, sizeof(XYZ_IMU_DATA), DoneProcEEPROM);
}

void EEPROM_Restore() // Пример чтения
{
  EEP_GetAsunc(0, sizeof(XYZ_IMU_DATA), DoneProcEEPROM);
}

extern "C" void SystemClock_Config();

int main()
{
  SystemClock_Config(); // 170MHz

  //MEM_Restore();
  MainIRS.SetAccelShift(LevelHor.Pitch, LevelHor.Roll, 0.0f);
  
  InitPDI();
  
  PWM_Init(100); // 100Hz
  PWM_SetAll(900);
  
  GPIO_InitPin(GPIO_PIN_13 | GPIO_PORT_C | GPIO_OUTPUT | GPIO_SET); // POWER ON 3V3 (nPC13)
  for (volatile int i = 0; i < 1000000; i ++) {};
  GPIOC->BSRR = GPIO_BSRR_BR13;
  for (volatile int i = 0; i < 1000000; i ++) {};

  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CYCCNT = 0;
  DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
  
  TICK_Init();
  
  TIM6_Init(TIM_PRIORITY, 500, TimerUpdateSensor, TimerUpdateMain);
  TIM7_Init(TIM_PRIORITY, OpticalFlow::Freq, TimerUpdateOptics);
  
  IMU_Init();
  BAR_Init();
  TOF_Init();
  FLOW_Init();
  GPS_Init();
  //MAG_Init();
  ADC_Init();
  LED_Init();
  SBUS_Init();
  EEP_Init();
  
  UART2_Init(115200); // Autopilot
  //LPUART1_Init(115200); // Autopilot
  
  EEPROM_Restore();
  
  TIM6_Enable();
  TIM7_Enable();
  
  InitAuto();
 
  while(true)
  {
    const unsigned long tick=TICK_GetCount();

    BAT_VAL = (float)(ADC_GetVolt() / 1000.0f); // Смотрим напряжение аккума (V)
    
    SBUS_Update(Joypad);
    
    TOF_Update2();
    
    if(GPS_Update())
    {
      //DroneNullPoint.X=47.32223892211914;
      //DroneNullPoint.Y=38.76748275756836;
      //DataGPS.Zero=gps_p;
      //DataGPS.Zero.Latitude=47.32223892211914;
      //DataGPS.Zero.Longitude=38.76748275756836;
      //DataGPS.Zero.Altitude=0;
      
      
      bool valid;
      Point gps_p;
      static float www_dx=0, www_dy=0, www_dz=0;
      if(GPS_GetCoordinates(gps_p, valid))
      {
        //valid=true;
        
        if(valid)
        {
          if(!DroneNullPoint.saved) 
          {
            DroneNullPoint = {true, gps_p.Latitude, gps_p.Longitude, gps_p.Altitude}; // потом оптимизировать (две точки)
            DataGPS.Zero=gps_p;
          }
          GPS_LocalDistance(DataGPS.Zero, gps_p, www_dx, www_dy, www_dz);
          DataGPS.X=-www_dx;
          DataGPS.Y=-www_dy;
          DataGPS.Z=-www_dz;
          if (DataGPS.Z < 0.0f)
          {
            DroneNullPoint.Z = gps_p.Altitude;
            DataGPS.Zero.Altitude = gps_p.Altitude;
            DataGPS.Z = 0.0f;
          }
          DataGPS.AbsAlt=gps_p.Altitude;
        }
        
        static unsigned long timer_noiz=0;
        static bool fixed_noiz = false;
        
        if(fixed_noiz)
        {
          if(TICK_GetCount()>timer_noiz+GPSNoizTime) fixed_noiz=false;
        }
        
        if(GPSNoiz<GPSNoizDelta || fixed_noiz) 
        {
          valid = false;
          if (GPSNoiz<GPSNoizDelta) 
          {
            timer_noiz = TICK_GetCount();
            fixed_noiz = true;
          }
        }
        
        DataGPS.Valid=valid;
        DataGPS.Update=true;
        
        if (DataGPS.Valid && !ExternalGPSOff) USE_GPS = true;
        else USE_GPS = false;
      }
    }
    
    static unsigned long led_tick=0;
    static bool led=false;
    if ((tick-led_tick>LED_TIMER) && BLINK_LED)
    {
      led_tick=tick;
      LED_Set(led=!led);
      
    }
    // Сохранение новых калибровок
    if (MainDrone.NeedSaveNewEEPROMData)
    {
      EEPROM_Save();
      MainDrone.NeedSaveNewEEPROMData = false;
    }
    // Сохранение новых параметров
    if (MainDrone.NeedSaveNewFLASHData)
    {
      MEM_Save();
      MainDrone.NeedSaveNewFLASHData = false;
      MainIRS.SetAccelShift(LevelHor.Pitch, LevelHor.Roll, 0.0f);
    }
    
    //Логическая проверка стиков пульта
    //SWA - ARM
    if ((Joypad.LastSWA != Joypad.SWA) && MainDrone.ManualInputAllowed)
    {
      Joypad.LastSWA = Joypad.SWA;
      if (Joypad.SWA > JOY_MID)
      {
        //Вызов функции проверки можно ли включать моторы
        CheeckStartCondition();
      }
      else if ((Joypad.SWA < JOY_MID))
      {
        MainDrone.engine = ENGINE_STATUS::disable;
        // Вырубаем моторы
      }
    }
    
    //SWC - GPS OFF
    if ((Joypad.LastSWC != Joypad.SWC) && MainDrone.ManualInputAllowed)
    {
      Joypad.LastSWC = Joypad.SWC;
      if (Joypad.SWC > JOY_MID) ExternalGPSOff = true;
      else ExternalGPSOff = false;
    }
    if (!USE_GPS) 
    {
      MainVel.GroundMode = true;
      MainVel.GroundSpeed = CalcLandSpeed(DroneInertial.Pos.Z);
    }
    else
    {
      MainVel.GroundMode = false;
    }
    
    //SWD - Autopilot active
    if ((Joypad.LastSWD != Joypad.SWD) && MainDrone.ManualInputAllowed)
    {
      Joypad.LastSWD = Joypad.SWD;
      if (Joypad.SWD < JOY_MID) 
      { 
        MainDrone.Mode = SYS_MODE::manual;
        MainDrone.AutoPilotActive = false;
      }
      else 
      {
        if (MainDrone.Mode == SYS_MODE::manual) MainDrone.Mode = SYS_MODE::hold;
        MainDrone.AutoPilotActive = true;
      }
    }
    // Потеря доверия к пульту
    if (Joypad.FailSafe)
    {
      MainDrone.ManualInputAllowed = false;
    }
    //Восстановление доверия к пульту
    if (!Joypad.FailSafe && !MainDrone.ManualInputAllowed && Joypad.Active)
    {
      if (!MainDrone.MainActive)
      {
        MainDrone.ManualInputAllowed = true;
      }
      else
      {
        if ((Joypad.SWA > JOY_MID) && (fabs(Joypad.Z - JOY_MID) < 450.0f)) 
        {
          MainDrone.ManualInputAllowed = true;
        }
      }
    }
    // Автопосадка при потере пульта или при отключении GPS
    if ((Joypad.FailSafe /*|| ExternalGPSOff*/) && DroneGoal.Position.Z != APSettings.AltLand && MainDrone.MainActive)
    {
      DroneGoal.Position.Z = APSettings.AltLand;
      DroneGoal.New = true;
      PointLand = {DroneInertial.Pos.X, DroneInertial.Pos.Y};
      MainDrone.Mode = SYS_MODE::land;
      MainDrone.AutoPilotActive = true;
    }
    
    AutoThread();
    
    static long test_tick=0;
    test_tick++;
    
  }
}
//------------------------------------------------------------------------------
