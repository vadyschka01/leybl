﻿#include <math.h>

#include "IRS.h"

static constexpr float PI = 3.14159265359f;
static constexpr float TO_DEG = 180.0f / PI;
static constexpr float TO_RAD = PI / 180.0f;
static constexpr float G = 9.80665f; // m/c2

IRS::IRS():
  RecordGyro(RecGyr.Rec),
  RecordSpeed(RecSpd.Rec),
  RecordPosit(RecPos.Rec),
  RecordQuat(RecQua.Rec)
{
  RecordGyro.Init(RecGyr.Buffer, Freq, RecGyr.Past);
  RecordSpeed.Init(RecSpd.Buffer, Freq, RecSpd.Past);
  RecordPosit.Init(RecPos.Buffer, Freq, RecPos.Past);
  RecordQuat.Init(RecQua.Buffer, Freq, RecQua.Past);
}

void IRS::RestoreQuat(const Vector3& Acc)
{
  float len = sqrtf(Acc.X * Acc.X + Acc.Y * Acc.Y + Acc.Z * Acc.Z);

  Vector3 acc = Acc.Norm();

  Vector3 g{ 0, 0, 1 };
  Vector3 axis = g.Cross(acc);

  float w = 1 + (g.X * acc.X + g.Y * acc.Y + g.Z * acc.Z);

  Quaternion q = { -axis.X, -axis.Y, axis.Z, w };
  q = q.Norm();

  Quaternion yaw{ 0, 0, OriQuat.Z, OriQuat.W };
  yaw = yaw.Norm();

  Quaternion pry = yaw * q; // Востановить оборот по Z

  static float quat_acc_alpha = 0.03f;
  
  static float quat_acc_max = 0.02f;
  float dyn = fabsf(len - 1.0f);
  if(dyn>quat_acc_max) dyn=1.0f; else dyn/=quat_acc_max;

  float gain = quat_acc_alpha * (1.0f-dyn);

  if (pry.IsNAN()) return;

  float dot = OriQuat.X * pry.X + OriQuat.Y * pry.Y + OriQuat.Z * pry.Z + OriQuat.W * pry.W;

  if (dot < 0.0f)
  {
    pry.X = -pry.X;
    pry.Y = -pry.Y;
    pry.Z = -pry.Z;
    pry.W = -pry.W;
  }

  Quaternion r;
  OriQuat.X = (1.0f - gain) * OriQuat.X + gain * pry.X;
  OriQuat.Y = (1.0f - gain) * OriQuat.Y + gain * pry.Y;
  OriQuat.Z = (1.0f - gain) * OriQuat.Z + gain * pry.Z;
  OriQuat.W = (1.0f - gain) * OriQuat.W + gain * pry.W;

  OriQuat = OriQuat.Norm();
}

float IRS::GetAngle(float X, float Y, float Z)
{
  if (Y == 0.0f && Z == 0.0f)
  {
    if (X > 0.0f) return 90.0f;
    if (X < 0.0f) return -90.0f;
    return 0.0f;
  }

  return atanf(X / sqrtf(Y * Y + Z * Z)) * TO_DEG;
}

void IRS::UpdateGyro(const Vector3& Gyr)
{
  IMU.Gyr = Gyr;

  Vector3 gyr = Gyr * (Period * TO_RAD);

  RecordGyro.Add(Gyr * TO_RAD);

  Quaternion g = gyr;
  g = (OriQuat * g);

  OriQuat += g * 0.5f;
  OriQuat = OriQuat.Norm();

  RecordQuat.Add(OriQuat);

  OriPRT = OriQuat.Conjugate() * Quaternion(0, 0, 1, 0) * OriQuat;
}

void IRS::UpdateMagnet(const Vector3& Mag)
{
  IMU.Mag = Mag;
  
  Vector3 mag = Mag.Norm();
  
  Quaternion mW = OriQuat * mag * OriQuat.Conjugate();
  
  mW = ShiftNoth * mW;
  
  float alpha = fabsf(-mW.X);
  if (alpha>0.01f) alpha=0.01f;
  else if (alpha<0.0001f) alpha=0.0001f;
  
  float half_angle = (-mW.X) * alpha * 0.5f;
  
  Quaternion corr // Корректирующий кватернион с помощью аппроксимации малого угла.
  {
      0.0f,       // x
      0.0f,       // y
      half_angle, // z
      1.0f        // w
  };
  
  OriQuat = (corr * OriQuat).Norm();
}

void IRS::UpdateAccel(const Vector3& Acc)
{
  Vector3 accel = ShiftAccelPRY * Acc * ShiftAccelPRY.Conjugate();
  
  IMU.Acc = accel;

  Quaternion ine = OriQuat * accel * OriQuat.Conjugate();

  Vector3 acc = { ine.X, ine.Y, ine.Z - 1.0f }; // без гравитации
  
  Inertial.Acc = acc;//OriQuat.RotateAroundZ(acc, true);

  Inertial.Spd += acc * (G * Period); // интегрирование скорости
  
  Vector3 spd = Inertial.Spd * Period;
  
  Inertial.Pos += spd; // интегрирование позиции
  
  RecordSpeed.Add(Inertial.Spd);
  RecordPosit.Add(Inertial.Pos);

  RestoreQuat(accel);
}

void IRS::UpdatePositionSpeed(const Vector3& ShiftPosition, const Vector3& ShiftSpeed)
{
  Shift.Pos += ShiftPosition;
  Shift.Spd += ShiftSpeed;
}

void IRS::UpdateQuaternion(const Quaternion& ShiftQuaternion, float Alpha)
{
  Shift.Pos = Shift.Qua * (1.0f - Alpha) + ShiftQuaternion * Alpha;
}

void IRS::RestoreAllShift(Vector3& ShiftPos)
{
  Vector3 spd = Shift.Spd;
  Shift.Spd = 0;
  RecordSpeed.Mix(spd);
  Inertial.Spd += spd;

  Vector3 pos = Shift.Pos;
  Shift.Pos = 0;
  
  RecordPosit.Mix(pos);
  Inertial.Pos += pos;
  ShiftPos=pos;

  Quaternion qua = Shift.Qua;
  Shift.Qua = 0;
  RecordQuat.Mix(qua);
  OriQuat += qua;
  OriQuat = OriQuat.Norm();
}

void IRS::SetAccelShift(float Pitch, float Roll, float Yaw)
{
  ShiftAccelPRY = Quaternion::CreateYawPitchRoll( { Pitch * TO_RAD, Roll * TO_RAD, Yaw * TO_RAD } );
}

bool IRS::SetGroundHeight(float* Height, float MaxHeight, float Alpha)
{
  if(Height)
  {
    float shift = Inertial.Pos.Z - *Height;
    GroundShift = GroundShift*(1.0f-Alpha) + shift*Alpha;
  }
  else
  {
    float height = Inertial.Pos.Z - GroundShift;
    
    if(height<MaxHeight)
    {
      float shift = Inertial.Pos.Z - MaxHeight;
      GroundShift = GroundShift*(1.0f-Alpha) + shift*Alpha;
    }
  }
  
  float height = Inertial.Pos.Z - GroundShift;
  if (height < 0.0f) GroundShift+=height;
}

void IRS::SetNothDeclination(float Angle)
{
  ShiftNoth = 
  {
    0.0f,                        // x
    0.0f,                        // y
    sinf(Angle * TO_RAD * 0.5f), // z
    cosf(Angle * TO_RAD * 0.5f)  // w
  };
}

/*bool IRS::FixedHeight(bool Fixed, float Height)
{
  bool zero=false;
  
  if(Fixed)
  { 
    if (Inertial.Pos.Z < Height) 
    {
      FixedMinHeight = Inertial.Pos.Z;
      zero = true;
    }
    else FixedMinHeight = Height;
  }
  
  if (!Fixed || FixedMinHeight < 0.0f) FixedMinHeight = 0.0f;
  
  return zero;
}*/

void IRS::GetSinXYCosZ(Vector3& SinXYCosZ)
{
  SinXYCosZ = OriPRT;
}

void IRS::GetPitchRollYaw(Vector3& PitchRollYaw)
{
  float yaw = atan2f(2 * (OriQuat.X * OriQuat.Y - OriQuat.W * OriQuat.Z), 1 - 2 * (OriQuat.Y * OriQuat.Y + OriQuat.Z * OriQuat.Z)) * TO_DEG;
  while (yaw < 0.0f) yaw = 360.0f + yaw;

  PitchRollYaw =
  {
    GetAngle(OriPRT.Y, OriPRT.X, OriPRT.Z),  // Pitch
    GetAngle(-OriPRT.X, OriPRT.Y, OriPRT.Z), // Roll
    yaw                                      // Yaw
  };
}

void IRS::GetInertial(Vector3* Pos, Vector3* Spd, Vector3* Acc, float* Gnd)
{
  if (Acc) *Acc = Inertial.Acc;
  if (Spd) *Spd = Inertial.Spd;
  if (Pos) *Pos = Inertial.Pos;
  if (Gnd) *Gnd = GroundShift;
}
