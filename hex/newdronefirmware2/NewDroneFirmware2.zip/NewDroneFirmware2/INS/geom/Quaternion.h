﻿#pragma once

#include "Vector.h"

struct Quaternion
{
  Quaternion();
  Quaternion(float v);
  Quaternion(float x, float y, float z, float w);
  Quaternion(const Vector3& Vec, float w = 0.0f);
  Quaternion(const Quaternion& Q);

  float X, Y, Z, W;
  
  void Zero();
  void Identity();

  Quaternion Norm(float Gain = 1.0f) const;
  Quaternion Conjugate() const;
  Quaternion Invert() const;
  Quaternion Negate() const;
  bool IsNAN() const;

  Quaternion& operator=(const Quaternion& Q);
  Quaternion& operator+=(const Quaternion& Q);
  Quaternion& operator-=(const Quaternion& Q);
  Quaternion& operator*=(const float Value);
  Quaternion& operator*=(const Quaternion& Q);
  Quaternion operator*(const float Value) const;
  Quaternion operator*(const Quaternion& Q) const;
  Quaternion operator+(const Quaternion& Q) const;
  Quaternion operator-(const Quaternion& Q) const;

  Vector3 Rotate(const Vector3& vec) const;
  Vector3 RotateAroundZ(const Vector3& vec, bool CCW = false) const;
  
  static Quaternion CreateYawPitchRoll(const Vector3& PitchRollYawRad);
  static Quaternion CreateYaw(const float YawRad);
  static Quaternion CreateDirection(const Vector2& Course);
  
  Quaternion GetError(const Quaternion& Target, bool FastWay) const;
};
