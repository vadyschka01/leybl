﻿#include <math.h>

#include "Velocity.h"

static constexpr float PI = 3.14159265359f;
static constexpr float TO_DEG = 180.0f / PI;
static constexpr float TO_RAD = PI / 180.0f;

static inline float sat(float val, float min, float max)
{
  if (val < min) return min;
  if (val > max) return max;
  return val;
}

Vector2 TargetOnXY(const Vector2& Point, const Vector2& Start, const Vector2& End, const float Distance) 
{
  Vector2 line = End - Start;
  float len = line.LengthSquared();
  if (len < 1e-6f) return End;
  
  Vector2 dis = Point - Start;
  
  float t = dis.Dot(line) / len;
  t = sat(t, 0.0f, 1.0f);
  
  Vector2 proj = Start + line * t;
  
  float way = (End - proj).LengthSquared();
  
  Vector2 target = line.Norm(Distance);
  
  if (way < target.LengthSquared()) return End;
  
  return proj + target;
}

Vector2 TargetSpeed2D(const Vector3& Point, const Vector3& Start, const Vector3& End, const float Distance, const float Speed)
{
  Vector2 line = End - Point;
  
  float speed = sat(line.Length(), 0.0f, Speed);
  
  Vector2 target = TargetOnXY(Point, Start, End, Distance);
  
  Vector2 move_xy = (target - Point).Norm(speed);
  
  return move_xy;
}

Vector3 TargetSpeed3D(const Vector3& Point, const Vector3& Start, const Vector3& End, const float Distance, const float Speed)
{
    Vector3 line = End - Start;
    float len = line.LengthSquared();
    
    float distToEnd = (End - Point).Length();
    float speed = sat(distToEnd, 0.0f, Speed);

    // Если путь очень короткий, просто летим к конечной точке
    if (len < 1e-6f) return (End - Point).Norm(speed);

    // Находим проекцию на 3D-линию
    Vector3 dis = Point - Start;
    float t = dis.Dot(line) / len;
    t = sat(t, 0.0f, 1.0f); // Ограничиваем проекцию границами отрезка
    
    Vector3 proj = Start + line * t; // Ближайшая точка на 3D-отрезке

    Vector3 dir = line.Norm(); // Единичный вектор направления
    Vector3 target = proj + dir * Distance;

    // Проверяем, не вышли ли мы за конечную точку
    float way = (End - proj).LengthSquared();
    if (way < (Distance * Distance)) target = End;
    
    // Формируем единый 3D-вектор скорости // Направлен от текущей позиции к 3D-цели
    return (target - Point).Norm(speed);
}

void Velocity::UpdateMoveSpeed(const Vector3& Position, const Vector3& Speed, const Vector3& Accel, float GroundShift)
{
  SpeedCurrent = Speed;
  PointCurrent = Position;

  static Vector3 auto_spd;
  if (ManualDirect) // Управление скоростью по направлению 
  {
    auto_spd = OriQuat.RotateAroundZ(SpeedXYZ, true);
  }
  else if (ManualSpeed) // Управление скоростью в глобальных координатах 
  {
    auto_spd = SpeedXYZ;
  }
  else // Управление скоростью по точкам
  {
    Vector3 start=PointBegin, end=PointEnd;
    
    if (GroundMode)
    {
      float heigth = GroundShift + GroundHeight;
      
      //if(end.Z > heigth) end.Z = heigth; // Низя так делать (мы смешиваем глобальное задание с локальной высотой, это разные величины, иначе нас догонит гора)
      
      auto_spd = TargetSpeed2D(Position, start, end, 1.0f, MoveSpeed);
      auto_spd.Z = sat((heigth - Position.Z), -GroundSpeed, GroundSpeed);
    }
    else
    {
      float heigth = GroundShift + GroundLimit;
      
      if (start.Z < heigth) start.Z = heigth;
      if (end.Z < heigth) end.Z = heigth;
      
      auto_spd = TargetSpeed3D(Position, start, end, 1.0f, MoveSpeed);
    }
  }

  //auto_spd = OriQuat.RotateAroundZ(auto_spd, true);
  Vector3 speed = Speed;//OriQuat.RotateAroundZ(Speed, true);
  
  Vector2 xy
  {
    -RegSpeedY.Update(auto_spd.Y, speed.Y, -Accel.Y), // Pitch
    RegSpeedX.Update(auto_spd.X, speed.X, -Accel.X)   // Roll
  };

  Throt = RegSpeedT.Update(auto_spd.Z, speed.Z, -Accel.Z);  // Throt

  float pow = 0.5f + fabsf(Throt);
  if (pow < 0.1f) pow = 0.1f;

  xy /= pow; // Компенсация вектора тяги
  xy.X = sat(xy.X, -1.0f, 1.0f);
  xy.Y = sat(xy.Y, -1.0f, 1.0f);

  if (xy.LengthSquared() > (AngleSinLimit * AngleSinLimit)) xy = xy.Norm(AngleSinLimit); // Ограничение наклона

  XY_TEST = xy;
  
  Vector3 xyz = Vector3(xy, 1.0f).Norm(); // Вектор наклона тяги
  
  xyz = OriQuat.RotateAroundZ(xyz, false); // Вернуть в локальный поворот
  
  Quaternion desired = Quaternion(-xyz.Y, xyz.X, 0.0f, 1.0f+xyz.Z).Norm(); // Кватернион наклона для заданной тяги

  if (ManualDirect) MoveQuat = YawDirect * desired;
  else if (AutoYaw) MoveQuat = YawAuto * desired;
  else MoveQuat = YawManual * desired;
}

void Velocity::LockAllRegInt(bool LockI)
{
  RegSpeedX.LockI = LockI;
  RegSpeedY.LockI = LockI;
  RegSpeedT.LockI = LockI;
}

void Velocity::SetManualYaw(bool Manual, const float* Yaw)
{
  AutoYaw = !Manual;
  if (Yaw) YawManual = Quaternion::CreateYaw(*Yaw * TO_RAD);
}

void Velocity::SetManualSpeed(bool Manual, const Vector3* XYZ)
{
  if (XYZ) SpeedXYZ = *XYZ;
  ManualSpeed = Manual;
}

void Velocity::SetDistanceSpeed(const Vector3* Begin, const Vector3* End, const float* NewSpeed)
{
  if (NewSpeed) MoveSpeed = fabsf(*NewSpeed);

  if (!End) return;
  PointEnd = *End;

  if (Begin) PointBegin = *Begin;
  /*else
  {
    if(StopSoft) PointBegin += SpeedCurrent * Period;
  }*/

  YawAuto = Quaternion::CreateDirection(PointEnd - PointBegin);
}

void Velocity::SetDirectSpeedControl(bool DirectControl, const Vector3* XYZ, const float* Yaw)
{
  ManualDirect = DirectControl;

  if (!ManualDirect) return;

  if (XYZ) SpeedXYZ = *XYZ;
  if (Yaw) YawDirect = Quaternion::CreateYaw(*Yaw * TO_RAD);
}

void Velocity::Stop(const bool* SoftStop)
{
  bool stop = StopSoft;
  if (SoftStop) stop = *SoftStop;

  PointBegin = PointCurrent;
  if (stop) PointBegin += SpeedCurrent;
  PointEnd = PointBegin;
}

void Velocity::GetThrotAnglePRY(float& ThrotOut, Quaternion& QuatPRY)
{
  ThrotOut = Throt;
  QuatPRY = MoveQuat;
}
