﻿#include <math.h>

#include "Attitude.h"

void Attitude::UpdateRegPRY(const Quaternion& CurQuat, const Vector3& SpeedPRY)
{
  if (SpeedMode)
  {
    Vector3 acc = (SpeedPRY - LastSpeedPRY) / Period;

    PowerAngle.X = RegSpeedP.Update(GoalSpeed.X,  SpeedPRY.X, -acc.X);
    PowerAngle.Y = RegSpeedR.Update(GoalSpeed.Y,  SpeedPRY.Y, -acc.Y);
    PowerAngle.Z = RegSpeedY.Update(GoalSpeed.Z, -SpeedPRY.Z,  acc.Z);
  }
  else
  {
    static Quaternion error;
    error = CurQuat.GetError(GoalQuat, true);
    
    PowerAngle.X = RegAngleP.Update(0.0f, -error.X, -SpeedPRY.X);
    PowerAngle.Y = RegAngleR.Update(0.0f, -error.Y, -SpeedPRY.Y);
    PowerAngle.Z = RegAngleY.Update(0.0f, error.Z,  SpeedPRY.Z);
  }

  LastSpeedPRY = SpeedPRY;
}

void Attitude::LockAllRegInt(bool LockI)
{
  RegAngleP.LockI = LockI;
  RegAngleR.LockI = LockI;

  RegSpeedP.LockI = LockI;
  RegSpeedR.LockI = LockI;
  RegSpeedY.LockI = LockI;
}

void Attitude::SetAnglePRY(const float* Throt, const Quaternion* QuatTarget, const bool* Speed)
{
  if (Throt) LastThrot = *Throt;

  if (QuatTarget) GoalQuat = *QuatTarget;

  if (Speed) SpeedMode = *Speed;
}

void Attitude::GetPowerPRY(float* Throt, Vector3* PowerPRY)
{
  if (Throt) *Throt = LastThrot;
  if (PowerPRY) *PowerPRY = PowerAngle;
}
