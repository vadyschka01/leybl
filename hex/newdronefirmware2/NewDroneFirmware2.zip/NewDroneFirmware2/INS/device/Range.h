﻿#pragma once

#include "../geom/Vector.h"
#include "../util/Record.h"
#include "../util/RegPDI.h"
#include "../geom/Quaternion.h"

class Range
{
public:
  Range(const Record<Vector3>& RecordPos, const Record<Vector3>& RecordSpd, const Record<Quaternion>& RecordQua);

public:
  static constexpr float Freq = 50.0f;
  static constexpr float Period = 1.0f / Freq;
  
  float MaxHeight = 8.0f; // Максимальная высота измерения

  float MinAngle = 30.0f; // Угол наклона потери доверия
  float MaxAngle = 45.0f; // Угол наклона отсутствия доверия
  
  bool AbsolutePosMode = true; // Режим принудительного контроля высоты
  
public:
  bool Active;

  float Len;

  float Past = 0.0f;

  Average<float> AveSpd;
  
  const Record<Vector3>& RecPos;
  const Record<Vector3>& RecSpd;
  const Record<Quaternion>& RecQua;
  
  struct { bool Ready; float Pos, Spd, Prv, Dyn; } Shift;

public:
  struct { float Restore, Accuracy, Power, Test;  } RegShift; // Регулятор смещения позиции и скорости
  struct { float Alpha, Power, Dynamic, Distance; } RegSpd; // Регулятор смещения скорости
  
public:
  void UpdateAverage();
  
  float SetRange(float* Range);
  
  bool GetShift(float& PositionZ, float& SpeedZ);
};
