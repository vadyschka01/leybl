#include "stm32g4xx.h"

#include "gpio.h"

#include "led.h"

void LED_Init()
{
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
  GPIO_InitPin(GPIO_PIN_15 | GPIO_PORT_A | GPIO_OUTPUT);
}
//------------------------------------------------------------------------------

void LED_Set(bool Set)
{
  if (Set) GPIOA->BSRR = GPIO_BSRR_BS_15;
  else GPIOA->BSRR = GPIO_BSRR_BR_15;
}
//------------------------------------------------------------------------------
