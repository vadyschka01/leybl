#pragma once

void LED_Init();
void LED_Set(bool Set);
