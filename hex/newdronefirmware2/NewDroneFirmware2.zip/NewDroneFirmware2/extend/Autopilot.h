﻿#pragma once

#include "../INS/geom/Vector.h"
#include "INS/cont/Velocity.h"

#include "Protocol.h"
#include "Filters.h"
#include "MathFunc.h"
#include "sbus.h"

void AutoLand();
void AutoGoHome();
void AutoGoToGlobal(double lat, double lon, float abs_alt, float speed);
void AutoGoToLocal(float x, float y, float z, float speed);
void AutoSetSpeed(float speed);
void SaveNullPoint(double& lat, double& lon, float& absAlt);
void CheeckStartCondition();
float CalcLandSpeed(float CurrentRange, float MinSpeed=0.3f, float MaxSpeed=3.0f,float HeightLandStop=6.0f);

EXEC_CODE_COMMAND CheeckStatusCommand(COMMANDS_ID comId);

struct AutoPilotSettings
{
	float RadReachPoint = 0.8f; // Радиус достижения точки
	float AltAutoGoHome = 2.0f; // Высота возврата домой по умолчанию в метрах (в случае посадки в другом месте)
        float AltLand = -5.0f;
};

struct AutoPoint
{
	bool saved;
	double X, Y;
	float Z;
};

struct ExchangePoint
{
	bool New;
        float Speed;
	Vector3 Position;
};

struct DroneStatus
{
  bool MainActive = false; // Индикатор снятия с охраны
  bool AutoPilotActive = false; // Индикатор актив. автопилота
  bool ManualInputAllowed = false; // Индикатор возможности ручного управления (безопасного)
  bool AltChangeAllowed = false; // Индикатор возможности смены целевой высоты в режиме удержания позиции
  bool PointBeginNeed = true; // Индикатор необходимости указания начальной точки
  bool MissionExecute = false; // Инидикатор выполняется ли миссия
  
  bool NeedSendRawCalibData = false;
  SENSOR_ID Sensor = SENSOR_ID::ACC;
  unsigned long TimeLastSend = 0;
  unsigned long TimeStartSend = 0;
  bool NeedSaveNewEEPROMData = false;
  bool EEPROMSaved = false;
  bool NeedSaveNewFLASHData = false;
  bool FLASHSaved = false;
  
  float AvgEngineThrust = 0.0f;
  
  ENGINE_STATUS engine = ENGINE_STATUS::disable;
  SYS_MODE Mode = SYS_MODE::manual;
  STATUS_MODE StatusMode = STATUS_MODE::on_ground;
  NAV_SYS_MODE Nav = NAV_SYS_MODE::inertial;
};

extern bool ExternalGPSOff;
extern bool USE_GPS;
extern bool AutoActive;
extern bool PortDisconect;

extern Vector2 PointLand;

extern AutoPoint DroneNullPoint;
extern SBUS_Data Joypad;
enum class AutoPortState { Free, Conected, Disconect };

extern AutoPortState AutoState;

void InitAuto();
unsigned long AutoThread();

struct MainGoal
{
  bool New;
  bool Stop;
  bool Yaw;
  float Speed;
  Vector3 PRY, Position, Route;
};

extern MainGoal DroneGoal;
extern Vector3 GoalPoint;
extern DroneStatus MainDrone;

struct MainInertial
{
  Vector3 Acc, Spd, Pos;
  unsigned long Time;
};

extern MainInertial DroneInertial;

struct MainOrintation
{
  float Range;
  Vector3 PRY, Iner, Position;
  float Power_UL, Power_UR, Power_DL, Power_DR;
};

extern MainOrintation DroneOrintation;
extern Velocity MainVel;
