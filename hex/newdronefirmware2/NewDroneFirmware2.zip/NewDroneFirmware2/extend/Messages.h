#pragma once

#include "Protocol.h"

#define MAX_PACKET_LEN 200

#pragma pack(push,1)

const unsigned short MaxLength = 1024;
const unsigned char Global_stx = 0xAA;

struct HeaderBegin
{
  unsigned char stx;
  unsigned short len1; //Len header + payload (message)  ����� ������ ���� �������� ����� ��������� BEGIN+HEADER+PAYLOAD
  unsigned short len2; //Len header + payload (message)
  unsigned char crc; // CRC MESSAGE
  //---
  bool CheckCRC();
  void SetCRC();
};
struct HeaderMessages
{
  MESSAGES_ID msgId;
  unsigned char srcId;
  unsigned char dstId;
  unsigned char len;
  unsigned long long timeusec;
};
struct BeginHeader
{
  HeaderBegin begin;
  HeaderMessages header;
  void CreateMessageHeaders(unsigned long size, MESSAGES_ID msg_id);
};

struct MessageBatteryInfo
{
  BeginHeader headers;

  ProtoDataBattery payload; // �������� �� unsined long (������ �����)
};
struct MessageSysInfo
{
  BeginHeader headers;

  ProtoDataSysInfo payload;

};
struct MessageGyroInfo
{
  BeginHeader headers;

  ProtoDataGyroInfo payload;
};
struct MessageAccelInfo
{
  BeginHeader headers;

  ProtoDataAccelInfo payload;
};
struct MessageGpsInfo
{
  BeginHeader headers;

  ProtoDataGpsInfo payload;
};
struct MessageInertialInfo
{
  BeginHeader headers;

  ProtoDataInertialInfo payload;
};
struct MessageRawCalibData
{
  BeginHeader headers;
  
  ProtoDataRawCalib payload;
};
struct MessageMissionProgress
{
  BeginHeader headers;

  unsigned long long current_item;
  unsigned long long total_items;
  bool f_start;
  bool f_pause;
  char mission_name[MAX_LEN_MISSION_NAME];
};
struct MessageCommandAck
{
  BeginHeader headers;

  COMMANDS_ID commandId;
  FEASIBILITY_CODE_COMMAND status; // 0 - �� ����� ���� ��������� (����������� ��� ������), 1 - �������
  ERROR_CODE_COMMAND errorCode;
};
struct MessageStatusCommand
{
  BeginHeader headers;

  COMMANDS_ID commandId;
  EXEC_CODE_COMMAND executionCode; // 0 - ������ ��� ���������� ,1 - ����������� ,2 - ��������� �������.
  ERROR_CODE_COMMAND errorCode;
};

struct MessageCommand
{
  BeginHeader headers;
  COMMANDS_ID commandId;
};
struct MessageCommandChangeSpeed
{
  MessageCommand commandInfo;

  float speed;
};
struct MessageCommandChangeNav
{
  MessageCommand commandInfo;

  NAV_SYS_MODE nav_id; // Inertial - 1, InfoGPS = 2, Oprical_Flow = 3
};
struct MessageCommandGoToGlobal
{
  MessageCommand commandInfo;

  double lat;
  double lon;
  float abs_alt;
  float speed;
};
struct MessageCommandGoToLocal
{
  MessageCommand commandInfo;

  float x;
  float y;
  float z;
  float speed;
};
struct MessageCommandSetParameter
{
  MessageCommand commandInfo;

  unsigned char cat_id;
  unsigned char param_id;
  DATA_TYPES param_type_code;
  unsigned char param_len;
  unsigned char param_data[MAX_PACKET_LEN];
};
struct MessageCommandProcessingCalibration
{
  MessageCommand commandInfo;
 
  SENSOR_ID sensor_id;
  bool start;
};
struct MessageCommandSetCalibrationData
{
  MessageCommand commandInfo;
  
  SENSOR_ID sensor_id;
  float X[2];
  float Y[2];
  float Z[2];
};
struct MessageCountMenuCategories
{
  BeginHeader headers;

  unsigned char countCategories;
  unsigned char data[MAX_PACKET_LEN];
};
struct MenuCategori
{
  unsigned char id;
  unsigned char len_name;
  unsigned char count_param;
  char name[0];
};
struct MessageMenuCategories
{
  BeginHeader headers;

  unsigned char countCategories;
  unsigned char categories[MAX_PACKET_LEN];
};
struct MessageCategoriesParameters
{
  BeginHeader headers;

  unsigned char cat_id;
  unsigned char param_id;
  unsigned char param_name_len;
  unsigned char param_len;
  DATA_TYPES param_type_code;
  char param_data[MAX_PACKET_LEN];
};

struct MessageMissionCount
{
  BeginHeader headers;

  unsigned long long count_items;
  bool launch_confidentiality;
  bool mission_priority;
  bool fault_tolerence;
  char mission_name[MAX_PACKET_LEN];
};
struct MessageMissionItem
{
  BeginHeader headers;

  MissionItemData payload;
};
struct MessageMissionRequestItem
{
  BeginHeader headers;

  unsigned long long item_number;
};
struct MessageMissionItemAck
{
  BeginHeader headers;

  unsigned long long item_number;
  bool status; // 0 - �� �������. 1 - �������.
};

#pragma pack(pop)