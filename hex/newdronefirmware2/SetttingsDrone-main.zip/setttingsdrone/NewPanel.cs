﻿using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SettingsDrone
{
  class NewPanel : Panel
  {
    public bool SelectPanel;
    public GMapMarker Marker;
  }
  class OverlayPanel : Panel
  {
    private const int WS_EX_TRANSPARENT = 0x20;
    public OverlayPanel()
    {
      // 1. Сообщаем, что панель поддерживает прозрачный фон
      this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);

      // 2. ВАЖНО: Выключаем собственную буферизацию панели.
      // Мы полагаемся на буфер родителя (GMap), иначе будет черный фон или мерцание.
      this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);

      // 3. Убираем стиль Opaque, чтобы Windows знала, что мы не закрашиваем всё сами
      // (это решит проблему исчезающих элементов)
      this.SetStyle(ControlStyles.Opaque, false);

      // 4. Перерисовываем при изменении размеров
      this.SetStyle(ControlStyles.ResizeRedraw, false);

      this.BackColor = Color.FromArgb(127,0,0,0);
    }

    //protected override CreateParams CreateParams
    //{
    //  get
    //  {
    //    CreateParams cp = base.CreateParams;
    //    cp.ExStyle |= WS_EX_TRANSPARENT; // Делаем панель "прозрачной" для системы
    //    return cp;
    //  }
    //}

    //protected override void OnPaintBackground(PaintEventArgs e)
    //{
    //  // Оставляем пустым. 
    //  // Это предотвращает стирание фона перед отрисовкой, убирая мерцание.
    //  // Но так как мы убрали Opaque, дети будут рисоваться корректно.
    //}
  }

  public class BorderedPanel : Panel
  {
    public Color BorderColor = Color.Red;
    public int BorderWidth = 2;

    public BorderedPanel()
    {
      // Убираем стандартную рамку
      this.Padding = new Padding(BorderWidth); // Чтобы контент не налезал на рамку
      this.SetStyle(ControlStyles.ResizeRedraw, true); // Перерисовывать при изменении размера
    }

    protected override void OnPaint(PaintEventArgs e)
    {
      base.OnPaint(e);

      // Рисуем рамку с помощью встроенного метода ControlPaint
      ControlPaint.DrawBorder(e.Graphics, this.ClientRectangle,
          BorderColor, BorderWidth, ButtonBorderStyle.Solid,
          BorderColor, BorderWidth, ButtonBorderStyle.Solid,
          BorderColor, BorderWidth, ButtonBorderStyle.Solid,
          BorderColor, BorderWidth, ButtonBorderStyle.Solid);
    }
  }
}
