﻿
using System.Windows.Forms.DataVisualization.Charting;

namespace SettingsDrone
{
  partial class SettingsDrone
  {
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      if (connection != null) connection.Disconnect();
      base.Dispose(disposing);
      gMapControl1.Dispose();
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      components = new System.ComponentModel.Container();
      ChartArea chartArea2 = new ChartArea();
      Legend legend2 = new Legend();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingsDrone));
      timer1 = new System.Windows.Forms.Timer(components);
      groupBox1 = new GroupBox();
      checkBox1 = new CheckBox();
      TopWindow = new CheckBox();
      buttonLogging = new Button();
      textBoxLogFilePath = new TextBox();
      label10 = new Label();
      numericUpDownFreqReqOthreTelem = new NumericUpDown();
      label8 = new Label();
      label7 = new Label();
      numericUpDown_Freq_req_telem = new NumericUpDown();
      HzRecvTelem = new Label();
      TelemetryMessagesTab = new TabControl();
      GPS = new TabPage();
      checkedListBoxGPS2 = new CheckedListBox();
      checkedListBoxGPS = new CheckedListBox();
      Inetrial = new TabPage();
      checkedListBoxInertial2 = new CheckedListBox();
      checkedListBoxInertial = new CheckedListBox();
      Gyro = new TabPage();
      checkedListBoxGyro = new CheckedListBox();
      Accel = new TabPage();
      checkedListBoxAccel = new CheckedListBox();
      Battery = new TabPage();
      checkedListBoxBattery = new CheckedListBox();
      Sys = new TabPage();
      groupBox2 = new GroupBox();
      checkedListBoxEngines = new CheckedListBox();
      checkedListBoxSys = new CheckedListBox();
      tabPageControlUAV = new TabPage();
      SetLocalCoord = new Button();
      commandStatusLabel = new Label();
      commandLabel = new Label();
      label56 = new Label();
      label54 = new Label();
      buttonSendSetSpeed = new Button();
      buttonGoToGlobal = new Button();
      textBoxLon = new TextBox();
      label52 = new Label();
      textBoxLat = new TextBox();
      label50 = new Label();
      buttonSendStop = new Button();
      buttonSendGoToLocal = new Button();
      numericUpDownSpeed = new NumericUpDown();
      label48 = new Label();
      numericUpDownZ = new NumericUpDown();
      label46 = new Label();
      numericUpDownY = new NumericUpDown();
      label44 = new Label();
      numericUpDownX = new NumericUpDown();
      label42 = new Label();
      buttonChangeNav = new Button();
      buttonSendGoHome = new Button();
      buttonSendLand = new Button();
      ConnectionBox = new GroupBox();
      ConnectionsPages = new TabControl();
      PipeLinePage = new TabPage();
      AddressPipeLine = new TextBox();
      PipeLineConnect = new Button();
      label1 = new Label();
      ComPage = new TabPage();
      BAUDBOX = new ComboBox();
      COMBOX = new ComboBox();
      label3 = new Label();
      label2 = new Label();
      COMConnect = new Button();
      groupBoxGraph = new GroupBox();
      checkBox_Graph_Live = new CheckBox();
      button_Graph_Fixed = new Button();
      numericUpDown_Graph_Interval = new NumericUpDown();
      label6 = new Label();
      checkBox_Graph_Auto = new CheckBox();
      numericUpDown_Graph_Scale = new NumericUpDown();
      checkBox_Graph_Scale = new CheckBox();
      numericUpDown_Graph_Max = new NumericUpDown();
      numericUpDown_Graph_Min = new NumericUpDown();
      label5 = new Label();
      numericUpDown_Graph_Time = new NumericUpDown();
      label4 = new Label();
      tabControl1 = new TabControl();
      Telemetry = new TabPage();
      panel3 = new Panel();
      panel1 = new Panel();
      panel10 = new OverlayPanel();
      gMapControl1 = new GMap.NET.WindowsForms.GMapControl();
      chart_Graph = new Chart();
      panel2 = new Panel();
      panel6 = new Panel();
      groupBox5 = new GroupBox();
      label38 = new Label();
      SPDRX = new Label();
      label30 = new Label();
      TelemBaroAlt = new Label();
      label59 = new Label();
      TelemYawVel = new Label();
      label57 = new Label();
      TelemPitchVel = new Label();
      label55 = new Label();
      TelemRollVel = new Label();
      label53 = new Label();
      TelemYaw = new Label();
      label51 = new Label();
      TelemPitch = new Label();
      label49 = new Label();
      TelemRoll = new Label();
      label47 = new Label();
      TelemSpeedINS = new Label();
      label45 = new Label();
      TelemHeadingDeg = new Label();
      label43 = new Label();
      TelemZ = new Label();
      label41 = new Label();
      TelemY = new Label();
      label34 = new Label();
      TelemX = new Label();
      label26 = new Label();
      TelemTimeUTC = new Label();
      label40 = new Label();
      TelemGPSFixType = new Label();
      label36 = new Label();
      TelemGPSspeed = new Label();
      label32 = new Label();
      TelemSatUsed = new Label();
      label28 = new Label();
      TelemSatVisible = new Label();
      label24 = new Label();
      TelemJamming = new Label();
      label39 = new Label();
      TelemNoise = new Label();
      label37 = new Label();
      TelemPdop = new Label();
      label35 = new Label();
      TelemVdop = new Label();
      label33 = new Label();
      TelemHdop = new Label();
      label31 = new Label();
      TelemRealAlt = new Label();
      label29 = new Label();
      TelemAbsAlt = new Label();
      label27 = new Label();
      TelemLon = new Label();
      label25 = new Label();
      TelemLat = new Label();
      label20 = new Label();
      TelemTempBaro = new Label();
      label22 = new Label();
      TelemPressureBaro = new Label();
      label18 = new Label();
      TelemTimeRemBat = new Label();
      label16 = new Label();
      TelemTotalPower = new Label();
      label23 = new Label();
      TelemBatTemp = new Label();
      label21 = new Label();
      TelemAmperageBat = new Label();
      label19 = new Label();
      TelemVoltageBat = new Label();
      label17 = new Label();
      TelemPerCharge = new Label();
      label15 = new Label();
      TelemEngineCount = new Label();
      label14 = new Label();
      TelemEngineStatus = new Label();
      label13 = new Label();
      TelemNavSys = new Label();
      label12 = new Label();
      TelemStatusMode = new Label();
      label11 = new Label();
      TelemMode = new Label();
      label9 = new Label();
      groupBox4 = new GroupBox();
      groupBox3 = new GroupBox();
      tabPageSettings = new TabPage();
      tabControlSettingsMenu = new TabControl();
      MagColibration = new TabPage();
      panel4 = new Panel();
      SendMagCalibData = new Button();
      comboBoxSensors = new ComboBox();
      textBox2 = new TextBox();
      textBox1 = new TextBox();
      StartMagGraph = new Button();
      CalculateSphere = new Button();
      sphereTextBox = new TextBox();
      CalCulateFiltSphere = new Button();
      groupBox6 = new GroupBox();
      graph3d1 = new Plot3D.Graph3D();
      AccColib = new TabPage();
      panel5 = new Panel();
      panel9 = new Panel();
      panelMinuseZ = new Panel();
      pictureBox5 = new PictureBox();
      textBoxMinuseZ = new TextBox();
      panelPluseZ = new Panel();
      pictureBox6 = new PictureBox();
      textBoxPluseZ = new TextBox();
      panelMinuseY = new Panel();
      pictureBox4 = new PictureBox();
      textBoxMinuseY = new TextBox();
      panel8 = new Panel();
      panelPluseY = new Panel();
      pictureBox3 = new PictureBox();
      textBoxPluseY = new TextBox();
      panelMinuseX = new Panel();
      pictureBox1 = new PictureBox();
      textBoxMinuseX = new TextBox();
      panelPluseX = new Panel();
      textBoxPluseX = new TextBox();
      pictureBox2 = new PictureBox();
      panel7 = new Panel();
      SetLevelHor = new Button();
      SendAccColibData = new Button();
      numericUpDownBorderAccValue = new NumericUpDown();
      label60 = new Label();
      numericUpCountValueAcc = new NumericUpDown();
      label58 = new Label();
      buttonStartAccColib = new Button();
      groupBox1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)numericUpDownFreqReqOthreTelem).BeginInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDown_Freq_req_telem).BeginInit();
      TelemetryMessagesTab.SuspendLayout();
      GPS.SuspendLayout();
      Inetrial.SuspendLayout();
      Gyro.SuspendLayout();
      Accel.SuspendLayout();
      Battery.SuspendLayout();
      Sys.SuspendLayout();
      groupBox2.SuspendLayout();
      tabPageControlUAV.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)numericUpDownSpeed).BeginInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDownZ).BeginInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDownY).BeginInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDownX).BeginInit();
      ConnectionBox.SuspendLayout();
      ConnectionsPages.SuspendLayout();
      PipeLinePage.SuspendLayout();
      ComPage.SuspendLayout();
      groupBoxGraph.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)numericUpDown_Graph_Interval).BeginInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDown_Graph_Scale).BeginInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDown_Graph_Max).BeginInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDown_Graph_Min).BeginInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDown_Graph_Time).BeginInit();
      tabControl1.SuspendLayout();
      Telemetry.SuspendLayout();
      panel3.SuspendLayout();
      panel1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)chart_Graph).BeginInit();
      panel2.SuspendLayout();
      panel6.SuspendLayout();
      groupBox5.SuspendLayout();
      groupBox4.SuspendLayout();
      groupBox3.SuspendLayout();
      tabPageSettings.SuspendLayout();
      MagColibration.SuspendLayout();
      panel4.SuspendLayout();
      groupBox6.SuspendLayout();
      AccColib.SuspendLayout();
      panel5.SuspendLayout();
      panel9.SuspendLayout();
      panelMinuseZ.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
      panelPluseZ.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
      panelMinuseY.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
      panel8.SuspendLayout();
      panelPluseY.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
      panelMinuseX.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
      panelPluseX.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
      panel7.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)numericUpDownBorderAccValue).BeginInit();
      ((System.ComponentModel.ISupportInitialize)numericUpCountValueAcc).BeginInit();
      SuspendLayout();
      // 
      // timer1
      // 
      timer1.Enabled = true;
      timer1.Interval = 20;
      timer1.Tick += timer1_Tick;
      // 
      // groupBox1
      // 
      groupBox1.BackColor = Color.Transparent;
      groupBox1.Controls.Add(checkBox1);
      groupBox1.Controls.Add(TopWindow);
      groupBox1.Controls.Add(buttonLogging);
      groupBox1.Controls.Add(textBoxLogFilePath);
      groupBox1.Controls.Add(label10);
      groupBox1.Controls.Add(numericUpDownFreqReqOthreTelem);
      groupBox1.Controls.Add(label8);
      groupBox1.Controls.Add(label7);
      groupBox1.Controls.Add(numericUpDown_Freq_req_telem);
      groupBox1.Location = new Point(666, 28);
      groupBox1.Margin = new Padding(4, 3, 4, 3);
      groupBox1.Name = "groupBox1";
      groupBox1.Padding = new Padding(4, 3, 4, 3);
      groupBox1.Size = new Size(1004, 107);
      groupBox1.TabIndex = 4;
      groupBox1.TabStop = false;
      groupBox1.Text = "General settings";
      // 
      // checkBox1
      // 
      checkBox1.AutoSize = true;
      checkBox1.Checked = true;
      checkBox1.CheckState = CheckState.Checked;
      checkBox1.Location = new Point(493, 75);
      checkBox1.Margin = new Padding(4, 3, 4, 3);
      checkBox1.Name = "checkBox1";
      checkBox1.Size = new Size(80, 29);
      checkBox1.TabIndex = 11;
      checkBox1.Text = "Chart";
      checkBox1.UseVisualStyleBackColor = true;
      checkBox1.CheckedChanged += checkBox1_CheckedChanged;
      // 
      // TopWindow
      // 
      TopWindow.AutoSize = true;
      TopWindow.Location = new Point(304, 75);
      TopWindow.Margin = new Padding(4, 3, 4, 3);
      TopWindow.Name = "TopWindow";
      TopWindow.Size = new Size(181, 29);
      TopWindow.TabIndex = 8;
      TopWindow.Text = "Top other window";
      TopWindow.UseVisualStyleBackColor = true;
      TopWindow.CheckedChanged += TopWindow_CheckedChanged;
      // 
      // buttonLogging
      // 
      buttonLogging.BackColor = Color.WhiteSmoke;
      buttonLogging.FlatStyle = FlatStyle.Flat;
      buttonLogging.Location = new Point(854, 22);
      buttonLogging.Margin = new Padding(4, 3, 4, 3);
      buttonLogging.Name = "buttonLogging";
      buttonLogging.Size = new Size(140, 42);
      buttonLogging.TabIndex = 10;
      buttonLogging.Text = "Start log\r\n";
      buttonLogging.UseVisualStyleBackColor = false;
      buttonLogging.Click += buttonLogging_Click;
      // 
      // textBoxLogFilePath
      // 
      textBoxLogFilePath.Location = new Point(429, 28);
      textBoxLogFilePath.Margin = new Padding(4, 3, 4, 3);
      textBoxLogFilePath.Name = "textBoxLogFilePath";
      textBoxLogFilePath.Size = new Size(418, 31);
      textBoxLogFilePath.TabIndex = 9;
      // 
      // label10
      // 
      label10.AutoSize = true;
      label10.Location = new Point(304, 32);
      label10.Margin = new Padding(4, 0, 4, 0);
      label10.Name = "label10";
      label10.Size = new Size(115, 25);
      label10.TabIndex = 8;
      label10.Text = "Log file path:";
      // 
      // numericUpDownFreqReqOthreTelem
      // 
      numericUpDownFreqReqOthreTelem.Location = new Point(206, 65);
      numericUpDownFreqReqOthreTelem.Margin = new Padding(4, 3, 4, 3);
      numericUpDownFreqReqOthreTelem.Name = "numericUpDownFreqReqOthreTelem";
      numericUpDownFreqReqOthreTelem.Size = new Size(74, 31);
      numericUpDownFreqReqOthreTelem.TabIndex = 7;
      numericUpDownFreqReqOthreTelem.Value = new decimal(new int[] { 1, 0, 0, 0 });
      numericUpDownFreqReqOthreTelem.ValueChanged += numericUpDownFreqReqOthreTelem_ValueChanged;
      // 
      // label8
      // 
      label8.AutoSize = true;
      label8.Location = new Point(14, 70);
      label8.Margin = new Padding(4, 0, 4, 0);
      label8.Name = "label8";
      label8.Size = new Size(178, 25);
      label8.TabIndex = 6;
      label8.Text = "Freq req other telem:";
      // 
      // label7
      // 
      label7.AutoSize = true;
      label7.Location = new Point(14, 28);
      label7.Margin = new Padding(4, 0, 4, 0);
      label7.Name = "label7";
      label7.Size = new Size(183, 25);
      label7.TabIndex = 5;
      label7.Text = "Freq req graph telem:";
      // 
      // numericUpDown_Freq_req_telem
      // 
      numericUpDown_Freq_req_telem.Location = new Point(206, 23);
      numericUpDown_Freq_req_telem.Margin = new Padding(4, 3, 4, 3);
      numericUpDown_Freq_req_telem.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
      numericUpDown_Freq_req_telem.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
      numericUpDown_Freq_req_telem.Name = "numericUpDown_Freq_req_telem";
      numericUpDown_Freq_req_telem.Size = new Size(74, 31);
      numericUpDown_Freq_req_telem.TabIndex = 2;
      numericUpDown_Freq_req_telem.Value = new decimal(new int[] { 10, 0, 0, 0 });
      numericUpDown_Freq_req_telem.ValueChanged += numericUpDown_Freq_req_telem_ValueChanged;
      // 
      // HzRecvTelem
      // 
      HzRecvTelem.AutoSize = true;
      HzRecvTelem.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      HzRecvTelem.Location = new Point(426, 662);
      HzRecvTelem.Margin = new Padding(4, 0, 4, 0);
      HzRecvTelem.Name = "HzRecvTelem";
      HzRecvTelem.Size = new Size(22, 25);
      HzRecvTelem.TabIndex = 81;
      HzRecvTelem.Text = "0";
      // 
      // TelemetryMessagesTab
      // 
      TelemetryMessagesTab.Controls.Add(GPS);
      TelemetryMessagesTab.Controls.Add(Inetrial);
      TelemetryMessagesTab.Controls.Add(Gyro);
      TelemetryMessagesTab.Controls.Add(Accel);
      TelemetryMessagesTab.Controls.Add(Battery);
      TelemetryMessagesTab.Controls.Add(Sys);
      TelemetryMessagesTab.Controls.Add(tabPageControlUAV);
      TelemetryMessagesTab.Location = new Point(9, 38);
      TelemetryMessagesTab.Margin = new Padding(4, 3, 4, 3);
      TelemetryMessagesTab.Name = "TelemetryMessagesTab";
      TelemetryMessagesTab.SelectedIndex = 0;
      TelemetryMessagesTab.Size = new Size(646, 368);
      TelemetryMessagesTab.TabIndex = 5;
      // 
      // GPS
      // 
      GPS.Controls.Add(checkedListBoxGPS2);
      GPS.Controls.Add(checkedListBoxGPS);
      GPS.Location = new Point(4, 34);
      GPS.Margin = new Padding(4, 3, 4, 3);
      GPS.Name = "GPS";
      GPS.Padding = new Padding(4, 3, 4, 3);
      GPS.Size = new Size(638, 330);
      GPS.TabIndex = 0;
      GPS.Text = "GPS";
      GPS.UseVisualStyleBackColor = true;
      // 
      // checkedListBoxGPS2
      // 
      checkedListBoxGPS2.FormattingEnabled = true;
      checkedListBoxGPS2.Location = new Point(309, 8);
      checkedListBoxGPS2.Margin = new Padding(4, 3, 4, 3);
      checkedListBoxGPS2.Name = "checkedListBoxGPS2";
      checkedListBoxGPS2.Size = new Size(304, 228);
      checkedListBoxGPS2.TabIndex = 1;
      checkedListBoxGPS2.ItemCheck += checkedListBoxTelemetry_ItemCheck;
      // 
      // checkedListBoxGPS
      // 
      checkedListBoxGPS.FormattingEnabled = true;
      checkedListBoxGPS.Location = new Point(9, 8);
      checkedListBoxGPS.Margin = new Padding(4, 3, 4, 3);
      checkedListBoxGPS.Name = "checkedListBoxGPS";
      checkedListBoxGPS.Size = new Size(293, 228);
      checkedListBoxGPS.TabIndex = 0;
      checkedListBoxGPS.ItemCheck += checkedListBoxTelemetry_ItemCheck;
      // 
      // Inetrial
      // 
      Inetrial.Controls.Add(checkedListBoxInertial2);
      Inetrial.Controls.Add(checkedListBoxInertial);
      Inetrial.Location = new Point(4, 34);
      Inetrial.Margin = new Padding(4, 3, 4, 3);
      Inetrial.Name = "Inetrial";
      Inetrial.Padding = new Padding(4, 3, 4, 3);
      Inetrial.Size = new Size(638, 330);
      Inetrial.TabIndex = 1;
      Inetrial.Text = "Inertial";
      Inetrial.UseVisualStyleBackColor = true;
      // 
      // checkedListBoxInertial2
      // 
      checkedListBoxInertial2.FormattingEnabled = true;
      checkedListBoxInertial2.Location = new Point(309, 8);
      checkedListBoxInertial2.Margin = new Padding(4, 3, 4, 3);
      checkedListBoxInertial2.Name = "checkedListBoxInertial2";
      checkedListBoxInertial2.Size = new Size(293, 228);
      checkedListBoxInertial2.TabIndex = 2;
      checkedListBoxInertial2.ItemCheck += checkedListBoxTelemetry_ItemCheck;
      // 
      // checkedListBoxInertial
      // 
      checkedListBoxInertial.FormattingEnabled = true;
      checkedListBoxInertial.Location = new Point(9, 8);
      checkedListBoxInertial.Margin = new Padding(4, 3, 4, 3);
      checkedListBoxInertial.Name = "checkedListBoxInertial";
      checkedListBoxInertial.Size = new Size(293, 228);
      checkedListBoxInertial.TabIndex = 1;
      checkedListBoxInertial.ItemCheck += checkedListBoxTelemetry_ItemCheck;
      // 
      // Gyro
      // 
      Gyro.Controls.Add(checkedListBoxGyro);
      Gyro.Location = new Point(4, 34);
      Gyro.Margin = new Padding(4, 3, 4, 3);
      Gyro.Name = "Gyro";
      Gyro.Size = new Size(638, 330);
      Gyro.TabIndex = 2;
      Gyro.Text = "Gyro";
      Gyro.UseVisualStyleBackColor = true;
      // 
      // checkedListBoxGyro
      // 
      checkedListBoxGyro.FormattingEnabled = true;
      checkedListBoxGyro.Location = new Point(9, 17);
      checkedListBoxGyro.Margin = new Padding(4, 3, 4, 3);
      checkedListBoxGyro.Name = "checkedListBoxGyro";
      checkedListBoxGyro.Size = new Size(293, 228);
      checkedListBoxGyro.TabIndex = 2;
      checkedListBoxGyro.ItemCheck += checkedListBoxTelemetry_ItemCheck;
      // 
      // Accel
      // 
      Accel.Controls.Add(checkedListBoxAccel);
      Accel.Location = new Point(4, 34);
      Accel.Margin = new Padding(4, 3, 4, 3);
      Accel.Name = "Accel";
      Accel.Size = new Size(638, 330);
      Accel.TabIndex = 3;
      Accel.Text = "Accel";
      Accel.UseVisualStyleBackColor = true;
      // 
      // checkedListBoxAccel
      // 
      checkedListBoxAccel.FormattingEnabled = true;
      checkedListBoxAccel.Location = new Point(9, 15);
      checkedListBoxAccel.Margin = new Padding(4, 3, 4, 3);
      checkedListBoxAccel.Name = "checkedListBoxAccel";
      checkedListBoxAccel.Size = new Size(293, 228);
      checkedListBoxAccel.TabIndex = 3;
      checkedListBoxAccel.ItemCheck += checkedListBoxTelemetry_ItemCheck;
      // 
      // Battery
      // 
      Battery.Controls.Add(checkedListBoxBattery);
      Battery.Location = new Point(4, 34);
      Battery.Margin = new Padding(4, 3, 4, 3);
      Battery.Name = "Battery";
      Battery.Size = new Size(638, 330);
      Battery.TabIndex = 4;
      Battery.Text = "Battery";
      Battery.UseVisualStyleBackColor = true;
      // 
      // checkedListBoxBattery
      // 
      checkedListBoxBattery.FormattingEnabled = true;
      checkedListBoxBattery.Location = new Point(9, 17);
      checkedListBoxBattery.Margin = new Padding(4, 3, 4, 3);
      checkedListBoxBattery.Name = "checkedListBoxBattery";
      checkedListBoxBattery.Size = new Size(293, 228);
      checkedListBoxBattery.TabIndex = 4;
      checkedListBoxBattery.ItemCheck += checkedListBoxTelemetry_ItemCheck;
      // 
      // Sys
      // 
      Sys.Controls.Add(groupBox2);
      Sys.Controls.Add(checkedListBoxSys);
      Sys.Location = new Point(4, 34);
      Sys.Margin = new Padding(4, 3, 4, 3);
      Sys.Name = "Sys";
      Sys.Size = new Size(638, 330);
      Sys.TabIndex = 5;
      Sys.Text = "Sys";
      Sys.UseVisualStyleBackColor = true;
      // 
      // groupBox2
      // 
      groupBox2.Controls.Add(checkedListBoxEngines);
      groupBox2.Location = new Point(309, 15);
      groupBox2.Margin = new Padding(4, 3, 4, 3);
      groupBox2.Name = "groupBox2";
      groupBox2.Padding = new Padding(4, 3, 4, 3);
      groupBox2.Size = new Size(299, 320);
      groupBox2.TabIndex = 6;
      groupBox2.TabStop = false;
      groupBox2.Text = "Engines";
      // 
      // checkedListBoxEngines
      // 
      checkedListBoxEngines.FormattingEnabled = true;
      checkedListBoxEngines.Location = new Point(9, 35);
      checkedListBoxEngines.Margin = new Padding(4, 3, 4, 3);
      checkedListBoxEngines.Name = "checkedListBoxEngines";
      checkedListBoxEngines.Size = new Size(283, 144);
      checkedListBoxEngines.TabIndex = 6;
      checkedListBoxEngines.ItemCheck += checkedListBoxEngines_ItemCheck;
      // 
      // checkedListBoxSys
      // 
      checkedListBoxSys.FormattingEnabled = true;
      checkedListBoxSys.Location = new Point(9, 15);
      checkedListBoxSys.Margin = new Padding(4, 3, 4, 3);
      checkedListBoxSys.Name = "checkedListBoxSys";
      checkedListBoxSys.Size = new Size(293, 228);
      checkedListBoxSys.TabIndex = 5;
      checkedListBoxSys.ItemCheck += checkedListBoxTelemetry_ItemCheck;
      // 
      // tabPageControlUAV
      // 
      tabPageControlUAV.Controls.Add(SetLocalCoord);
      tabPageControlUAV.Controls.Add(commandStatusLabel);
      tabPageControlUAV.Controls.Add(commandLabel);
      tabPageControlUAV.Controls.Add(label56);
      tabPageControlUAV.Controls.Add(label54);
      tabPageControlUAV.Controls.Add(buttonSendSetSpeed);
      tabPageControlUAV.Controls.Add(buttonGoToGlobal);
      tabPageControlUAV.Controls.Add(textBoxLon);
      tabPageControlUAV.Controls.Add(label52);
      tabPageControlUAV.Controls.Add(textBoxLat);
      tabPageControlUAV.Controls.Add(label50);
      tabPageControlUAV.Controls.Add(buttonSendStop);
      tabPageControlUAV.Controls.Add(buttonSendGoToLocal);
      tabPageControlUAV.Controls.Add(numericUpDownSpeed);
      tabPageControlUAV.Controls.Add(label48);
      tabPageControlUAV.Controls.Add(numericUpDownZ);
      tabPageControlUAV.Controls.Add(label46);
      tabPageControlUAV.Controls.Add(numericUpDownY);
      tabPageControlUAV.Controls.Add(label44);
      tabPageControlUAV.Controls.Add(numericUpDownX);
      tabPageControlUAV.Controls.Add(label42);
      tabPageControlUAV.Controls.Add(buttonChangeNav);
      tabPageControlUAV.Controls.Add(buttonSendGoHome);
      tabPageControlUAV.Controls.Add(buttonSendLand);
      tabPageControlUAV.Location = new Point(4, 34);
      tabPageControlUAV.Margin = new Padding(1, 2, 1, 2);
      tabPageControlUAV.Name = "tabPageControlUAV";
      tabPageControlUAV.Size = new Size(638, 330);
      tabPageControlUAV.TabIndex = 6;
      tabPageControlUAV.Text = "Control";
      tabPageControlUAV.UseVisualStyleBackColor = true;
      // 
      // SetLocalCoord
      // 
      SetLocalCoord.FlatStyle = FlatStyle.Flat;
      SetLocalCoord.Location = new Point(4, 132);
      SetLocalCoord.Margin = new Padding(4, 5, 4, 5);
      SetLocalCoord.Name = "SetLocalCoord";
      SetLocalCoord.Size = new Size(71, 33);
      SetLocalCoord.TabIndex = 23;
      SetLocalCoord.Text = "Set";
      SetLocalCoord.UseVisualStyleBackColor = true;
      SetLocalCoord.Click += SetLocalCoord_Click;
      // 
      // commandStatusLabel
      // 
      commandStatusLabel.AutoSize = true;
      commandStatusLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      commandStatusLabel.Location = new Point(186, 232);
      commandStatusLabel.Margin = new Padding(1, 0, 1, 0);
      commandStatusLabel.Name = "commandStatusLabel";
      commandStatusLabel.Size = new Size(19, 25);
      commandStatusLabel.TabIndex = 22;
      commandStatusLabel.Text = "-";
      // 
      // commandLabel
      // 
      commandLabel.AutoSize = true;
      commandLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      commandLabel.Location = new Point(186, 202);
      commandLabel.Margin = new Padding(1, 0, 1, 0);
      commandLabel.Name = "commandLabel";
      commandLabel.Size = new Size(19, 25);
      commandLabel.TabIndex = 21;
      commandLabel.Text = "-";
      // 
      // label56
      // 
      label56.AutoSize = true;
      label56.Location = new Point(79, 202);
      label56.Margin = new Padding(1, 0, 1, 0);
      label56.Name = "label56";
      label56.Size = new Size(100, 25);
      label56.TabIndex = 20;
      label56.Text = "Command:";
      // 
      // label54
      // 
      label54.AutoSize = true;
      label54.Location = new Point(29, 232);
      label54.Margin = new Padding(1, 0, 1, 0);
      label54.Name = "label54";
      label54.Size = new Size(152, 25);
      label54.TabIndex = 19;
      label54.Text = "Command status:";
      // 
      // buttonSendSetSpeed
      // 
      buttonSendSetSpeed.Enabled = false;
      buttonSendSetSpeed.FlatStyle = FlatStyle.Flat;
      buttonSendSetSpeed.Location = new Point(9, 285);
      buttonSendSetSpeed.Margin = new Padding(1, 2, 1, 2);
      buttonSendSetSpeed.Name = "buttonSendSetSpeed";
      buttonSendSetSpeed.Size = new Size(111, 33);
      buttonSendSetSpeed.TabIndex = 18;
      buttonSendSetSpeed.Text = "SetSpeed";
      buttonSendSetSpeed.UseVisualStyleBackColor = true;
      buttonSendSetSpeed.Click += buttonSendSetSpeed_Click;
      // 
      // buttonGoToGlobal
      // 
      buttonGoToGlobal.Enabled = false;
      buttonGoToGlobal.FlatStyle = FlatStyle.Flat;
      buttonGoToGlobal.Location = new Point(261, 132);
      buttonGoToGlobal.Margin = new Padding(1, 2, 1, 2);
      buttonGoToGlobal.Name = "buttonGoToGlobal";
      buttonGoToGlobal.Size = new Size(286, 33);
      buttonGoToGlobal.TabIndex = 17;
      buttonGoToGlobal.Text = "GoToGlobal";
      buttonGoToGlobal.UseVisualStyleBackColor = true;
      buttonGoToGlobal.Click += buttonGoToGlobal_Click;
      // 
      // textBoxLon
      // 
      textBoxLon.Location = new Point(314, 58);
      textBoxLon.Margin = new Padding(1, 2, 1, 2);
      textBoxLon.Name = "textBoxLon";
      textBoxLon.Size = new Size(234, 31);
      textBoxLon.TabIndex = 16;
      textBoxLon.KeyPress += _KeyTextBoxPressFloat;
      // 
      // label52
      // 
      label52.AutoSize = true;
      label52.Location = new Point(261, 62);
      label52.Margin = new Padding(1, 0, 1, 0);
      label52.Name = "label52";
      label52.Size = new Size(45, 25);
      label52.TabIndex = 15;
      label52.Text = "Lon:";
      // 
      // textBoxLat
      // 
      textBoxLat.Location = new Point(314, 22);
      textBoxLat.Margin = new Padding(1, 2, 1, 2);
      textBoxLat.Name = "textBoxLat";
      textBoxLat.Size = new Size(234, 31);
      textBoxLat.TabIndex = 14;
      textBoxLat.KeyPress += _KeyTextBoxPressFloat;
      // 
      // label50
      // 
      label50.AutoSize = true;
      label50.Location = new Point(269, 23);
      label50.Margin = new Padding(1, 0, 1, 0);
      label50.Name = "label50";
      label50.Size = new Size(39, 25);
      label50.TabIndex = 13;
      label50.Text = "Lat:";
      // 
      // buttonSendStop
      // 
      buttonSendStop.Enabled = false;
      buttonSendStop.FlatStyle = FlatStyle.Flat;
      buttonSendStop.Location = new Point(514, 285);
      buttonSendStop.Margin = new Padding(1, 2, 1, 2);
      buttonSendStop.Name = "buttonSendStop";
      buttonSendStop.Size = new Size(111, 33);
      buttonSendStop.TabIndex = 12;
      buttonSendStop.Text = "Stop";
      buttonSendStop.UseVisualStyleBackColor = true;
      buttonSendStop.Click += buttonSendStop_Click;
      // 
      // buttonSendGoToLocal
      // 
      buttonSendGoToLocal.Enabled = false;
      buttonSendGoToLocal.FlatStyle = FlatStyle.Flat;
      buttonSendGoToLocal.Location = new Point(81, 132);
      buttonSendGoToLocal.Margin = new Padding(1, 2, 1, 2);
      buttonSendGoToLocal.Name = "buttonSendGoToLocal";
      buttonSendGoToLocal.Size = new Size(159, 33);
      buttonSendGoToLocal.TabIndex = 11;
      buttonSendGoToLocal.Text = "GoToLocal";
      buttonSendGoToLocal.UseVisualStyleBackColor = true;
      buttonSendGoToLocal.Click += buttonSendGoToLocal_Click;
      // 
      // numericUpDownSpeed
      // 
      numericUpDownSpeed.DecimalPlaces = 5;
      numericUpDownSpeed.Increment = new decimal(new int[] { 1, 0, 0, 65536 });
      numericUpDownSpeed.Location = new Point(334, 93);
      numericUpDownSpeed.Margin = new Padding(1, 2, 1, 2);
      numericUpDownSpeed.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
      numericUpDownSpeed.Name = "numericUpDownSpeed";
      numericUpDownSpeed.Size = new Size(214, 31);
      numericUpDownSpeed.TabIndex = 10;
      numericUpDownSpeed.Value = new decimal(new int[] { 1, 0, 0, 0 });
      // 
      // label48
      // 
      label48.AutoSize = true;
      label48.Location = new Point(261, 97);
      label48.Margin = new Padding(1, 0, 1, 0);
      label48.Name = "label48";
      label48.Size = new Size(66, 25);
      label48.TabIndex = 9;
      label48.Text = "Speed:";
      // 
      // numericUpDownZ
      // 
      numericUpDownZ.DecimalPlaces = 5;
      numericUpDownZ.Increment = new decimal(new int[] { 1, 0, 0, 65536 });
      numericUpDownZ.Location = new Point(114, 93);
      numericUpDownZ.Margin = new Padding(1, 2, 1, 2);
      numericUpDownZ.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
      numericUpDownZ.Minimum = new decimal(new int[] { 10000, 0, 0, int.MinValue });
      numericUpDownZ.Name = "numericUpDownZ";
      numericUpDownZ.Size = new Size(121, 31);
      numericUpDownZ.TabIndex = 8;
      // 
      // label46
      // 
      label46.AutoSize = true;
      label46.Location = new Point(81, 100);
      label46.Margin = new Padding(1, 0, 1, 0);
      label46.Name = "label46";
      label46.Size = new Size(26, 25);
      label46.TabIndex = 7;
      label46.Text = "Z:";
      // 
      // numericUpDownY
      // 
      numericUpDownY.DecimalPlaces = 5;
      numericUpDownY.Increment = new decimal(new int[] { 1, 0, 0, 65536 });
      numericUpDownY.Location = new Point(114, 58);
      numericUpDownY.Margin = new Padding(1, 2, 1, 2);
      numericUpDownY.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
      numericUpDownY.Minimum = new decimal(new int[] { 10000, 0, 0, int.MinValue });
      numericUpDownY.Name = "numericUpDownY";
      numericUpDownY.Size = new Size(121, 31);
      numericUpDownY.TabIndex = 6;
      // 
      // label44
      // 
      label44.AutoSize = true;
      label44.Location = new Point(81, 62);
      label44.Margin = new Padding(1, 0, 1, 0);
      label44.Name = "label44";
      label44.Size = new Size(26, 25);
      label44.TabIndex = 5;
      label44.Text = "Y:";
      // 
      // numericUpDownX
      // 
      numericUpDownX.DecimalPlaces = 5;
      numericUpDownX.Increment = new decimal(new int[] { 1, 0, 0, 65536 });
      numericUpDownX.Location = new Point(114, 22);
      numericUpDownX.Margin = new Padding(1, 2, 1, 2);
      numericUpDownX.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
      numericUpDownX.Minimum = new decimal(new int[] { 10000, 0, 0, int.MinValue });
      numericUpDownX.Name = "numericUpDownX";
      numericUpDownX.Size = new Size(121, 31);
      numericUpDownX.TabIndex = 4;
      // 
      // label42
      // 
      label42.AutoSize = true;
      label42.Location = new Point(81, 23);
      label42.Margin = new Padding(1, 0, 1, 0);
      label42.Name = "label42";
      label42.Size = new Size(27, 25);
      label42.TabIndex = 3;
      label42.Text = "X:";
      // 
      // buttonChangeNav
      // 
      buttonChangeNav.Enabled = false;
      buttonChangeNav.FlatStyle = FlatStyle.Flat;
      buttonChangeNav.Location = new Point(370, 285);
      buttonChangeNav.Margin = new Padding(1, 2, 1, 2);
      buttonChangeNav.Name = "buttonChangeNav";
      buttonChangeNav.Size = new Size(136, 33);
      buttonChangeNav.TabIndex = 2;
      buttonChangeNav.Text = "ChangeNav";
      buttonChangeNav.UseVisualStyleBackColor = true;
      buttonChangeNav.Click += buttonChangeNav_Click;
      // 
      // buttonSendGoHome
      // 
      buttonSendGoHome.Enabled = false;
      buttonSendGoHome.FlatStyle = FlatStyle.Flat;
      buttonSendGoHome.Location = new Point(250, 285);
      buttonSendGoHome.Margin = new Padding(1, 2, 1, 2);
      buttonSendGoHome.Name = "buttonSendGoHome";
      buttonSendGoHome.Size = new Size(111, 33);
      buttonSendGoHome.TabIndex = 1;
      buttonSendGoHome.Text = "GoHome";
      buttonSendGoHome.UseVisualStyleBackColor = true;
      buttonSendGoHome.Click += buttonSendGoHome_Click;
      // 
      // buttonSendLand
      // 
      buttonSendLand.Enabled = false;
      buttonSendLand.FlatStyle = FlatStyle.Flat;
      buttonSendLand.Location = new Point(130, 285);
      buttonSendLand.Margin = new Padding(1, 2, 1, 2);
      buttonSendLand.Name = "buttonSendLand";
      buttonSendLand.Size = new Size(111, 33);
      buttonSendLand.TabIndex = 0;
      buttonSendLand.Text = "Land";
      buttonSendLand.UseVisualStyleBackColor = true;
      buttonSendLand.Click += buttonSendLand_Click;
      // 
      // ConnectionBox
      // 
      ConnectionBox.BackColor = Color.Transparent;
      ConnectionBox.Controls.Add(ConnectionsPages);
      ConnectionBox.ForeColor = Color.Black;
      ConnectionBox.Location = new Point(0, 27);
      ConnectionBox.Margin = new Padding(4, 3, 4, 3);
      ConnectionBox.Name = "ConnectionBox";
      ConnectionBox.Padding = new Padding(4, 3, 4, 3);
      ConnectionBox.Size = new Size(661, 227);
      ConnectionBox.TabIndex = 0;
      ConnectionBox.TabStop = false;
      ConnectionBox.Text = "Connection settings";
      // 
      // ConnectionsPages
      // 
      ConnectionsPages.Controls.Add(PipeLinePage);
      ConnectionsPages.Controls.Add(ComPage);
      ConnectionsPages.Font = new Font("Segoe UI", 9F);
      ConnectionsPages.Location = new Point(9, 38);
      ConnectionsPages.Margin = new Padding(4, 3, 4, 3);
      ConnectionsPages.Name = "ConnectionsPages";
      ConnectionsPages.SelectedIndex = 0;
      ConnectionsPages.Size = new Size(630, 168);
      ConnectionsPages.TabIndex = 0;
      // 
      // PipeLinePage
      // 
      PipeLinePage.Controls.Add(AddressPipeLine);
      PipeLinePage.Controls.Add(PipeLineConnect);
      PipeLinePage.Controls.Add(label1);
      PipeLinePage.Location = new Point(4, 34);
      PipeLinePage.Margin = new Padding(4, 3, 4, 3);
      PipeLinePage.Name = "PipeLinePage";
      PipeLinePage.Padding = new Padding(4, 3, 4, 3);
      PipeLinePage.Size = new Size(622, 130);
      PipeLinePage.TabIndex = 0;
      PipeLinePage.Text = "PipeLine";
      PipeLinePage.UseVisualStyleBackColor = true;
      // 
      // AddressPipeLine
      // 
      AddressPipeLine.Location = new Point(74, 42);
      AddressPipeLine.Margin = new Padding(4, 3, 4, 3);
      AddressPipeLine.Name = "AddressPipeLine";
      AddressPipeLine.Size = new Size(390, 31);
      AddressPipeLine.TabIndex = 2;
      AddressPipeLine.Text = "Drone";
      // 
      // PipeLineConnect
      // 
      PipeLineConnect.FlatStyle = FlatStyle.Flat;
      PipeLineConnect.Location = new Point(471, 35);
      PipeLineConnect.Margin = new Padding(4, 3, 4, 3);
      PipeLineConnect.Name = "PipeLineConnect";
      PipeLineConnect.Size = new Size(140, 42);
      PipeLineConnect.TabIndex = 1;
      PipeLineConnect.Text = "Connect";
      PipeLineConnect.UseVisualStyleBackColor = true;
      PipeLineConnect.Click += PipeLineConnect_Click;
      // 
      // label1
      // 
      label1.AutoSize = true;
      label1.Location = new Point(9, 43);
      label1.Margin = new Padding(4, 0, 4, 0);
      label1.Name = "label1";
      label1.Size = new Size(61, 25);
      label1.TabIndex = 0;
      label1.Text = "Addr: ";
      // 
      // ComPage
      // 
      ComPage.Controls.Add(BAUDBOX);
      ComPage.Controls.Add(COMBOX);
      ComPage.Controls.Add(label3);
      ComPage.Controls.Add(label2);
      ComPage.Controls.Add(COMConnect);
      ComPage.Location = new Point(4, 34);
      ComPage.Margin = new Padding(4, 3, 4, 3);
      ComPage.Name = "ComPage";
      ComPage.Padding = new Padding(4, 3, 4, 3);
      ComPage.Size = new Size(622, 130);
      ComPage.TabIndex = 1;
      ComPage.Text = "COM";
      ComPage.UseVisualStyleBackColor = true;
      // 
      // BAUDBOX
      // 
      BAUDBOX.FormattingEnabled = true;
      BAUDBOX.Items.AddRange(new object[] { "9600", "34800", "57600", "115200", "230400" });
      BAUDBOX.Location = new Point(99, 72);
      BAUDBOX.Margin = new Padding(4, 3, 4, 3);
      BAUDBOX.Name = "BAUDBOX";
      BAUDBOX.Size = new Size(310, 33);
      BAUDBOX.TabIndex = 4;
      BAUDBOX.Text = "115200";
      // 
      // COMBOX
      // 
      COMBOX.DropDownStyle = ComboBoxStyle.DropDownList;
      COMBOX.FormattingEnabled = true;
      COMBOX.Location = new Point(100, 20);
      COMBOX.Margin = new Padding(4, 3, 4, 3);
      COMBOX.Name = "COMBOX";
      COMBOX.Size = new Size(310, 33);
      COMBOX.TabIndex = 3;
      COMBOX.DropDown += COMBOX_DropDown;
      // 
      // label3
      // 
      label3.AutoSize = true;
      label3.Location = new Point(21, 72);
      label3.Margin = new Padding(4, 0, 4, 0);
      label3.Name = "label3";
      label3.Size = new Size(56, 25);
      label3.TabIndex = 2;
      label3.Text = "Baud:";
      // 
      // label2
      // 
      label2.AutoSize = true;
      label2.Location = new Point(21, 23);
      label2.Margin = new Padding(4, 0, 4, 0);
      label2.Name = "label2";
      label2.Size = new Size(57, 25);
      label2.TabIndex = 1;
      label2.Text = "COM:";
      // 
      // COMConnect
      // 
      COMConnect.FlatStyle = FlatStyle.Flat;
      COMConnect.Location = new Point(441, 45);
      COMConnect.Margin = new Padding(4, 3, 4, 3);
      COMConnect.Name = "COMConnect";
      COMConnect.Size = new Size(166, 42);
      COMConnect.TabIndex = 0;
      COMConnect.Text = "Connect";
      COMConnect.UseVisualStyleBackColor = true;
      COMConnect.Click += COMConnect_Click;
      // 
      // groupBoxGraph
      // 
      groupBoxGraph.BackColor = Color.Transparent;
      groupBoxGraph.Controls.Add(checkBox_Graph_Live);
      groupBoxGraph.Controls.Add(button_Graph_Fixed);
      groupBoxGraph.Controls.Add(numericUpDown_Graph_Interval);
      groupBoxGraph.Controls.Add(label6);
      groupBoxGraph.Controls.Add(checkBox_Graph_Auto);
      groupBoxGraph.Controls.Add(numericUpDown_Graph_Scale);
      groupBoxGraph.Controls.Add(checkBox_Graph_Scale);
      groupBoxGraph.Controls.Add(numericUpDown_Graph_Max);
      groupBoxGraph.Controls.Add(numericUpDown_Graph_Min);
      groupBoxGraph.Controls.Add(label5);
      groupBoxGraph.Controls.Add(numericUpDown_Graph_Time);
      groupBoxGraph.Controls.Add(label4);
      groupBoxGraph.Font = new Font("Segoe UI", 9F);
      groupBoxGraph.Location = new Point(666, 132);
      groupBoxGraph.Margin = new Padding(4, 3, 4, 3);
      groupBoxGraph.Name = "groupBoxGraph";
      groupBoxGraph.Padding = new Padding(4, 3, 4, 3);
      groupBoxGraph.Size = new Size(1004, 120);
      groupBoxGraph.TabIndex = 3;
      groupBoxGraph.TabStop = false;
      groupBoxGraph.Text = "Graph settings";
      // 
      // checkBox_Graph_Live
      // 
      checkBox_Graph_Live.AutoSize = true;
      checkBox_Graph_Live.Checked = true;
      checkBox_Graph_Live.CheckState = CheckState.Checked;
      checkBox_Graph_Live.Location = new Point(749, 78);
      checkBox_Graph_Live.Margin = new Padding(4, 3, 4, 3);
      checkBox_Graph_Live.Name = "checkBox_Graph_Live";
      checkBox_Graph_Live.Size = new Size(71, 29);
      checkBox_Graph_Live.TabIndex = 11;
      checkBox_Graph_Live.Text = "LIVE";
      checkBox_Graph_Live.UseVisualStyleBackColor = true;
      // 
      // button_Graph_Fixed
      // 
      button_Graph_Fixed.BackColor = Color.WhiteSmoke;
      button_Graph_Fixed.FlatStyle = FlatStyle.Flat;
      button_Graph_Fixed.Location = new Point(566, 75);
      button_Graph_Fixed.Margin = new Padding(4, 3, 4, 3);
      button_Graph_Fixed.Name = "button_Graph_Fixed";
      button_Graph_Fixed.Size = new Size(91, 38);
      button_Graph_Fixed.TabIndex = 10;
      button_Graph_Fixed.Text = "Fixed";
      button_Graph_Fixed.UseVisualStyleBackColor = false;
      button_Graph_Fixed.Click += button_Graph_Fixed_Click;
      // 
      // numericUpDown_Graph_Interval
      // 
      numericUpDown_Graph_Interval.DecimalPlaces = 5;
      numericUpDown_Graph_Interval.Location = new Point(294, 78);
      numericUpDown_Graph_Interval.Margin = new Padding(4, 3, 4, 3);
      numericUpDown_Graph_Interval.Minimum = new decimal(new int[] { 1, 0, 0, 327680 });
      numericUpDown_Graph_Interval.Name = "numericUpDown_Graph_Interval";
      numericUpDown_Graph_Interval.Size = new Size(264, 31);
      numericUpDown_Graph_Interval.TabIndex = 9;
      numericUpDown_Graph_Interval.Value = new decimal(new int[] { 1, 0, 0, 0 });
      numericUpDown_Graph_Interval.ValueChanged += numericUpDown_Graph_Min_ValueChanged;
      // 
      // label6
      // 
      label6.AutoSize = true;
      label6.Location = new Point(211, 78);
      label6.Margin = new Padding(4, 0, 4, 0);
      label6.Name = "label6";
      label6.Size = new Size(74, 25);
      label6.TabIndex = 8;
      label6.Text = "Interval:";
      // 
      // checkBox_Graph_Auto
      // 
      checkBox_Graph_Auto.AutoSize = true;
      checkBox_Graph_Auto.Location = new Point(14, 80);
      checkBox_Graph_Auto.Margin = new Padding(4, 3, 4, 3);
      checkBox_Graph_Auto.Name = "checkBox_Graph_Auto";
      checkBox_Graph_Auto.Size = new Size(92, 29);
      checkBox_Graph_Auto.TabIndex = 7;
      checkBox_Graph_Auto.Text = "Auto Y";
      checkBox_Graph_Auto.UseVisualStyleBackColor = true;
      checkBox_Graph_Auto.CheckedChanged += numericUpDown_Graph_Min_ValueChanged;
      // 
      // numericUpDown_Graph_Scale
      // 
      numericUpDown_Graph_Scale.Location = new Point(854, 37);
      numericUpDown_Graph_Scale.Margin = new Padding(4, 3, 4, 3);
      numericUpDown_Graph_Scale.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
      numericUpDown_Graph_Scale.Name = "numericUpDown_Graph_Scale";
      numericUpDown_Graph_Scale.Size = new Size(121, 31);
      numericUpDown_Graph_Scale.TabIndex = 6;
      numericUpDown_Graph_Scale.Value = new decimal(new int[] { 1, 0, 0, 0 });
      // 
      // checkBox_Graph_Scale
      // 
      checkBox_Graph_Scale.AutoSize = true;
      checkBox_Graph_Scale.Checked = true;
      checkBox_Graph_Scale.CheckState = CheckState.Checked;
      checkBox_Graph_Scale.Location = new Point(749, 37);
      checkBox_Graph_Scale.Margin = new Padding(4, 3, 4, 3);
      checkBox_Graph_Scale.Name = "checkBox_Graph_Scale";
      checkBox_Graph_Scale.Size = new Size(97, 29);
      checkBox_Graph_Scale.TabIndex = 5;
      checkBox_Graph_Scale.Text = "Scale Y:";
      checkBox_Graph_Scale.UseVisualStyleBackColor = true;
      // 
      // numericUpDown_Graph_Max
      // 
      numericUpDown_Graph_Max.Location = new Point(466, 33);
      numericUpDown_Graph_Max.Margin = new Padding(4, 3, 4, 3);
      numericUpDown_Graph_Max.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
      numericUpDown_Graph_Max.Minimum = new decimal(new int[] { 1000000, 0, 0, int.MinValue });
      numericUpDown_Graph_Max.Name = "numericUpDown_Graph_Max";
      numericUpDown_Graph_Max.Size = new Size(91, 31);
      numericUpDown_Graph_Max.TabIndex = 4;
      numericUpDown_Graph_Max.Value = new decimal(new int[] { 10, 0, 0, 0 });
      numericUpDown_Graph_Max.ValueChanged += numericUpDown_Graph_Min_ValueChanged;
      // 
      // numericUpDown_Graph_Min
      // 
      numericUpDown_Graph_Min.Location = new Point(350, 33);
      numericUpDown_Graph_Min.Margin = new Padding(4, 3, 4, 3);
      numericUpDown_Graph_Min.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
      numericUpDown_Graph_Min.Minimum = new decimal(new int[] { 1000000, 0, 0, int.MinValue });
      numericUpDown_Graph_Min.Name = "numericUpDown_Graph_Min";
      numericUpDown_Graph_Min.Size = new Size(91, 31);
      numericUpDown_Graph_Min.TabIndex = 3;
      numericUpDown_Graph_Min.Value = new decimal(new int[] { 10, 0, 0, int.MinValue });
      numericUpDown_Graph_Min.ValueChanged += numericUpDown_Graph_Min_ValueChanged;
      // 
      // label5
      // 
      label5.AutoSize = true;
      label5.Location = new Point(284, 37);
      label5.Margin = new Padding(4, 0, 4, 0);
      label5.Name = "label5";
      label5.Size = new Size(58, 25);
      label5.TabIndex = 2;
      label5.Text = "Value:";
      // 
      // numericUpDown_Graph_Time
      // 
      numericUpDown_Graph_Time.Location = new Point(79, 33);
      numericUpDown_Graph_Time.Margin = new Padding(4, 3, 4, 3);
      numericUpDown_Graph_Time.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
      numericUpDown_Graph_Time.Name = "numericUpDown_Graph_Time";
      numericUpDown_Graph_Time.Size = new Size(71, 31);
      numericUpDown_Graph_Time.TabIndex = 1;
      numericUpDown_Graph_Time.Value = new decimal(new int[] { 10, 0, 0, 0 });
      // 
      // label4
      // 
      label4.AutoSize = true;
      label4.Location = new Point(14, 38);
      label4.Margin = new Padding(4, 0, 4, 0);
      label4.Name = "label4";
      label4.Size = new Size(55, 25);
      label4.TabIndex = 0;
      label4.Text = "Track:";
      // 
      // tabControl1
      // 
      tabControl1.Controls.Add(Telemetry);
      tabControl1.Controls.Add(tabPageSettings);
      tabControl1.Controls.Add(MagColibration);
      tabControl1.Controls.Add(AccColib);
      tabControl1.Dock = DockStyle.Fill;
      tabControl1.Font = new Font("Segoe UI", 9F);
      tabControl1.Location = new Point(0, 0);
      tabControl1.Margin = new Padding(4, 3, 4, 3);
      tabControl1.Name = "tabControl1";
      tabControl1.SelectedIndex = 0;
      tabControl1.Size = new Size(1694, 1055);
      tabControl1.TabIndex = 7;
      tabControl1.SelectedIndexChanged += tabControl1_SelectedIndexChanged;
      // 
      // Telemetry
      // 
      Telemetry.Controls.Add(panel3);
      Telemetry.Location = new Point(4, 34);
      Telemetry.Margin = new Padding(4, 3, 4, 3);
      Telemetry.Name = "Telemetry";
      Telemetry.Padding = new Padding(4, 3, 4, 3);
      Telemetry.Size = new Size(1686, 1017);
      Telemetry.TabIndex = 0;
      Telemetry.Text = "Telemtry";
      Telemetry.UseVisualStyleBackColor = true;
      // 
      // panel3
      // 
      panel3.Controls.Add(panel1);
      panel3.Controls.Add(panel2);
      panel3.Controls.Add(groupBox3);
      panel3.Dock = DockStyle.Fill;
      panel3.Location = new Point(4, 3);
      panel3.Margin = new Padding(4, 3, 4, 3);
      panel3.Name = "panel3";
      panel3.Size = new Size(1678, 1011);
      panel3.TabIndex = 10;
      // 
      // panel1
      // 
      panel1.Controls.Add(panel10);
      panel1.Controls.Add(gMapControl1);
      panel1.Controls.Add(chart_Graph);
      panel1.Dock = DockStyle.Fill;
      panel1.Location = new Point(661, 253);
      panel1.Margin = new Padding(6, 7, 6, 7);
      panel1.Name = "panel1";
      panel1.Size = new Size(1017, 758);
      panel1.TabIndex = 6;
      // 
      // panel10
      // 
      panel10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
      panel10.AutoScroll = true;
      panel10.Location = new Point(763, 3);
      panel10.Name = "panel10";
      panel10.Size = new Size(250, 750);
      panel10.TabIndex = 2;
      // 
      // gMapControl1
      // 
      gMapControl1.BackColor = Color.Transparent;
      gMapControl1.Bearing = 0F;
      gMapControl1.CanDragMap = true;
      gMapControl1.Dock = DockStyle.Fill;
      gMapControl1.EmptyTileColor = Color.Black;
      gMapControl1.Font = new Font("Times New Roman", 14F, FontStyle.Bold);
      gMapControl1.GrayScaleMode = false;
      gMapControl1.HelperLineOption = GMap.NET.WindowsForms.HelperLineOptions.DontShow;
      gMapControl1.LevelsKeepInMemory = 5;
      gMapControl1.Location = new Point(0, 0);
      gMapControl1.MarkersEnabled = true;
      gMapControl1.MaxZoom = 2;
      gMapControl1.MinZoom = 2;
      gMapControl1.MouseWheelZoomEnabled = true;
      gMapControl1.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter;
      gMapControl1.Name = "gMapControl1";
      gMapControl1.NegativeMode = false;
      gMapControl1.PolygonsEnabled = true;
      gMapControl1.RetryLoadTile = 0;
      gMapControl1.RoutesEnabled = true;
      gMapControl1.ScaleMode = GMap.NET.WindowsForms.ScaleModes.Integer;
      gMapControl1.SelectedAreaFillColor = Color.Transparent;
      gMapControl1.ShowTileGridLines = false;
      gMapControl1.Size = new Size(1017, 758);
      gMapControl1.TabIndex = 1;
      gMapControl1.Visible = false;
      gMapControl1.Zoom = 0D;
      gMapControl1.OnMapClick += gMapControl1_OnMapClick;
      gMapControl1.OnMarkerClick += gMapControl1_OnMarkerClick;
      gMapControl1.OnMarkerEnter += gMapControl1_OnMarkerEnter;
      gMapControl1.OnMarkerLeave += gMapControl1_OnMarkerLeave;
      gMapControl1.Load += gMapControl1_Load;
      gMapControl1.KeyPress += gMapControl1_KeyPress;
      gMapControl1.MouseDown += gMapControl1_MouseDown;
      gMapControl1.MouseMove += gMapControl1_MouseMove;
      gMapControl1.MouseUp += gMapControl1_MouseUp;
      // 
      // chart_Graph
      // 
      chartArea2.AxisX.Interval = 1D;
      chartArea2.AxisX.IntervalType = DateTimeIntervalType.Seconds;
      chartArea2.AxisX.LabelStyle.Format = "ss";
      chartArea2.AxisY.Interval = 10D;
      chartArea2.AxisY.IntervalOffset = 1D;
      chartArea2.Name = "ChartArea1";
      chart_Graph.ChartAreas.Add(chartArea2);
      chart_Graph.Dock = DockStyle.Fill;
      legend2.Name = "Legend1";
      chart_Graph.Legends.Add(legend2);
      chart_Graph.Location = new Point(0, 0);
      chart_Graph.Margin = new Padding(6, 7, 6, 7);
      chart_Graph.Name = "chart_Graph";
      chart_Graph.Size = new Size(1017, 758);
      chart_Graph.TabIndex = 0;
      chart_Graph.Text = "chart1";
      // 
      // panel2
      // 
      panel2.Controls.Add(panel6);
      panel2.Controls.Add(groupBox4);
      panel2.Dock = DockStyle.Left;
      panel2.Location = new Point(0, 253);
      panel2.Margin = new Padding(6, 7, 6, 7);
      panel2.Name = "panel2";
      panel2.Size = new Size(661, 758);
      panel2.TabIndex = 7;
      // 
      // panel6
      // 
      panel6.AutoScroll = true;
      panel6.BackColor = Color.Transparent;
      panel6.Controls.Add(groupBox5);
      panel6.Dock = DockStyle.Top;
      panel6.Location = new Point(0, 413);
      panel6.Margin = new Padding(1, 2, 1, 2);
      panel6.Name = "panel6";
      panel6.Size = new Size(661, 413);
      panel6.TabIndex = 8;
      // 
      // groupBox5
      // 
      groupBox5.BackColor = Color.Transparent;
      groupBox5.Controls.Add(label38);
      groupBox5.Controls.Add(HzRecvTelem);
      groupBox5.Controls.Add(SPDRX);
      groupBox5.Controls.Add(label30);
      groupBox5.Controls.Add(TelemBaroAlt);
      groupBox5.Controls.Add(label59);
      groupBox5.Controls.Add(TelemYawVel);
      groupBox5.Controls.Add(label57);
      groupBox5.Controls.Add(TelemPitchVel);
      groupBox5.Controls.Add(label55);
      groupBox5.Controls.Add(TelemRollVel);
      groupBox5.Controls.Add(label53);
      groupBox5.Controls.Add(TelemYaw);
      groupBox5.Controls.Add(label51);
      groupBox5.Controls.Add(TelemPitch);
      groupBox5.Controls.Add(label49);
      groupBox5.Controls.Add(TelemRoll);
      groupBox5.Controls.Add(label47);
      groupBox5.Controls.Add(TelemSpeedINS);
      groupBox5.Controls.Add(label45);
      groupBox5.Controls.Add(TelemHeadingDeg);
      groupBox5.Controls.Add(label43);
      groupBox5.Controls.Add(TelemZ);
      groupBox5.Controls.Add(label41);
      groupBox5.Controls.Add(TelemY);
      groupBox5.Controls.Add(label34);
      groupBox5.Controls.Add(TelemX);
      groupBox5.Controls.Add(label26);
      groupBox5.Controls.Add(TelemTimeUTC);
      groupBox5.Controls.Add(label40);
      groupBox5.Controls.Add(TelemGPSFixType);
      groupBox5.Controls.Add(label36);
      groupBox5.Controls.Add(TelemGPSspeed);
      groupBox5.Controls.Add(label32);
      groupBox5.Controls.Add(TelemSatUsed);
      groupBox5.Controls.Add(label28);
      groupBox5.Controls.Add(TelemSatVisible);
      groupBox5.Controls.Add(label24);
      groupBox5.Controls.Add(TelemJamming);
      groupBox5.Controls.Add(label39);
      groupBox5.Controls.Add(TelemNoise);
      groupBox5.Controls.Add(label37);
      groupBox5.Controls.Add(TelemPdop);
      groupBox5.Controls.Add(label35);
      groupBox5.Controls.Add(TelemVdop);
      groupBox5.Controls.Add(label33);
      groupBox5.Controls.Add(TelemHdop);
      groupBox5.Controls.Add(label31);
      groupBox5.Controls.Add(TelemRealAlt);
      groupBox5.Controls.Add(label29);
      groupBox5.Controls.Add(TelemAbsAlt);
      groupBox5.Controls.Add(label27);
      groupBox5.Controls.Add(TelemLon);
      groupBox5.Controls.Add(label25);
      groupBox5.Controls.Add(TelemLat);
      groupBox5.Controls.Add(label20);
      groupBox5.Controls.Add(TelemTempBaro);
      groupBox5.Controls.Add(label22);
      groupBox5.Controls.Add(TelemPressureBaro);
      groupBox5.Controls.Add(label18);
      groupBox5.Controls.Add(TelemTimeRemBat);
      groupBox5.Controls.Add(label16);
      groupBox5.Controls.Add(TelemTotalPower);
      groupBox5.Controls.Add(label23);
      groupBox5.Controls.Add(TelemBatTemp);
      groupBox5.Controls.Add(label21);
      groupBox5.Controls.Add(TelemAmperageBat);
      groupBox5.Controls.Add(label19);
      groupBox5.Controls.Add(TelemVoltageBat);
      groupBox5.Controls.Add(label17);
      groupBox5.Controls.Add(TelemPerCharge);
      groupBox5.Controls.Add(label15);
      groupBox5.Controls.Add(TelemEngineCount);
      groupBox5.Controls.Add(label14);
      groupBox5.Controls.Add(TelemEngineStatus);
      groupBox5.Controls.Add(label13);
      groupBox5.Controls.Add(TelemNavSys);
      groupBox5.Controls.Add(label12);
      groupBox5.Controls.Add(TelemStatusMode);
      groupBox5.Controls.Add(label11);
      groupBox5.Controls.Add(TelemMode);
      groupBox5.Controls.Add(label9);
      groupBox5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      groupBox5.Location = new Point(4, 2);
      groupBox5.Margin = new Padding(4, 3, 4, 3);
      groupBox5.Name = "groupBox5";
      groupBox5.Padding = new Padding(4, 3, 4, 3);
      groupBox5.Size = new Size(659, 700);
      groupBox5.TabIndex = 7;
      groupBox5.TabStop = false;
      groupBox5.Text = "Total telemetry";
      // 
      // label38
      // 
      label38.AutoSize = true;
      label38.Location = new Point(289, 662);
      label38.Margin = new Padding(4, 0, 4, 0);
      label38.Name = "label38";
      label38.Size = new Size(135, 25);
      label38.TabIndex = 82;
      label38.Text = "Freq recv msg:";
      // 
      // SPDRX
      // 
      SPDRX.AutoSize = true;
      SPDRX.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      SPDRX.Location = new Point(426, 632);
      SPDRX.Margin = new Padding(4, 0, 4, 0);
      SPDRX.Name = "SPDRX";
      SPDRX.Size = new Size(22, 25);
      SPDRX.TabIndex = 79;
      SPDRX.Text = "0";
      // 
      // label30
      // 
      label30.AutoSize = true;
      label30.Location = new Point(351, 632);
      label30.Margin = new Padding(4, 0, 4, 0);
      label30.Name = "label30";
      label30.Size = new Size(69, 25);
      label30.TabIndex = 78;
      label30.Text = "spd rx:";
      // 
      // TelemBaroAlt
      // 
      TelemBaroAlt.AutoSize = true;
      TelemBaroAlt.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemBaroAlt.Location = new Point(426, 598);
      TelemBaroAlt.Margin = new Padding(4, 0, 4, 0);
      TelemBaroAlt.Name = "TelemBaroAlt";
      TelemBaroAlt.Size = new Size(44, 25);
      TelemBaroAlt.TabIndex = 77;
      TelemBaroAlt.Text = "null";
      // 
      // label59
      // 
      label59.AutoSize = true;
      label59.Location = new Point(341, 598);
      label59.Margin = new Padding(4, 0, 4, 0);
      label59.Name = "label59";
      label59.Size = new Size(81, 25);
      label59.TabIndex = 76;
      label59.Text = "baroAlt:";
      // 
      // TelemYawVel
      // 
      TelemYawVel.AutoSize = true;
      TelemYawVel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemYawVel.Location = new Point(426, 568);
      TelemYawVel.Margin = new Padding(4, 0, 4, 0);
      TelemYawVel.Name = "TelemYawVel";
      TelemYawVel.Size = new Size(44, 25);
      TelemYawVel.TabIndex = 75;
      TelemYawVel.Text = "null";
      // 
      // label57
      // 
      label57.AutoSize = true;
      label57.Location = new Point(349, 568);
      label57.Margin = new Padding(4, 0, 4, 0);
      label57.Name = "label57";
      label57.Size = new Size(77, 25);
      label57.TabIndex = 74;
      label57.Text = "yawVel:";
      // 
      // TelemPitchVel
      // 
      TelemPitchVel.AutoSize = true;
      TelemPitchVel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemPitchVel.Location = new Point(426, 538);
      TelemPitchVel.Margin = new Padding(4, 0, 4, 0);
      TelemPitchVel.Name = "TelemPitchVel";
      TelemPitchVel.Size = new Size(44, 25);
      TelemPitchVel.TabIndex = 73;
      TelemPitchVel.Text = "null";
      // 
      // label55
      // 
      label55.AutoSize = true;
      label55.Location = new Point(339, 538);
      label55.Margin = new Padding(4, 0, 4, 0);
      label55.Name = "label55";
      label55.Size = new Size(86, 25);
      label55.TabIndex = 72;
      label55.Text = "pitchVel:";
      // 
      // TelemRollVel
      // 
      TelemRollVel.AutoSize = true;
      TelemRollVel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemRollVel.Location = new Point(426, 505);
      TelemRollVel.Margin = new Padding(4, 0, 4, 0);
      TelemRollVel.Name = "TelemRollVel";
      TelemRollVel.Size = new Size(44, 25);
      TelemRollVel.TabIndex = 71;
      TelemRollVel.Text = "null";
      // 
      // label53
      // 
      label53.AutoSize = true;
      label53.Location = new Point(351, 505);
      label53.Margin = new Padding(4, 0, 4, 0);
      label53.Name = "label53";
      label53.Size = new Size(71, 25);
      label53.TabIndex = 70;
      label53.Text = "rollVel:";
      // 
      // TelemYaw
      // 
      TelemYaw.AutoSize = true;
      TelemYaw.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemYaw.Location = new Point(426, 473);
      TelemYaw.Margin = new Padding(4, 0, 4, 0);
      TelemYaw.Name = "TelemYaw";
      TelemYaw.Size = new Size(44, 25);
      TelemYaw.TabIndex = 69;
      TelemYaw.Text = "null";
      // 
      // label51
      // 
      label51.AutoSize = true;
      label51.Location = new Point(370, 473);
      label51.Margin = new Padding(4, 0, 4, 0);
      label51.Name = "label51";
      label51.Size = new Size(51, 25);
      label51.TabIndex = 68;
      label51.Text = "yaw:";
      // 
      // TelemPitch
      // 
      TelemPitch.AutoSize = true;
      TelemPitch.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemPitch.Location = new Point(426, 442);
      TelemPitch.Margin = new Padding(4, 0, 4, 0);
      TelemPitch.Name = "TelemPitch";
      TelemPitch.Size = new Size(44, 25);
      TelemPitch.TabIndex = 67;
      TelemPitch.Text = "null";
      // 
      // label49
      // 
      label49.AutoSize = true;
      label49.Location = new Point(361, 442);
      label49.Margin = new Padding(4, 0, 4, 0);
      label49.Name = "label49";
      label49.Size = new Size(60, 25);
      label49.TabIndex = 66;
      label49.Text = "pitch:";
      // 
      // TelemRoll
      // 
      TelemRoll.AutoSize = true;
      TelemRoll.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemRoll.Location = new Point(426, 412);
      TelemRoll.Margin = new Padding(4, 0, 4, 0);
      TelemRoll.Name = "TelemRoll";
      TelemRoll.Size = new Size(44, 25);
      TelemRoll.TabIndex = 65;
      TelemRoll.Text = "null";
      // 
      // label47
      // 
      label47.AutoSize = true;
      label47.Location = new Point(376, 412);
      label47.Margin = new Padding(4, 0, 4, 0);
      label47.Name = "label47";
      label47.Size = new Size(45, 25);
      label47.TabIndex = 64;
      label47.Text = "roll:";
      // 
      // TelemSpeedINS
      // 
      TelemSpeedINS.AutoSize = true;
      TelemSpeedINS.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemSpeedINS.Location = new Point(426, 382);
      TelemSpeedINS.Margin = new Padding(4, 0, 4, 0);
      TelemSpeedINS.Name = "TelemSpeedINS";
      TelemSpeedINS.Size = new Size(44, 25);
      TelemSpeedINS.TabIndex = 63;
      TelemSpeedINS.Text = "null";
      // 
      // label45
      // 
      label45.AutoSize = true;
      label45.Location = new Point(351, 382);
      label45.Margin = new Padding(4, 0, 4, 0);
      label45.Name = "label45";
      label45.Size = new Size(67, 25);
      label45.TabIndex = 62;
      label45.Text = "speed:";
      // 
      // TelemHeadingDeg
      // 
      TelemHeadingDeg.AutoSize = true;
      TelemHeadingDeg.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemHeadingDeg.Location = new Point(426, 348);
      TelemHeadingDeg.Margin = new Padding(4, 0, 4, 0);
      TelemHeadingDeg.Name = "TelemHeadingDeg";
      TelemHeadingDeg.Size = new Size(44, 25);
      TelemHeadingDeg.TabIndex = 61;
      TelemHeadingDeg.Text = "null";
      // 
      // label43
      // 
      label43.AutoSize = true;
      label43.Location = new Point(304, 348);
      label43.Margin = new Padding(4, 0, 4, 0);
      label43.Name = "label43";
      label43.Size = new Size(120, 25);
      label43.TabIndex = 60;
      label43.Text = "headingDeg:";
      // 
      // TelemZ
      // 
      TelemZ.AutoSize = true;
      TelemZ.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemZ.Location = new Point(426, 318);
      TelemZ.Margin = new Padding(4, 0, 4, 0);
      TelemZ.Name = "TelemZ";
      TelemZ.Size = new Size(44, 25);
      TelemZ.TabIndex = 59;
      TelemZ.Text = "null";
      // 
      // label41
      // 
      label41.AutoSize = true;
      label41.Location = new Point(391, 318);
      label41.Margin = new Padding(4, 0, 4, 0);
      label41.Name = "label41";
      label41.Size = new Size(26, 25);
      label41.TabIndex = 58;
      label41.Text = "z:";
      // 
      // TelemY
      // 
      TelemY.AutoSize = true;
      TelemY.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemY.Location = new Point(426, 288);
      TelemY.Margin = new Padding(4, 0, 4, 0);
      TelemY.Name = "TelemY";
      TelemY.Size = new Size(44, 25);
      TelemY.TabIndex = 57;
      TelemY.Text = "null";
      // 
      // label34
      // 
      label34.AutoSize = true;
      label34.Location = new Point(391, 288);
      label34.Margin = new Padding(4, 0, 4, 0);
      label34.Name = "label34";
      label34.Size = new Size(27, 25);
      label34.TabIndex = 56;
      label34.Text = "y:";
      // 
      // TelemX
      // 
      TelemX.AutoSize = true;
      TelemX.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemX.Location = new Point(426, 255);
      TelemX.Margin = new Padding(4, 0, 4, 0);
      TelemX.Name = "TelemX";
      TelemX.Size = new Size(44, 25);
      TelemX.TabIndex = 55;
      TelemX.Text = "null";
      // 
      // label26
      // 
      label26.AutoSize = true;
      label26.Location = new Point(391, 255);
      label26.Margin = new Padding(4, 0, 4, 0);
      label26.Name = "label26";
      label26.Size = new Size(27, 25);
      label26.TabIndex = 54;
      label26.Text = "x:";
      // 
      // TelemTimeUTC
      // 
      TelemTimeUTC.AutoSize = true;
      TelemTimeUTC.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemTimeUTC.Location = new Point(131, 662);
      TelemTimeUTC.Margin = new Padding(4, 0, 4, 0);
      TelemTimeUTC.Name = "TelemTimeUTC";
      TelemTimeUTC.Size = new Size(44, 25);
      TelemTimeUTC.TabIndex = 53;
      TelemTimeUTC.Text = "null";
      // 
      // label40
      // 
      label40.AutoSize = true;
      label40.Location = new Point(9, 662);
      label40.Margin = new Padding(4, 0, 4, 0);
      label40.Name = "label40";
      label40.Size = new Size(89, 25);
      label40.TabIndex = 52;
      label40.Text = "timeUTC:";
      // 
      // TelemGPSFixType
      // 
      TelemGPSFixType.AutoSize = true;
      TelemGPSFixType.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemGPSFixType.Location = new Point(131, 632);
      TelemGPSFixType.Margin = new Padding(4, 0, 4, 0);
      TelemGPSFixType.Name = "TelemGPSFixType";
      TelemGPSFixType.Size = new Size(44, 25);
      TelemGPSFixType.TabIndex = 51;
      TelemGPSFixType.Text = "null";
      // 
      // label36
      // 
      label36.AutoSize = true;
      label36.Location = new Point(9, 632);
      label36.Margin = new Padding(4, 0, 4, 0);
      label36.Name = "label36";
      label36.Size = new Size(80, 25);
      label36.TabIndex = 50;
      label36.Text = "fixType:";
      // 
      // TelemGPSspeed
      // 
      TelemGPSspeed.AutoSize = true;
      TelemGPSspeed.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemGPSspeed.Location = new Point(131, 598);
      TelemGPSspeed.Margin = new Padding(4, 0, 4, 0);
      TelemGPSspeed.Name = "TelemGPSspeed";
      TelemGPSspeed.Size = new Size(44, 25);
      TelemGPSspeed.TabIndex = 49;
      TelemGPSspeed.Text = "null";
      // 
      // label32
      // 
      label32.AutoSize = true;
      label32.Location = new Point(9, 598);
      label32.Margin = new Padding(4, 0, 4, 0);
      label32.Name = "label32";
      label32.Size = new Size(67, 25);
      label32.TabIndex = 48;
      label32.Text = "speed:";
      // 
      // TelemSatUsed
      // 
      TelemSatUsed.AutoSize = true;
      TelemSatUsed.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemSatUsed.Location = new Point(131, 568);
      TelemSatUsed.Margin = new Padding(4, 0, 4, 0);
      TelemSatUsed.Name = "TelemSatUsed";
      TelemSatUsed.Size = new Size(44, 25);
      TelemSatUsed.TabIndex = 47;
      TelemSatUsed.Text = "null";
      // 
      // label28
      // 
      label28.AutoSize = true;
      label28.Location = new Point(9, 568);
      label28.Margin = new Padding(4, 0, 4, 0);
      label28.Name = "label28";
      label28.Size = new Size(84, 25);
      label28.TabIndex = 46;
      label28.Text = "satUsed:";
      // 
      // TelemSatVisible
      // 
      TelemSatVisible.AutoSize = true;
      TelemSatVisible.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemSatVisible.Location = new Point(131, 538);
      TelemSatVisible.Margin = new Padding(4, 0, 4, 0);
      TelemSatVisible.Name = "TelemSatVisible";
      TelemSatVisible.Size = new Size(44, 25);
      TelemSatVisible.TabIndex = 45;
      TelemSatVisible.Text = "null";
      // 
      // label24
      // 
      label24.AutoSize = true;
      label24.Location = new Point(9, 538);
      label24.Margin = new Padding(4, 0, 4, 0);
      label24.Name = "label24";
      label24.Size = new Size(98, 25);
      label24.TabIndex = 44;
      label24.Text = "satVisible:";
      // 
      // TelemJamming
      // 
      TelemJamming.AutoSize = true;
      TelemJamming.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemJamming.Location = new Point(131, 505);
      TelemJamming.Margin = new Padding(4, 0, 4, 0);
      TelemJamming.Name = "TelemJamming";
      TelemJamming.Size = new Size(44, 25);
      TelemJamming.TabIndex = 43;
      TelemJamming.Text = "null";
      // 
      // label39
      // 
      label39.AutoSize = true;
      label39.Location = new Point(9, 505);
      label39.Margin = new Padding(4, 0, 4, 0);
      label39.Name = "label39";
      label39.Size = new Size(91, 25);
      label39.TabIndex = 42;
      label39.Text = "jamming:";
      // 
      // TelemNoise
      // 
      TelemNoise.AutoSize = true;
      TelemNoise.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemNoise.Location = new Point(131, 473);
      TelemNoise.Margin = new Padding(4, 0, 4, 0);
      TelemNoise.Name = "TelemNoise";
      TelemNoise.Size = new Size(44, 25);
      TelemNoise.TabIndex = 41;
      TelemNoise.Text = "null";
      // 
      // label37
      // 
      label37.AutoSize = true;
      label37.Location = new Point(9, 473);
      label37.Margin = new Padding(4, 0, 4, 0);
      label37.Name = "label37";
      label37.Size = new Size(62, 25);
      label37.TabIndex = 40;
      label37.Text = "noise:";
      // 
      // TelemPdop
      // 
      TelemPdop.AutoSize = true;
      TelemPdop.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemPdop.Location = new Point(131, 442);
      TelemPdop.Margin = new Padding(4, 0, 4, 0);
      TelemPdop.Name = "TelemPdop";
      TelemPdop.Size = new Size(44, 25);
      TelemPdop.TabIndex = 39;
      TelemPdop.Text = "null";
      // 
      // label35
      // 
      label35.AutoSize = true;
      label35.Location = new Point(9, 442);
      label35.Margin = new Padding(4, 0, 4, 0);
      label35.Name = "label35";
      label35.Size = new Size(61, 25);
      label35.TabIndex = 38;
      label35.Text = "pdop:";
      // 
      // TelemVdop
      // 
      TelemVdop.AutoSize = true;
      TelemVdop.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemVdop.Location = new Point(131, 412);
      TelemVdop.Margin = new Padding(4, 0, 4, 0);
      TelemVdop.Name = "TelemVdop";
      TelemVdop.Size = new Size(44, 25);
      TelemVdop.TabIndex = 37;
      TelemVdop.Text = "null";
      // 
      // label33
      // 
      label33.AutoSize = true;
      label33.Location = new Point(9, 412);
      label33.Margin = new Padding(4, 0, 4, 0);
      label33.Name = "label33";
      label33.Size = new Size(60, 25);
      label33.TabIndex = 36;
      label33.Text = "vdop:";
      // 
      // TelemHdop
      // 
      TelemHdop.AutoSize = true;
      TelemHdop.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemHdop.Location = new Point(131, 382);
      TelemHdop.Margin = new Padding(4, 0, 4, 0);
      TelemHdop.Name = "TelemHdop";
      TelemHdop.Size = new Size(44, 25);
      TelemHdop.TabIndex = 35;
      TelemHdop.Text = "null";
      // 
      // label31
      // 
      label31.AutoSize = true;
      label31.Location = new Point(9, 382);
      label31.Margin = new Padding(4, 0, 4, 0);
      label31.Name = "label31";
      label31.Size = new Size(61, 25);
      label31.TabIndex = 34;
      label31.Text = "hdop:";
      // 
      // TelemRealAlt
      // 
      TelemRealAlt.AutoSize = true;
      TelemRealAlt.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemRealAlt.Location = new Point(131, 348);
      TelemRealAlt.Margin = new Padding(4, 0, 4, 0);
      TelemRealAlt.Name = "TelemRealAlt";
      TelemRealAlt.Size = new Size(44, 25);
      TelemRealAlt.TabIndex = 33;
      TelemRealAlt.Text = "null";
      // 
      // label29
      // 
      label29.AutoSize = true;
      label29.Location = new Point(9, 348);
      label29.Margin = new Padding(4, 0, 4, 0);
      label29.Name = "label29";
      label29.Size = new Size(74, 25);
      label29.TabIndex = 32;
      label29.Text = "realAlt:";
      // 
      // TelemAbsAlt
      // 
      TelemAbsAlt.AutoSize = true;
      TelemAbsAlt.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemAbsAlt.Location = new Point(131, 318);
      TelemAbsAlt.Margin = new Padding(4, 0, 4, 0);
      TelemAbsAlt.Name = "TelemAbsAlt";
      TelemAbsAlt.Size = new Size(44, 25);
      TelemAbsAlt.TabIndex = 31;
      TelemAbsAlt.Text = "null";
      // 
      // label27
      // 
      label27.AutoSize = true;
      label27.Location = new Point(9, 318);
      label27.Margin = new Padding(4, 0, 4, 0);
      label27.Name = "label27";
      label27.Size = new Size(71, 25);
      label27.TabIndex = 30;
      label27.Text = "absAlt:";
      // 
      // TelemLon
      // 
      TelemLon.AutoSize = true;
      TelemLon.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemLon.Location = new Point(131, 288);
      TelemLon.Margin = new Padding(4, 0, 4, 0);
      TelemLon.Name = "TelemLon";
      TelemLon.Size = new Size(44, 25);
      TelemLon.TabIndex = 29;
      TelemLon.Text = "null";
      // 
      // label25
      // 
      label25.AutoSize = true;
      label25.Location = new Point(9, 288);
      label25.Margin = new Padding(4, 0, 4, 0);
      label25.Name = "label25";
      label25.Size = new Size(44, 25);
      label25.TabIndex = 28;
      label25.Text = "lon:";
      // 
      // TelemLat
      // 
      TelemLat.AutoSize = true;
      TelemLat.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemLat.Location = new Point(131, 255);
      TelemLat.Margin = new Padding(4, 0, 4, 0);
      TelemLat.Name = "TelemLat";
      TelemLat.Size = new Size(44, 25);
      TelemLat.TabIndex = 27;
      TelemLat.Text = "null";
      // 
      // label20
      // 
      label20.AutoSize = true;
      label20.Location = new Point(9, 255);
      label20.Margin = new Padding(4, 0, 4, 0);
      label20.Name = "label20";
      label20.Size = new Size(39, 25);
      label20.TabIndex = 26;
      label20.Text = "lat:";
      // 
      // TelemTempBaro
      // 
      TelemTempBaro.AutoSize = true;
      TelemTempBaro.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemTempBaro.Location = new Point(134, 215);
      TelemTempBaro.Margin = new Padding(4, 0, 4, 0);
      TelemTempBaro.Name = "TelemTempBaro";
      TelemTempBaro.Size = new Size(44, 25);
      TelemTempBaro.TabIndex = 25;
      TelemTempBaro.Text = "null";
      // 
      // label22
      // 
      label22.AutoSize = true;
      label22.Location = new Point(9, 215);
      label22.Margin = new Padding(4, 0, 4, 0);
      label22.Name = "label22";
      label22.Size = new Size(101, 25);
      label22.TabIndex = 24;
      label22.Text = "tempBaro:";
      // 
      // TelemPressureBaro
      // 
      TelemPressureBaro.AutoSize = true;
      TelemPressureBaro.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemPressureBaro.Location = new Point(134, 183);
      TelemPressureBaro.Margin = new Padding(4, 0, 4, 0);
      TelemPressureBaro.Name = "TelemPressureBaro";
      TelemPressureBaro.Size = new Size(44, 25);
      TelemPressureBaro.TabIndex = 23;
      TelemPressureBaro.Text = "null";
      // 
      // label18
      // 
      label18.AutoSize = true;
      label18.Location = new Point(9, 183);
      label18.Margin = new Padding(4, 0, 4, 0);
      label18.Name = "label18";
      label18.Size = new Size(129, 25);
      label18.TabIndex = 22;
      label18.Text = "pressureBaro:";
      // 
      // TelemTimeRemBat
      // 
      TelemTimeRemBat.AutoSize = true;
      TelemTimeRemBat.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemTimeRemBat.Location = new Point(426, 183);
      TelemTimeRemBat.Margin = new Padding(4, 0, 4, 0);
      TelemTimeRemBat.Name = "TelemTimeRemBat";
      TelemTimeRemBat.Size = new Size(44, 25);
      TelemTimeRemBat.TabIndex = 21;
      TelemTimeRemBat.Text = "null";
      // 
      // label16
      // 
      label16.AutoSize = true;
      label16.Location = new Point(321, 183);
      label16.Margin = new Padding(4, 0, 4, 0);
      label16.Name = "label16";
      label16.Size = new Size(104, 25);
      label16.TabIndex = 20;
      label16.Text = "timeLive_s:";
      // 
      // TelemTotalPower
      // 
      TelemTotalPower.AutoSize = true;
      TelemTotalPower.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemTotalPower.Location = new Point(426, 152);
      TelemTotalPower.Margin = new Padding(4, 0, 4, 0);
      TelemTotalPower.Name = "TelemTotalPower";
      TelemTotalPower.Size = new Size(44, 25);
      TelemTotalPower.TabIndex = 19;
      TelemTotalPower.Text = "null";
      // 
      // label23
      // 
      label23.AutoSize = true;
      label23.Location = new Point(316, 152);
      label23.Margin = new Padding(4, 0, 4, 0);
      label23.Name = "label23";
      label23.Size = new Size(110, 25);
      label23.TabIndex = 18;
      label23.Text = "totalPower:";
      // 
      // TelemBatTemp
      // 
      TelemBatTemp.AutoSize = true;
      TelemBatTemp.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemBatTemp.Location = new Point(426, 122);
      TelemBatTemp.Margin = new Padding(4, 0, 4, 0);
      TelemBatTemp.Name = "TelemBatTemp";
      TelemBatTemp.Size = new Size(44, 25);
      TelemBatTemp.TabIndex = 17;
      TelemBatTemp.Text = "null";
      // 
      // label21
      // 
      label21.AutoSize = true;
      label21.Location = new Point(339, 122);
      label21.Margin = new Padding(4, 0, 4, 0);
      label21.Name = "label21";
      label21.Size = new Size(90, 25);
      label21.TabIndex = 16;
      label21.Text = "tempBat:";
      // 
      // TelemAmperageBat
      // 
      TelemAmperageBat.AutoSize = true;
      TelemAmperageBat.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemAmperageBat.Location = new Point(426, 92);
      TelemAmperageBat.Margin = new Padding(4, 0, 4, 0);
      TelemAmperageBat.Name = "TelemAmperageBat";
      TelemAmperageBat.Size = new Size(44, 25);
      TelemAmperageBat.TabIndex = 15;
      TelemAmperageBat.Text = "null";
      // 
      // label19
      // 
      label19.AutoSize = true;
      label19.Location = new Point(321, 92);
      label19.Margin = new Padding(4, 0, 4, 0);
      label19.Name = "label19";
      label19.Size = new Size(102, 25);
      label19.TabIndex = 14;
      label19.Text = "amperage:";
      // 
      // TelemVoltageBat
      // 
      TelemVoltageBat.AutoSize = true;
      TelemVoltageBat.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemVoltageBat.Location = new Point(426, 58);
      TelemVoltageBat.Margin = new Padding(4, 0, 4, 0);
      TelemVoltageBat.Name = "TelemVoltageBat";
      TelemVoltageBat.Size = new Size(44, 25);
      TelemVoltageBat.TabIndex = 13;
      TelemVoltageBat.Text = "null";
      // 
      // label17
      // 
      label17.AutoSize = true;
      label17.Location = new Point(341, 58);
      label17.Margin = new Padding(4, 0, 4, 0);
      label17.Name = "label17";
      label17.Size = new Size(81, 25);
      label17.TabIndex = 12;
      label17.Text = "voltage:";
      // 
      // TelemPerCharge
      // 
      TelemPerCharge.AutoSize = true;
      TelemPerCharge.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemPerCharge.Location = new Point(426, 28);
      TelemPerCharge.Margin = new Padding(4, 0, 4, 0);
      TelemPerCharge.Name = "TelemPerCharge";
      TelemPerCharge.Size = new Size(44, 25);
      TelemPerCharge.TabIndex = 11;
      TelemPerCharge.Text = "null";
      // 
      // label15
      // 
      label15.AutoSize = true;
      label15.Location = new Point(319, 28);
      label15.Margin = new Padding(4, 0, 4, 0);
      label15.Name = "label15";
      label15.Size = new Size(105, 25);
      label15.TabIndex = 10;
      label15.Text = "perCharge:";
      // 
      // TelemEngineCount
      // 
      TelemEngineCount.AutoSize = true;
      TelemEngineCount.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemEngineCount.Location = new Point(134, 152);
      TelemEngineCount.Margin = new Padding(4, 0, 4, 0);
      TelemEngineCount.Name = "TelemEngineCount";
      TelemEngineCount.Size = new Size(44, 25);
      TelemEngineCount.TabIndex = 9;
      TelemEngineCount.Text = "null";
      // 
      // label14
      // 
      label14.AutoSize = true;
      label14.Location = new Point(9, 152);
      label14.Margin = new Padding(4, 0, 4, 0);
      label14.Name = "label14";
      label14.Size = new Size(126, 25);
      label14.TabIndex = 8;
      label14.Text = "engineCount:";
      // 
      // TelemEngineStatus
      // 
      TelemEngineStatus.AutoSize = true;
      TelemEngineStatus.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemEngineStatus.Location = new Point(134, 122);
      TelemEngineStatus.Margin = new Padding(4, 0, 4, 0);
      TelemEngineStatus.Name = "TelemEngineStatus";
      TelemEngineStatus.Size = new Size(44, 25);
      TelemEngineStatus.TabIndex = 7;
      TelemEngineStatus.Text = "null";
      // 
      // label13
      // 
      label13.AutoSize = true;
      label13.Location = new Point(9, 122);
      label13.Margin = new Padding(4, 0, 4, 0);
      label13.Name = "label13";
      label13.Size = new Size(128, 25);
      label13.TabIndex = 6;
      label13.Text = "engineStatus:";
      // 
      // TelemNavSys
      // 
      TelemNavSys.AutoSize = true;
      TelemNavSys.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemNavSys.Location = new Point(131, 92);
      TelemNavSys.Margin = new Padding(4, 0, 4, 0);
      TelemNavSys.Name = "TelemNavSys";
      TelemNavSys.Size = new Size(44, 25);
      TelemNavSys.TabIndex = 5;
      TelemNavSys.Text = "null";
      // 
      // label12
      // 
      label12.AutoSize = true;
      label12.Location = new Point(9, 92);
      label12.Margin = new Padding(4, 0, 4, 0);
      label12.Name = "label12";
      label12.Size = new Size(76, 25);
      label12.TabIndex = 4;
      label12.Text = "navSys:";
      // 
      // TelemStatusMode
      // 
      TelemStatusMode.AutoSize = true;
      TelemStatusMode.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemStatusMode.Location = new Point(134, 58);
      TelemStatusMode.Margin = new Padding(4, 0, 4, 0);
      TelemStatusMode.Name = "TelemStatusMode";
      TelemStatusMode.Size = new Size(44, 25);
      TelemStatusMode.TabIndex = 3;
      TelemStatusMode.Text = "null";
      // 
      // label11
      // 
      label11.AutoSize = true;
      label11.Location = new Point(9, 58);
      label11.Margin = new Padding(4, 0, 4, 0);
      label11.Name = "label11";
      label11.Size = new Size(117, 25);
      label11.TabIndex = 2;
      label11.Text = "statusMode:";
      // 
      // TelemMode
      // 
      TelemMode.AutoSize = true;
      TelemMode.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
      TelemMode.Location = new Point(134, 28);
      TelemMode.Margin = new Padding(4, 0, 4, 0);
      TelemMode.Name = "TelemMode";
      TelemMode.Size = new Size(44, 25);
      TelemMode.TabIndex = 1;
      TelemMode.Text = "null";
      // 
      // label9
      // 
      label9.AutoSize = true;
      label9.Location = new Point(9, 28);
      label9.Margin = new Padding(4, 0, 4, 0);
      label9.Name = "label9";
      label9.Size = new Size(65, 25);
      label9.TabIndex = 0;
      label9.Text = "mode:";
      // 
      // groupBox4
      // 
      groupBox4.BackColor = Color.Transparent;
      groupBox4.Controls.Add(TelemetryMessagesTab);
      groupBox4.Dock = DockStyle.Top;
      groupBox4.Location = new Point(0, 0);
      groupBox4.Margin = new Padding(4, 3, 4, 3);
      groupBox4.Name = "groupBox4";
      groupBox4.Padding = new Padding(4, 3, 4, 3);
      groupBox4.Size = new Size(661, 413);
      groupBox4.TabIndex = 6;
      groupBox4.TabStop = false;
      groupBox4.Text = "Telemetry to graph and control";
      // 
      // groupBox3
      // 
      groupBox3.BackColor = Color.Transparent;
      groupBox3.Controls.Add(groupBoxGraph);
      groupBox3.Controls.Add(ConnectionBox);
      groupBox3.Controls.Add(groupBox1);
      groupBox3.Dock = DockStyle.Top;
      groupBox3.Location = new Point(0, 0);
      groupBox3.Margin = new Padding(4, 3, 4, 3);
      groupBox3.Name = "groupBox3";
      groupBox3.Padding = new Padding(4, 3, 4, 3);
      groupBox3.Size = new Size(1678, 253);
      groupBox3.TabIndex = 9;
      groupBox3.TabStop = false;
      groupBox3.Text = "Settings";
      // 
      // tabPageSettings
      // 
      tabPageSettings.Controls.Add(tabControlSettingsMenu);
      tabPageSettings.Location = new Point(4, 34);
      tabPageSettings.Margin = new Padding(4, 3, 4, 3);
      tabPageSettings.Name = "tabPageSettings";
      tabPageSettings.Padding = new Padding(4, 3, 4, 3);
      tabPageSettings.Size = new Size(1686, 1017);
      tabPageSettings.TabIndex = 1;
      tabPageSettings.Text = "Settings";
      tabPageSettings.UseVisualStyleBackColor = true;
      // 
      // tabControlSettingsMenu
      // 
      tabControlSettingsMenu.Location = new Point(9, 8);
      tabControlSettingsMenu.Margin = new Padding(1, 2, 1, 2);
      tabControlSettingsMenu.Name = "tabControlSettingsMenu";
      tabControlSettingsMenu.SelectedIndex = 0;
      tabControlSettingsMenu.Size = new Size(1670, 1087);
      tabControlSettingsMenu.TabIndex = 0;
      // 
      // MagColibration
      // 
      MagColibration.Controls.Add(panel4);
      MagColibration.Controls.Add(groupBox6);
      MagColibration.Location = new Point(4, 34);
      MagColibration.Name = "MagColibration";
      MagColibration.Size = new Size(1686, 1017);
      MagColibration.TabIndex = 2;
      MagColibration.Text = "Magnet Calibration";
      MagColibration.UseVisualStyleBackColor = true;
      // 
      // panel4
      // 
      panel4.Controls.Add(SendMagCalibData);
      panel4.Controls.Add(comboBoxSensors);
      panel4.Controls.Add(textBox2);
      panel4.Controls.Add(textBox1);
      panel4.Controls.Add(StartMagGraph);
      panel4.Controls.Add(CalculateSphere);
      panel4.Controls.Add(sphereTextBox);
      panel4.Controls.Add(CalCulateFiltSphere);
      panel4.Dock = DockStyle.Right;
      panel4.Location = new Point(1307, 0);
      panel4.Name = "panel4";
      panel4.Size = new Size(379, 1017);
      panel4.TabIndex = 6;
      // 
      // SendMagCalibData
      // 
      SendMagCalibData.Enabled = false;
      SendMagCalibData.FlatStyle = FlatStyle.Flat;
      SendMagCalibData.Location = new Point(6, 917);
      SendMagCalibData.Name = "SendMagCalibData";
      SendMagCalibData.Size = new Size(366, 33);
      SendMagCalibData.TabIndex = 8;
      SendMagCalibData.Text = "Send mag calibration data";
      SendMagCalibData.UseVisualStyleBackColor = true;
      SendMagCalibData.Click += SendMagCalibData_Click;
      // 
      // comboBoxSensors
      // 
      comboBoxSensors.DisplayMember = "0";
      comboBoxSensors.DropDownStyle = ComboBoxStyle.DropDownList;
      comboBoxSensors.FormattingEnabled = true;
      comboBoxSensors.Items.AddRange(new object[] { "IMU_MAG", "EXTERNAL_MAG" });
      comboBoxSensors.Location = new Point(6, 12);
      comboBoxSensors.Name = "comboBoxSensors";
      comboBoxSensors.Size = new Size(365, 33);
      comboBoxSensors.TabIndex = 7;
      // 
      // textBox2
      // 
      textBox2.AutoCompleteCustomSource.AddRange(new string[] { "Sphere Radius:", "Sphere Center:", "   X:", "   Y:", "   Z:" });
      textBox2.Location = new Point(6, 675);
      textBox2.Multiline = true;
      textBox2.Name = "textBox2";
      textBox2.ReadOnly = true;
      textBox2.Size = new Size(365, 236);
      textBox2.TabIndex = 6;
      textBox2.Text = "Min Sphere:\r\n   X:\r\n   Y:\r\n   Z:\r\nMax Sphere:\r\n   X:\r\n   Y:\r\n   Z:";
      // 
      // textBox1
      // 
      textBox1.AutoCompleteCustomSource.AddRange(new string[] { "Sphere Radius:", "Sphere Center:", "   X:", "   Y:", "   Z:" });
      textBox1.Location = new Point(6, 432);
      textBox1.Multiline = true;
      textBox1.Name = "textBox1";
      textBox1.ReadOnly = true;
      textBox1.Size = new Size(365, 221);
      textBox1.TabIndex = 5;
      textBox1.Text = "Filt Sphere Radius:\r\n   X:\r\n   Y:\r\n   Z:\r\nFilt Sphere Center:\r\n   X:\r\n   Y:\r\n   Z:";
      // 
      // StartMagGraph
      // 
      StartMagGraph.FlatStyle = FlatStyle.Flat;
      StartMagGraph.Location = new Point(6, 57);
      StartMagGraph.Name = "StartMagGraph";
      StartMagGraph.Size = new Size(366, 33);
      StartMagGraph.TabIndex = 1;
      StartMagGraph.Text = "Start storage data";
      StartMagGraph.UseVisualStyleBackColor = true;
      StartMagGraph.Click += StartMagGraph_Click;
      // 
      // CalculateSphere
      // 
      CalculateSphere.FlatStyle = FlatStyle.Flat;
      CalculateSphere.Location = new Point(6, 97);
      CalculateSphere.Name = "CalculateSphere";
      CalculateSphere.Size = new Size(366, 33);
      CalculateSphere.TabIndex = 2;
      CalculateSphere.Text = "Calculate Sphere";
      CalculateSphere.UseVisualStyleBackColor = true;
      CalculateSphere.Click += CalculateSphere_Click;
      // 
      // sphereTextBox
      // 
      sphereTextBox.AutoCompleteCustomSource.AddRange(new string[] { "Sphere Radius:", "Sphere Center:", "   X:", "   Y:", "   Z:" });
      sphereTextBox.Location = new Point(6, 137);
      sphereTextBox.Multiline = true;
      sphereTextBox.Name = "sphereTextBox";
      sphereTextBox.ReadOnly = true;
      sphereTextBox.Size = new Size(365, 231);
      sphereTextBox.TabIndex = 3;
      sphereTextBox.Text = "Sphere Radius:\r\n   X:\r\n   Y:\r\n   Z:\r\nSphere Center:\r\n   X:\r\n   Y:\r\n   Z:";
      // 
      // CalCulateFiltSphere
      // 
      CalCulateFiltSphere.FlatStyle = FlatStyle.Flat;
      CalCulateFiltSphere.Location = new Point(6, 383);
      CalCulateFiltSphere.Name = "CalCulateFiltSphere";
      CalCulateFiltSphere.Size = new Size(366, 33);
      CalCulateFiltSphere.TabIndex = 4;
      CalCulateFiltSphere.Text = "Calculate Filt Sphere";
      CalCulateFiltSphere.UseVisualStyleBackColor = true;
      CalCulateFiltSphere.Click += CalCulateFiltSphere_Click;
      // 
      // groupBox6
      // 
      groupBox6.Controls.Add(graph3d1);
      groupBox6.Dock = DockStyle.Fill;
      groupBox6.Location = new Point(0, 0);
      groupBox6.Name = "groupBox6";
      groupBox6.Size = new Size(1686, 1017);
      groupBox6.TabIndex = 0;
      groupBox6.TabStop = false;
      groupBox6.Text = "MagChart";
      // 
      // graph3d1
      // 
      graph3d1.AxisX_Color = Color.White;
      graph3d1.AxisX_Legend = "";
      graph3d1.AxisY_Color = Color.White;
      graph3d1.AxisY_Legend = null;
      graph3d1.AxisZ_Color = Color.White;
      graph3d1.AxisZ_Legend = null;
      graph3d1.BackColor = Color.White;
      graph3d1.BorderColor = Color.Black;
      graph3d1.BorderStyle = BorderStyle.Fixed3D;
      graph3d1.Cursor = Cursors.Hand;
      graph3d1.Dock = DockStyle.Fill;
      graph3d1.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
      graph3d1.ForeColor = Color.Black;
      graph3d1.Location = new Point(3, 27);
      graph3d1.Name = "graph3d1";
      graph3d1.PolygonLineColor = Color.Black;
      graph3d1.Raster = Plot3D.Graph3D.eRaster.Off;
      graph3d1.Size = new Size(1680, 987);
      graph3d1.TabIndex = 0;
      graph3d1.TopLegendColor = Color.Black;
      // 
      // AccColib
      // 
      AccColib.Controls.Add(panel5);
      AccColib.Controls.Add(panel7);
      AccColib.Location = new Point(4, 34);
      AccColib.Name = "AccColib";
      AccColib.Size = new Size(1686, 1017);
      AccColib.TabIndex = 3;
      AccColib.Text = "Accel Calibration";
      AccColib.UseVisualStyleBackColor = true;
      // 
      // panel5
      // 
      panel5.Controls.Add(panel9);
      panel5.Controls.Add(panel8);
      panel5.Dock = DockStyle.Fill;
      panel5.Location = new Point(0, 0);
      panel5.Name = "panel5";
      panel5.Size = new Size(1440, 1017);
      panel5.TabIndex = 0;
      // 
      // panel9
      // 
      panel9.BackColor = Color.Transparent;
      panel9.Controls.Add(panelMinuseZ);
      panel9.Controls.Add(panelPluseZ);
      panel9.Controls.Add(panelMinuseY);
      panel9.Dock = DockStyle.Top;
      panel9.Location = new Point(0, 547);
      panel9.Name = "panel9";
      panel9.Size = new Size(1440, 475);
      panel9.TabIndex = 8;
      // 
      // panelMinuseZ
      // 
      panelMinuseZ.BorderStyle = BorderStyle.FixedSingle;
      panelMinuseZ.Controls.Add(pictureBox5);
      panelMinuseZ.Controls.Add(textBoxMinuseZ);
      panelMinuseZ.Dock = DockStyle.Left;
      panelMinuseZ.Location = new Point(955, 0);
      panelMinuseZ.Name = "panelMinuseZ";
      panelMinuseZ.Size = new Size(478, 475);
      panelMinuseZ.TabIndex = 6;
      // 
      // pictureBox5
      // 
      pictureBox5.Dock = DockStyle.Fill;
      pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
      pictureBox5.Location = new Point(0, 0);
      pictureBox5.Name = "pictureBox5";
      pictureBox5.Size = new Size(476, 434);
      pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
      pictureBox5.TabIndex = 0;
      pictureBox5.TabStop = false;
      // 
      // textBoxMinuseZ
      // 
      textBoxMinuseZ.Dock = DockStyle.Bottom;
      textBoxMinuseZ.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
      textBoxMinuseZ.Location = new Point(0, 434);
      textBoxMinuseZ.Name = "textBoxMinuseZ";
      textBoxMinuseZ.ReadOnly = true;
      textBoxMinuseZ.Size = new Size(476, 39);
      textBoxMinuseZ.TabIndex = 3;
      textBoxMinuseZ.Text = "-Z";
      textBoxMinuseZ.TextAlign = HorizontalAlignment.Center;
      // 
      // panelPluseZ
      // 
      panelPluseZ.BorderStyle = BorderStyle.FixedSingle;
      panelPluseZ.Controls.Add(pictureBox6);
      panelPluseZ.Controls.Add(textBoxPluseZ);
      panelPluseZ.Dock = DockStyle.Left;
      panelPluseZ.Location = new Point(463, 0);
      panelPluseZ.Name = "panelPluseZ";
      panelPluseZ.Size = new Size(492, 475);
      panelPluseZ.TabIndex = 5;
      // 
      // pictureBox6
      // 
      pictureBox6.Dock = DockStyle.Fill;
      pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
      pictureBox6.Location = new Point(0, 0);
      pictureBox6.Name = "pictureBox6";
      pictureBox6.Size = new Size(490, 434);
      pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
      pictureBox6.TabIndex = 0;
      pictureBox6.TabStop = false;
      // 
      // textBoxPluseZ
      // 
      textBoxPluseZ.Dock = DockStyle.Bottom;
      textBoxPluseZ.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
      textBoxPluseZ.Location = new Point(0, 434);
      textBoxPluseZ.Name = "textBoxPluseZ";
      textBoxPluseZ.ReadOnly = true;
      textBoxPluseZ.Size = new Size(490, 39);
      textBoxPluseZ.TabIndex = 3;
      textBoxPluseZ.Text = "+Z";
      textBoxPluseZ.TextAlign = HorizontalAlignment.Center;
      // 
      // panelMinuseY
      // 
      panelMinuseY.BorderStyle = BorderStyle.FixedSingle;
      panelMinuseY.Controls.Add(pictureBox4);
      panelMinuseY.Controls.Add(textBoxMinuseY);
      panelMinuseY.Dock = DockStyle.Left;
      panelMinuseY.Location = new Point(0, 0);
      panelMinuseY.Name = "panelMinuseY";
      panelMinuseY.Size = new Size(463, 475);
      panelMinuseY.TabIndex = 4;
      // 
      // pictureBox4
      // 
      pictureBox4.Dock = DockStyle.Fill;
      pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
      pictureBox4.Location = new Point(0, 0);
      pictureBox4.Name = "pictureBox4";
      pictureBox4.Size = new Size(461, 434);
      pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
      pictureBox4.TabIndex = 0;
      pictureBox4.TabStop = false;
      // 
      // textBoxMinuseY
      // 
      textBoxMinuseY.Dock = DockStyle.Bottom;
      textBoxMinuseY.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
      textBoxMinuseY.Location = new Point(0, 434);
      textBoxMinuseY.Name = "textBoxMinuseY";
      textBoxMinuseY.ReadOnly = true;
      textBoxMinuseY.Size = new Size(461, 39);
      textBoxMinuseY.TabIndex = 3;
      textBoxMinuseY.Text = "-Y";
      textBoxMinuseY.TextAlign = HorizontalAlignment.Center;
      // 
      // panel8
      // 
      panel8.BackColor = Color.Transparent;
      panel8.Controls.Add(panelPluseY);
      panel8.Controls.Add(panelMinuseX);
      panel8.Controls.Add(panelPluseX);
      panel8.Dock = DockStyle.Top;
      panel8.Location = new Point(0, 0);
      panel8.Name = "panel8";
      panel8.Size = new Size(1440, 547);
      panel8.TabIndex = 7;
      // 
      // panelPluseY
      // 
      panelPluseY.BorderStyle = BorderStyle.FixedSingle;
      panelPluseY.Controls.Add(pictureBox3);
      panelPluseY.Controls.Add(textBoxPluseY);
      panelPluseY.Dock = DockStyle.Left;
      panelPluseY.Location = new Point(955, 0);
      panelPluseY.Name = "panelPluseY";
      panelPluseY.Size = new Size(476, 547);
      panelPluseY.TabIndex = 3;
      // 
      // pictureBox3
      // 
      pictureBox3.Dock = DockStyle.Fill;
      pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
      pictureBox3.Location = new Point(0, 0);
      pictureBox3.Name = "pictureBox3";
      pictureBox3.Size = new Size(474, 506);
      pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
      pictureBox3.TabIndex = 0;
      pictureBox3.TabStop = false;
      // 
      // textBoxPluseY
      // 
      textBoxPluseY.Dock = DockStyle.Bottom;
      textBoxPluseY.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
      textBoxPluseY.Location = new Point(0, 506);
      textBoxPluseY.Name = "textBoxPluseY";
      textBoxPluseY.ReadOnly = true;
      textBoxPluseY.Size = new Size(474, 39);
      textBoxPluseY.TabIndex = 3;
      textBoxPluseY.Text = "+Y";
      textBoxPluseY.TextAlign = HorizontalAlignment.Center;
      // 
      // panelMinuseX
      // 
      panelMinuseX.BorderStyle = BorderStyle.FixedSingle;
      panelMinuseX.Controls.Add(pictureBox1);
      panelMinuseX.Controls.Add(textBoxMinuseX);
      panelMinuseX.Dock = DockStyle.Left;
      panelMinuseX.Location = new Point(463, 0);
      panelMinuseX.Name = "panelMinuseX";
      panelMinuseX.Size = new Size(492, 547);
      panelMinuseX.TabIndex = 2;
      // 
      // pictureBox1
      // 
      pictureBox1.BackColor = Color.Transparent;
      pictureBox1.Dock = DockStyle.Fill;
      pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
      pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
      pictureBox1.Location = new Point(0, 0);
      pictureBox1.Name = "pictureBox1";
      pictureBox1.Size = new Size(490, 506);
      pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
      pictureBox1.TabIndex = 0;
      pictureBox1.TabStop = false;
      // 
      // textBoxMinuseX
      // 
      textBoxMinuseX.Dock = DockStyle.Bottom;
      textBoxMinuseX.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
      textBoxMinuseX.Location = new Point(0, 506);
      textBoxMinuseX.Name = "textBoxMinuseX";
      textBoxMinuseX.ReadOnly = true;
      textBoxMinuseX.Size = new Size(490, 39);
      textBoxMinuseX.TabIndex = 3;
      textBoxMinuseX.Text = "-X";
      textBoxMinuseX.TextAlign = HorizontalAlignment.Center;
      // 
      // panelPluseX
      // 
      panelPluseX.BorderStyle = BorderStyle.FixedSingle;
      panelPluseX.Controls.Add(textBoxPluseX);
      panelPluseX.Controls.Add(pictureBox2);
      panelPluseX.Dock = DockStyle.Left;
      panelPluseX.Location = new Point(0, 0);
      panelPluseX.Name = "panelPluseX";
      panelPluseX.Size = new Size(463, 547);
      panelPluseX.TabIndex = 1;
      // 
      // textBoxPluseX
      // 
      textBoxPluseX.BackColor = Color.White;
      textBoxPluseX.Dock = DockStyle.Bottom;
      textBoxPluseX.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
      textBoxPluseX.ForeColor = SystemColors.MenuText;
      textBoxPluseX.Location = new Point(0, 506);
      textBoxPluseX.Name = "textBoxPluseX";
      textBoxPluseX.ReadOnly = true;
      textBoxPluseX.Size = new Size(461, 39);
      textBoxPluseX.TabIndex = 2;
      textBoxPluseX.Text = "+X";
      textBoxPluseX.TextAlign = HorizontalAlignment.Center;
      // 
      // pictureBox2
      // 
      pictureBox2.Dock = DockStyle.Fill;
      pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
      pictureBox2.Location = new Point(0, 0);
      pictureBox2.Name = "pictureBox2";
      pictureBox2.Size = new Size(461, 545);
      pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
      pictureBox2.TabIndex = 0;
      pictureBox2.TabStop = false;
      // 
      // panel7
      // 
      panel7.Controls.Add(SetLevelHor);
      panel7.Controls.Add(SendAccColibData);
      panel7.Controls.Add(numericUpDownBorderAccValue);
      panel7.Controls.Add(label60);
      panel7.Controls.Add(numericUpCountValueAcc);
      panel7.Controls.Add(label58);
      panel7.Controls.Add(buttonStartAccColib);
      panel7.Dock = DockStyle.Right;
      panel7.Location = new Point(1440, 0);
      panel7.Name = "panel7";
      panel7.Size = new Size(246, 1017);
      panel7.TabIndex = 2;
      // 
      // SetLevelHor
      // 
      SetLevelHor.Enabled = false;
      SetLevelHor.FlatStyle = FlatStyle.Flat;
      SetLevelHor.Location = new Point(7, 197);
      SetLevelHor.Name = "SetLevelHor";
      SetLevelHor.Size = new Size(230, 33);
      SetLevelHor.TabIndex = 13;
      SetLevelHor.Text = "Set level hor";
      SetLevelHor.UseVisualStyleBackColor = true;
      SetLevelHor.Click += SetLevelHor_Click;
      // 
      // SendAccColibData
      // 
      SendAccColibData.Enabled = false;
      SendAccColibData.FlatStyle = FlatStyle.Flat;
      SendAccColibData.Location = new Point(7, 157);
      SendAccColibData.Name = "SendAccColibData";
      SendAccColibData.Size = new Size(230, 33);
      SendAccColibData.TabIndex = 12;
      SendAccColibData.Text = "Send calibration data";
      SendAccColibData.UseVisualStyleBackColor = true;
      SendAccColibData.Click += button1_Click;
      // 
      // numericUpDownBorderAccValue
      // 
      numericUpDownBorderAccValue.Location = new Point(121, 120);
      numericUpDownBorderAccValue.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
      numericUpDownBorderAccValue.Name = "numericUpDownBorderAccValue";
      numericUpDownBorderAccValue.Size = new Size(114, 31);
      numericUpDownBorderAccValue.TabIndex = 11;
      numericUpDownBorderAccValue.Value = new decimal(new int[] { 50, 0, 0, 0 });
      // 
      // label60
      // 
      label60.AutoSize = true;
      label60.Location = new Point(14, 122);
      label60.Name = "label60";
      label60.Size = new Size(69, 25);
      label60.TabIndex = 10;
      label60.Text = "Border:";
      // 
      // numericUpCountValueAcc
      // 
      numericUpCountValueAcc.Location = new Point(121, 72);
      numericUpCountValueAcc.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
      numericUpCountValueAcc.Name = "numericUpCountValueAcc";
      numericUpCountValueAcc.Size = new Size(114, 31);
      numericUpCountValueAcc.TabIndex = 9;
      numericUpCountValueAcc.Value = new decimal(new int[] { 100, 0, 0, 0 });
      // 
      // label58
      // 
      label58.AutoSize = true;
      label58.Location = new Point(14, 73);
      label58.Name = "label58";
      label58.Size = new Size(110, 25);
      label58.TabIndex = 8;
      label58.Text = "Count value:";
      // 
      // buttonStartAccColib
      // 
      buttonStartAccColib.FlatStyle = FlatStyle.Flat;
      buttonStartAccColib.Location = new Point(6, 22);
      buttonStartAccColib.Name = "buttonStartAccColib";
      buttonStartAccColib.Size = new Size(230, 33);
      buttonStartAccColib.TabIndex = 7;
      buttonStartAccColib.Text = "Start Acc Calibrate";
      buttonStartAccColib.UseVisualStyleBackColor = true;
      buttonStartAccColib.Click += buttonStartAccColib_Click;
      // 
      // SettingsDrone
      // 
      AutoScaleDimensions = new SizeF(10F, 25F);
      AutoScaleMode = AutoScaleMode.Font;
      ClientSize = new Size(1694, 1055);
      Controls.Add(tabControl1);
      Margin = new Padding(4, 3, 4, 3);
      Name = "SettingsDrone";
      Text = "SettingsDrone";
      groupBox1.ResumeLayout(false);
      groupBox1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)numericUpDownFreqReqOthreTelem).EndInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDown_Freq_req_telem).EndInit();
      TelemetryMessagesTab.ResumeLayout(false);
      GPS.ResumeLayout(false);
      Inetrial.ResumeLayout(false);
      Gyro.ResumeLayout(false);
      Accel.ResumeLayout(false);
      Battery.ResumeLayout(false);
      Sys.ResumeLayout(false);
      groupBox2.ResumeLayout(false);
      tabPageControlUAV.ResumeLayout(false);
      tabPageControlUAV.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)numericUpDownSpeed).EndInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDownZ).EndInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDownY).EndInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDownX).EndInit();
      ConnectionBox.ResumeLayout(false);
      ConnectionsPages.ResumeLayout(false);
      PipeLinePage.ResumeLayout(false);
      PipeLinePage.PerformLayout();
      ComPage.ResumeLayout(false);
      ComPage.PerformLayout();
      groupBoxGraph.ResumeLayout(false);
      groupBoxGraph.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)numericUpDown_Graph_Interval).EndInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDown_Graph_Scale).EndInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDown_Graph_Max).EndInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDown_Graph_Min).EndInit();
      ((System.ComponentModel.ISupportInitialize)numericUpDown_Graph_Time).EndInit();
      tabControl1.ResumeLayout(false);
      Telemetry.ResumeLayout(false);
      panel3.ResumeLayout(false);
      panel1.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)chart_Graph).EndInit();
      panel2.ResumeLayout(false);
      panel6.ResumeLayout(false);
      groupBox5.ResumeLayout(false);
      groupBox5.PerformLayout();
      groupBox4.ResumeLayout(false);
      groupBox3.ResumeLayout(false);
      tabPageSettings.ResumeLayout(false);
      MagColibration.ResumeLayout(false);
      panel4.ResumeLayout(false);
      panel4.PerformLayout();
      groupBox6.ResumeLayout(false);
      AccColib.ResumeLayout(false);
      panel5.ResumeLayout(false);
      panel9.ResumeLayout(false);
      panelMinuseZ.ResumeLayout(false);
      panelMinuseZ.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
      panelPluseZ.ResumeLayout(false);
      panelPluseZ.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
      panelMinuseY.ResumeLayout(false);
      panelMinuseY.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
      panel8.ResumeLayout(false);
      panelPluseY.ResumeLayout(false);
      panelPluseY.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
      panelMinuseX.ResumeLayout(false);
      panelMinuseX.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
      panelPluseX.ResumeLayout(false);
      panelPluseX.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
      panel7.ResumeLayout(false);
      panel7.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)numericUpDownBorderAccValue).EndInit();
      ((System.ComponentModel.ISupportInitialize)numericUpCountValueAcc).EndInit();
      ResumeLayout(false);
    }

    #endregion
    private System.Windows.Forms.Timer timer1;
    private GroupBox groupBox1;
    private Label label7;
    private NumericUpDown numericUpDown_Freq_req_telem;
    private TabControl TelemetryMessagesTab;
    private TabPage GPS;
    private CheckedListBox checkedListBoxGPS2;
    private CheckedListBox checkedListBoxGPS;
    private TabPage Inetrial;
    private CheckedListBox checkedListBoxInertial2;
    private CheckedListBox checkedListBoxInertial;
    private TabPage Gyro;
    private CheckedListBox checkedListBoxGyro;
    private TabPage Accel;
    private CheckedListBox checkedListBoxAccel;
    private TabPage Battery;
    private CheckedListBox checkedListBoxBattery;
    private TabPage Sys;
    private GroupBox groupBox2;
    private CheckedListBox checkedListBoxEngines;
    private CheckedListBox checkedListBoxSys;
    private GroupBox ConnectionBox;
    private TabControl ConnectionsPages;
    private TabPage PipeLinePage;
    private TextBox AddressPipeLine;
    private Button PipeLineConnect;
    private Label label1;
    private TabPage ComPage;
    private ComboBox BAUDBOX;
    private ComboBox COMBOX;
    private Label label3;
    private Label label2;
    private Button COMConnect;
    private GroupBox groupBoxGraph;
    private CheckBox checkBox_Graph_Live;
    private Button button_Graph_Fixed;
    private NumericUpDown numericUpDown_Graph_Interval;
    private Label label6;
    private CheckBox checkBox_Graph_Auto;
    private NumericUpDown numericUpDown_Graph_Scale;
    private CheckBox checkBox_Graph_Scale;
    private NumericUpDown numericUpDown_Graph_Max;
    private NumericUpDown numericUpDown_Graph_Min;
    private Label label5;
    private NumericUpDown numericUpDown_Graph_Time;
    private Label label4;
    private TabControl tabControl1;
    private TabPage Telemetry;
    private TabPage tabPageSettings;
    private Chart chart_Graph;
    private Panel panel1;
    private Panel panel2;
    private GroupBox groupBox3;
    private Panel panel3;
    private GroupBox groupBox4;
    private NumericUpDown numericUpDownFreqReqOthreTelem;
    private Label label8;
    private GroupBox groupBox5;
    private Label TelemMode;
    private Label label9;
    private Label TelemStatusMode;
    private Label label11;
    private Label TelemEngineStatus;
    private Label label13;
    private Label TelemNavSys;
    private Label label12;
    private Label TelemTotalPower;
    private Label label23;
    private Label TelemBatTemp;
    private Label label21;
    private Label TelemAmperageBat;
    private Label label19;
    private Label TelemVoltageBat;
    private Label label17;
    private Label TelemPerCharge;
    private Label label15;
    private Label TelemEngineCount;
    private Label label14;
    private Label TelemTimeRemBat;
    private Label label16;
    private Label TelemTempBaro;
    private Label label22;
    private Label TelemPressureBaro;
    private Label label18;
    private Label TelemHdop;
    private Label label31;
    private Label TelemRealAlt;
    private Label label29;
    private Label TelemAbsAlt;
    private Label label27;
    private Label TelemLon;
    private Label label25;
    private Label TelemLat;
    private Label label20;
    private Label TelemJamming;
    private Label label39;
    private Label TelemNoise;
    private Label label37;
    private Label TelemPdop;
    private Label label35;
    private Label TelemVdop;
    private Label label33;
    private Label TelemSatUsed;
    private Label label28;
    private Label TelemSatVisible;
    private Label label24;
    private Label TelemTimeUTC;
    private Label label40;
    private Label TelemGPSFixType;
    private Label label36;
    private Label TelemGPSspeed;
    private Label label32;
    private Label TelemYawVel;
    private Label label57;
    private Label TelemPitchVel;
    private Label label55;
    private Label TelemRollVel;
    private Label label53;
    private Label TelemYaw;
    private Label label51;
    private Label TelemPitch;
    private Label label49;
    private Label TelemRoll;
    private Label label47;
    private Label TelemSpeedINS;
    private Label label45;
    private Label TelemHeadingDeg;
    private Label label43;
    private Label TelemZ;
    private Label label41;
    private Label TelemY;
    private Label label34;
    private Label TelemX;
    private Label label26;
    private Label TelemBaroAlt;
    private Label label59;
    private Button buttonLogging;
    private TextBox textBoxLogFilePath;
    private Label label10;
    private Label SPDRX;
    private Label label30;
    private Label HzRecvTelem;
    private Label label38;
    private Panel panel6;
    private TabPage tabPageControlUAV;
    private NumericUpDown numericUpDownX;
    private Label label42;
    private Button buttonChangeNav;
    private Button buttonSendGoHome;
    private Button buttonSendLand;
    private Button buttonSendStop;
    private Button buttonSendGoToLocal;
    private NumericUpDown numericUpDownSpeed;
    private Label label48;
    private NumericUpDown numericUpDownZ;
    private Label label46;
    private NumericUpDown numericUpDownY;
    private Label label44;
    private TextBox textBoxLon;
    private Label label52;
    private TextBox textBoxLat;
    private Label label50;
    private Button buttonGoToGlobal;
    private Button buttonSendSetSpeed;
    private TabControl tabControlSettingsMenu;
    private Label label54;
    private Label commandStatusLabel;
    private Label commandLabel;
    private Label label56;
    private TabPage MagColibration;
    private GroupBox groupBox6;
    private Plot3D.Graph3D graph3d1;
    private Button StartMagGraph;
    private Button CalculateSphere;
    private TextBox sphereTextBox;
    private Button CalCulateFiltSphere;
    private TextBox textBox1;
    private Panel panel4;
    private TextBox textBox2;
        private Button SetLocalCoord;
    private TabPage AccColib;
    private Panel panel5;
    private Panel panel7;
    private Panel panelPluseX;
    private PictureBox pictureBox1;
    private Panel panelMinuseZ;
    private PictureBox pictureBox6;
    private Panel panelPluseZ;
    private PictureBox pictureBox5;
    private Panel panelMinuseY;
    private PictureBox pictureBox4;
    private Panel panelPluseY;
    private PictureBox pictureBox3;
    private Panel panelMinuseX;
    private PictureBox pictureBox2;
    private TextBox textBoxMinuseZ;
    private TextBox textBoxPluseZ;
    private TextBox textBoxMinuseY;
    private TextBox textBoxPluseY;
    private TextBox textBoxMinuseX;
    private TextBox textBoxPluseX;
    private Panel panel9;
    private Panel panel8;
    private Button buttonStartAccColib;
    private NumericUpDown numericUpDownBorderAccValue;
    private Label label60;
    private NumericUpDown numericUpCountValueAcc;
    private Label label58;
    private Button SendAccColibData;
    private ComboBox comboBoxSensors;
    private Button SendMagCalibData;
    private Button SetLevelHor;
    private CheckBox TopWindow;
    private GMap.NET.WindowsForms.GMapControl gMapControl1;
    private CheckBox checkBox1;
    private OverlayPanel panel10;
  }
}
