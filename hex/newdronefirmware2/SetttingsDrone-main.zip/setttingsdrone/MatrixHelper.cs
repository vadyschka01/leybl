﻿using System;

namespace SettingsDrone
{
  public static class MatrixHelper
  {
    // Умножение матрицы на матрицу (или вектор)
    public static double[,] Multiply(double[,] A, double[,] B)
    {
      int rA = A.GetLength(0);
      int cA = A.GetLength(1);
      int rB = B.GetLength(0);
      int cB = B.GetLength(1);

      if (cA != rB)
        throw new ArgumentException("Размеры матриц несовместимы для умножения.");

      double[,] result = new double[rA, cB];
      for (int i = 0; i < rA; i++)
      {
        for (int j = 0; j < cB; j++)
        {
          double sum = 0;
          for (int k = 0; k < cA; k++)
            sum += A[i, k] * B[k, j];
          result[i, j] = sum;
        }
      }
      return result;
    }

    // Транспонирование матрицы
    public static double[,] Transpose(double[,] matrix)
    {
      int rows = matrix.GetLength(0);
      int cols = matrix.GetLength(1);
      double[,] result = new double[cols, rows];
      for (int i = 0; i < rows; i++)
        for (int j = 0; j < cols; j++)
          result[j, i] = matrix[i, j];
      return result;
    }

    // Инвертирование матрицы методом Гаусса-Жордана
    public static double[,] Invert(double[,] matrix)
    {
      int n = matrix.GetLength(0);
      if (n != matrix.GetLength(1))
        throw new ArgumentException("Матрица должна быть квадратной.");

      double[,] augmentedMatrix = new double[n, 2 * n];

      // Создаем расширенную матрицу [A | I]
      for (int i = 0; i < n; i++)
      {
        for (int j = 0; j < n; j++)
          augmentedMatrix[i, j] = matrix[i, j];
        augmentedMatrix[i, i + n] = 1;
      }

      // Применяем прямой ход метода Гаусса
      for (int i = 0; i < n; i++)
      {
        // Находим ведущий элемент
        int maxRow = i;
        for (int k = i + 1; k < n; k++)
          if (Math.Abs(augmentedMatrix[k, i]) > Math.Abs(augmentedMatrix[maxRow, i]))
            maxRow = k;

        // Меняем строки местами
        for (int k = 0; k < 2 * n; k++)
        {
          double temp = augmentedMatrix[i, k];
          augmentedMatrix[i, k] = augmentedMatrix[maxRow, k];
          augmentedMatrix[maxRow, k] = temp;
        }

        // Проверка на сингулярность
        if (Math.Abs(augmentedMatrix[i, i]) < 1e-12)
          throw new InvalidOperationException("Матрица является сингулярной и не может быть инвертирована.");

        // Нормализуем строку
        double pivot = augmentedMatrix[i, i];
        for (int j = 0; j < 2 * n; j++)
          augmentedMatrix[i, j] /= pivot;

        // Обнуляем элементы в столбце
        for (int k = 0; k < n; k++)
        {
          if (k != i)
          {
            double factor = augmentedMatrix[k, i];
            for (int j = 0; j < 2 * n; j++)
              augmentedMatrix[k, j] -= factor * augmentedMatrix[i, j];
          }
        }
      }

      // Извлекаем инвертированную матрицу
      double[,] inverse = new double[n, n];
      for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
          inverse[i, j] = augmentedMatrix[i, j + n];

      return inverse;
    }
  }
}
