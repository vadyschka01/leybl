﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.Ports;

namespace SettingsDrone
{
    public class ComClient : ConnectionInterface
    {
        string dev;
        int baud;
        SerialPort serial;
        public ComClient(string com, int baud) 
        {
            dev = /*"\\\\.\\" + */com;
            this.baud = baud;
        }

        public override void Connect()
        {
            try
            {
                serial = new SerialPort(dev, baud);
                //serial.ReadTimeout = 100;
                serial.Open();
                IsConnected = true;
            }
            catch (Exception ex)
            {
                IsConnected = false;
                throw ex;
            }
        }

        public override void Disconnect()
        {
            serial.Close();
            IsConnected = false;
        }

        public override byte[]? RecvData(int count)
        {
            byte[] data = new byte[count];
            try
            {
                int count_read = serial.Read(data, 0, count);
                if (count_read <= 0) return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error recv data with COM port: {ex}");
                return null; 
            }
            return data;
        }

        public override bool SendData(byte[] data)
        {
            try
            {
                serial.Write(data, 0, data.Length);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error send data with COM port: {ex}");
                return false; 
            }
        }
    }
}
