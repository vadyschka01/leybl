﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;

namespace SettingsDrone
{
  public class NewButton : Button
  {
    public int cat_id;
    public int param_id;
  }
  public class NewTextBox : TextBox
  {
    public int cat_id;
    public int param_id;
    public string param_name;
  }
  public class ItemBoxCollection
  {
    public string? name;
    public Series? ser;
    public bool check;
    public ItemBoxCollection(string name)
    {
      this.name = name;
      ser = new System.Windows.Forms.DataVisualization.Charting.Series();
      ser.ChartArea = "ChartArea1";
      ser.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
      ser.Legend = "Legend1";
      ser.Name = name;
      ser.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.DateTime;
      ser.BorderWidth = 5;
    }

    public override string? ToString()
    {
      return name;
    }
  }
  public unsafe class EngineItemsBoxCollection
  {
    public string? name;
    public Series[]? ser;
    public bool check;
    public EngineItemsBoxCollection(string name, int count)
    {
      this.name = name;
      ser = new Series[count];
      for (int i = 0; i < count; i++)
      {
        System.Windows.Forms.DataVisualization.Charting.Series s = new System.Windows.Forms.DataVisualization.Charting.Series();
        s.ChartArea = "ChartArea1";
        s.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
        s.Legend = "Legend1";
        s.Name = $"{name}-{i}";
        s.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.DateTime;
        s.BorderWidth = 5;
        ser[i] = s;
      }

    }

    public override string? ToString()
    {
      return name;
    }
  }

  public struct DroneGPS
  {
    public double lat; //
    public double lon; //
    public float absAlt; //
    public float realAlt; //
    public float hdop; //
    public float vdop; //
    public float pdop; //
    public float noise; //
    public float jamming; //
    public byte satVisible;
    public byte satUsed; //
    public float speed; // 
    public GPS_FIX_TYPE fixType; // NO_GPS - 0, NO_FIX - 1, 2D_FIX - 2, 3D_FIX - 3, DGPS - 4, RTK_FLOAT - 5, RTK_FIXED - 6, STATIC - 7, PPP - 8
    public ulong timeUTC; // UTC - InfoGPS

    public void update(MessageGpsInfo info)
    {
      lat = info.lat;
      lon = info.lon;
      absAlt = info.absAlt;
      realAlt = info.realAlt;
      hdop = info.hdop;
      vdop = info.vdop;
      pdop = info.pdop;
      noise = info.noise;
      jamming = info.jamming;
      satVisible = info.satVisible;
      satUsed = info.satUsed;
      speed = info.speed;
      fixType = info.fixType;
      timeUTC = info.timeUTC;
    }
  }
  public struct DroneBattery
  {
    public byte perCharge;
    public float voltage;
    public float amperage;
    public float temp;
    public float totalPower;
    public ulong timeRemaining;

    public void update(MessageBatteryInfo info)
    {
      perCharge = info.perCharge;
      voltage = info.voltage;
      amperage = info.amperage;
      temp = info.temp;
      totalPower = info.totalPower;
      timeRemaining = info.timeRemaining;
    }
  }
  public struct DroneGyro
  {
    public float yawGyroVel;
    public float pitchGyroVel;
    public float rollGyroVel;

    public void update(MessageGyroInfo info)
    {
      yawGyroVel = info.yawGyroVel;
      pitchGyroVel = info.pitchGyroVel;
      rollGyroVel = info.rollGyroVel;
    }
  }
  public struct DroneAccel
  {
    public float yawAccelVel;
    public float pitchAccelVel;
    public float rollAccelVel;
    public float aX;
    public float aY;
    public float aZ;
    public float tempAccel;

    public void update(MessageAccelInfo info)
    {
      tempAccel = info.tempAccel;
      aX = info.aX;
      aY = info.aY;
      aZ = info.aZ;
      yawAccelVel = info.yawAccelVel;
      pitchAccelVel = info.pitchAccelVel;
      rollAccelVel = info.rollAccelVel;
    }
  }
  public struct DroneSys
  {
    public SYS_MODE mode;
    public STATUS_MODE statusMode;
    public NAV_SYS_MODE navSys;
    public ENGINE_STATUS engineStatus;
    public byte engineCount;
    public float pressureBaro;
    public float tempBaro;

    public EnginePowerInfo[] enginePower;

    public void update(MessageSysInfo info)
    {
      mode = info.mode;
      statusMode = info.statusMode;
      navSys = info.navSys;
      engineStatus = info.engineStatus;
      engineCount = info.engineCount;
      pressureBaro = info.pressureBaro;
      tempBaro = info.tempBaro;
      enginePower = MessageSysInfo.enginePower;
    }
  }
  public struct DroneInertial
  {
    public float x;
    public float y;
    public float z;
    public float headingDeg;
    public float speed;
    public float roll;
    public float pitch;
    public float yaw;
    public float rollVel;
    public float pitchVel;
    public float yawVel;
    public float baroAlt;

    public void update(MessageInertialInfo info)
    {
      x = info.x;
      y = info.y;
      z = info.z;
      headingDeg = info.headingDeg;
      speed = info.speed;
      roll = info.roll;
      pitch = info.pitch;
      yaw = info.yaw;
      rollVel = info.rollVel;
      pitchVel = info.pitchVel;
      yawVel = info.yawVel;
      baroAlt = info.baroAlt;
    }
  }

  public struct DroneRawCalibData
  {
    SENSOR_ID sensor;

    public float X;
    public float Y;
    public float Z;

    public void update(MessageRawCalibData info)
    {
      sensor = info.sensor;
      X = info.X;
      Y = info.Y;
      Z = info.Z;
    }
  }

  public struct ParamCatMenu
  {
    public byte cat_id;
    public byte param_id;
    public byte param_name_len;
    public byte param_len;
    public string param_name;
    public DATA_TYPES param_type_code;
    public object param_data;
    public bool changed;
    public object new_data;
  }

  public struct MenuCatDrone
  {
    public byte id;
    public byte len_name;
    public byte count_param;
    public string name;
    public ParamCatMenu[] parameters;
  }

  public struct DroneSettings
  {
    public int countMenuCat;
    public int[]? catNamesLens;
    public MenuCatDrone[]? categories;
    public DroneSettings()
    {
      countMenuCat = 0;
    }

    public void update()
    {
      if (countMenuCat == 0) return;
      if (categories == null)
      {
        categories = new MenuCatDrone[countMenuCat];
      }
      if (MessageMenuCategories.categories == null) return;
      for (int i = 0; i < countMenuCat; i++)
      {
        MenuCategori cat = MessageMenuCategories.categories[i];
        categories[cat.id].id = cat.id;
        categories[cat.id].len_name = cat.len_name;
        categories[cat.id].count_param = cat.count_param;
        categories[cat.id].parameters = new ParamCatMenu[cat.count_param];
        categories[cat.id].name = MenuCategori.name[cat.id];
      }
    }
  }

  public struct DroneNullPoint
  {
    public bool saved;
    public double lat;
    public double lon;
    public double absAlt;

    public DroneNullPoint()
    {
      saved = false;
    }
  }

  public class Drone
  {
    public Drone() { }
    public ulong? Timeusec = null;
    public DroneNullPoint NullPoint = new DroneNullPoint();
    public DroneGPS gpsInfo = new DroneGPS();
    public DroneBattery batteryInfo = new DroneBattery();
    public DroneSys sysInfo = new DroneSys();
    public DroneGyro gyroInfo = new DroneGyro();
    public DroneAccel accelInfo = new DroneAccel();
    public DroneInertial inertialInfo = new DroneInertial();
    public DroneSettings settings = new DroneSettings();
    public DroneRawCalibData calibData = new DroneRawCalibData();
  }
}
