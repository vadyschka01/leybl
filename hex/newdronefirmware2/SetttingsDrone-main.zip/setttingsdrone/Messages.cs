﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.Design;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace SettingsDrone
{
  public enum MESSAGES_ID : byte
  {
    SysInfo = 1,
    GyroInfo = 2,
    AccelInfo = 3,
    GpsInfo = 4,
    InertialInfo = 5,
    BatteryInfo = 6,
    Ack = 7,
    StatusCommand = 8,
    StatusAllCommands = 9,
    Command = 10,
    RequestReg = 11,
    ResponseReg = 12,
    Auth = 13,
    OpenKey = 14,
    MissionCount = 15,
    MissionItem = 16,
    MissionItemAck = 17,
    MissionRequestItem = 18,
    RequestLastMessage = 19,
    ConnectionTest = 20,
    CountMenuCategories = 32,
    CategoriesMenu = 33,
    CategoriesParameters = 34,
    RawCalibData = 35
  };
  public enum COMMANDS_ID : byte
  {
    ChangeNav = 1,
    ChangeSpeed = 2,
    Land = 3,
    GoHome = 4,
    StopEngine = 5,
    StartEngine = 6,
    Pause = 7,
    Continue = 8,
    GoToGlobal = 9,
    GoToLocal = 10,
    SetParameter = 15,
    ProcessingCalibration = 16,
    SetCalibrationData = 17,
    MotorMoutionTest = 18
  };
  public enum ERROR_CODE_COMMAND : byte
  {
    No_error = 0,
    Speed_has_already_been_set = 1,
    Engines_are_already_running = 2,
    Engines_have_already_been_stopped = 3,
    UAV_is_already_on_the_ground = 4,
    UAV_is_already_landing = 5,
    UAV_is_already_moving = 6,
    Mission_has_not_been_launched = 7,
    Mission_is_already_on_pause = 8,
    Mission_was_not_on_pause = 9,
    Mission_was_not_launched = 10,
    This_NavSys_has_already_been_applied = 11,
    Lost_connection_with_controller = 12,
    The_command_is_canceled_when_a_new_one_is_received = 13,
    Error_reading_the_mission_file = 14,
    Error_validating_the_mission_file = 15,
    This_attack_event_already_exists = 16,
    Error_creating_the_configuration_file_moa = 17,
    Error_saving_the_configuration_file_moa = 18,
    Error_deleting_the_attack_event = 19,
    This_attack_event_cannot_be_deleted = 20,
    This_attack_event_does_not_exist = 21
  };
  public enum EXEC_CODE_COMMAND : byte
  {
    error = 0,
    in_progress = 1,
    completed = 2
  };
  public enum FEASIBILITY_CODE_COMMAND : byte
  {
    cannot_be_performed = 0,
    accepted = 1
  };
  public enum DATA_TYPES : byte
  {
    dt_char = 0,
    dt_unsigned_char = 1,
    dt_string = 2,
    dt_short = 3,
    dt_bool = 4,
    dt_unsigned_short = 5,
    dt_int = 6,
    dt_unsigned_int = 7,
    dt_long = 8,
    dt_unsigned_long = 9,
    dt_long_long = 10,
    dt_unsigned_long_long = 11,
    dt_float_32 = 12,
    dt_float_64 = 13,
    dt_unknown = 255
  };
  public enum SENSOR_ID : byte
  {
    ACC = 0,
    IMU_MAG = 1,
    EXTERNAL_MAG = 2,
    LEVEL_HOR = 3
  };
  public enum ENGINE_STATUS : byte
  {
    disable = 0,
    enable = 1
  };
  public enum STATUS_MODE : byte
  {
    on_ground = 1,
    taking_off = 2,
    fly = 3,
    landing = 4
  };
  public enum SYS_MODE : byte
  {
    take_off = 1,
    land = 2,
    go_home = 3,
    auto_mode = 4,
    hold = 5,
    manual = 6
  };
  public enum NAV_SYS_MODE : byte
  {
    inertial = 1,
    gps = 2,
    Optical_flow = 3
  };
  public enum GPS_FIX_TYPE : byte
  {
    NO_FIX = 0,
    TWO_D_FIX = 1,
    THREE_D_FIX = 2,
    DGPS = 4,
    RTK_FLOAT = 5,
    RTK_FIXED = 6,
    STATIC = 7,
    PPP = 8,
    NO_GPS = 9
  };

  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct HeaderBegin
  {
    public byte stx;
    public ushort len1; //Len header + payload (message)  ПОТОМ ДОЛЖНО БЫТЬ РАЗМЕРОМ ВСЕГО СООБЩЕНИЯ BEGIN+HEADER+PAYLOAD
    public ushort len2; //Len header + payload (message)
    public byte crc; // CRC MESSAGE

    static public int StrLen = Marshal.SizeOf(typeof(HeaderBegin));
    //---
  }
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct HeaderMessages
  {
    public MESSAGES_ID msgId;
    public byte srcId;
    public byte dstId;
    public byte len;
    public ulong timeusec;

    static public int StrLen = Marshal.SizeOf(typeof(HeaderMessages));
  }
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageGpsInfo
  {
    public double lat; //
    public double lon; //
    public float absAlt; //
    public float realAlt; //
    public float hdop; //
    public float vdop; //
    public float pdop; //
    public float noise; //
    public float jamming; //
    public byte satVisible;
    public byte satUsed; //
    public float speed; // 
    public GPS_FIX_TYPE fixType; // NO_GPS - 0, NO_FIX - 1, 2D_FIX - 2, 3D_FIX - 3, DGPS - 4, RTK_FLOAT - 5, RTK_FIXED - 6, STATIC - 7, PPP - 8
    public ulong timeUTC; // UTC - InfoGPS

    static public int StrLen = Marshal.SizeOf(typeof(MessageGpsInfo));
  }
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageBatteryInfo
  {
    public byte perCharge;
    public float voltage;
    public float amperage;
    public float temp;
    public float totalPower;
    public ulong timeRemaining;
  }
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct EnginePowerInfo
  {
    public byte power; //Текущая нагрузка на мотор от 0 до 100%
    public uint engineSpeed;//Текущие оборты в секунду мотора
    public float current; // Ток потребляемый мотором
    public float voltage; // Напряжение на моторе
    public float temp; // Температура мотора

    static public byte MaxCount = 8;
    static public int StrLen = Marshal.SizeOf(typeof(EnginePowerInfo));
  };

  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageSysInfo
  {
    public SYS_MODE mode;
    public STATUS_MODE statusMode;
    public NAV_SYS_MODE navSys;
    public ENGINE_STATUS engineStatus;
    public byte engineCount;
    public float pressureBaro;
    public float tempBaro;

    public static EnginePowerInfo[] enginePower;
    static public int StrLen = Marshal.SizeOf(typeof(MessageSysInfo));
  }
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageGyroInfo
  {
    public float yawGyroVel;
    public float pitchGyroVel;
    public float rollGyroVel;
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageAccelInfo
  {
    public float yawAccelVel;
    public float pitchAccelVel;
    public float rollAccelVel;
    public float aX;
    public float aY;
    public float aZ;
    public float tempAccel;
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageInertialInfo
  {
    public float x;
    public float y;
    public float z;
    public float headingDeg;
    public float speed;
    public float roll;
    public float pitch;
    public float yaw;
    public float rollVel;
    public float pitchVel;
    public float yawVel;
    public float baroAlt;
  }
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageCountMenuCategories
  {
    public byte countCategories;
    public static int[] data;

    static public int StrLen = Marshal.SizeOf(typeof(MessageCountMenuCategories));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageRawCalibData
  {
    public SENSOR_ID sensor;

    public float X;
    public float Y;
    public float Z;
    static public int StrLen = Marshal.SizeOf(typeof(MessageRawCalibData));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MenuCategori
  {
    public byte id;
    public byte len_name;
    public byte count_param;
    public static string[] name;

    static public int StrLen = Marshal.SizeOf(typeof(MenuCategori));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageMenuCategories
  {
    public byte countCategories;
    public static MenuCategori[] categories;

    static public int StrLen = Marshal.SizeOf(typeof(MessageMenuCategories));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageCategoriesParameters
  {
    public byte cat_id;
    public byte param_id;
    public byte param_name_len;
    public byte param_len;
    public DATA_TYPES param_type_code;

    public static string[][]? param_name;
    static public object[][]? param_data;
    static public int StrLen = Marshal.SizeOf(typeof(MessageCategoriesParameters));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageCommandSetParameter
  {
    public COMMANDS_ID commandId;

    public byte cat_id;
    public byte param_id;
    public DATA_TYPES param_type_code;
    public byte param_len;

    public static byte[]? param_data;

    static public int StrLen = Marshal.SizeOf(typeof(MessageCommandSetParameter));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageCommandAck
  {
    public COMMANDS_ID commandId;
    public FEASIBILITY_CODE_COMMAND status; // 0 - не может быть выполнена (указывается код ошибки), 1 - принята
    public ERROR_CODE_COMMAND errorCode;
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageStatusCommand
  {
    public COMMANDS_ID commandId;
    public EXEC_CODE_COMMAND executionCode; // 0 - ошибка при выполнении ,1 - выполняется ,2 - выполнена успешно.
    public ERROR_CODE_COMMAND errorCode;
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageCommandLand
  {
    public COMMANDS_ID commandId;
    static public int StrLen = Marshal.SizeOf(typeof(MessageCommandLand));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageCommandGoHome
  {
    public COMMANDS_ID commandId;
    static public int StrLen = Marshal.SizeOf(typeof(MessageCommandGoHome));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageCommandChangeNav
  {
    public COMMANDS_ID commandId;
    public NAV_SYS_MODE navMode;
    static public int StrLen = Marshal.SizeOf(typeof(MessageCommandChangeNav));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageCommandGoToLocal
  {
    public COMMANDS_ID commandId;
    public float x;
    public float y;
    public float z;
    public float speed;
    static public int StrLen = Marshal.SizeOf(typeof(MessageCommandGoToLocal));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageCommandSetSpeed
  {
    public COMMANDS_ID commandId;
    public float speed;
    static public int StrLen = Marshal.SizeOf(typeof(MessageCommandSetSpeed));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageCommandGoToGlobal
  {
    public COMMANDS_ID commandId;
    public double lat;
    public double lon;
    public float absAlt;
    public float speed;
    static public int StrLen = Marshal.SizeOf(typeof(MessageCommandGoToGlobal));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageCommandProcessingCalibration
  {
    public COMMANDS_ID commandId;

    public SENSOR_ID sensor_id;
    public bool start;
    static public int StrLen = Marshal.SizeOf(typeof(MessageCommandProcessingCalibration));
  };
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct MessageCommandSetCalibrationData
  {
    public COMMANDS_ID commandId;

    public SENSOR_ID sensor_id;
    static public int StrLen = Marshal.SizeOf(typeof(MessageCommandSetCalibrationData));
  };
  public struct MessageCommandMotorMoutionTest
  {
    public COMMANDS_ID commandId;

    public byte motor_id;
    static public int StrLen = Marshal.SizeOf(typeof(MessageCommandMotorMoutionTest));
  };
}
