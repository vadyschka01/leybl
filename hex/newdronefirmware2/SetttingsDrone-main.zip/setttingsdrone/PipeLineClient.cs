﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Pipes;

namespace SettingsDrone
{
    public class PipeLineClient : ConnectionInterface
    {
        string name;
        int TimeOutConnect = 1000; //msec
        NamedPipeClientStream pipe;
        public PipeLineClient(string name)
        {
            this.name = name;
        }

        public override void Connect()
        {
            try
            {
                PipeOptions pipeOptions = PipeOptions.Asynchronous;
                pipe = new NamedPipeClientStream(".", name, PipeDirection.InOut, pipeOptions);
                pipe.Connect(TimeOutConnect);
                pipe.ReadMode = PipeTransmissionMode.Byte;
                IsConnected = true;
            }
            catch (Exception e)
            {
                IsConnected = false;
                throw e;
            }
        }

        public override void Disconnect()
        {
            pipe.Close();
            IsConnected = false;
        }

        /// <summary>
		/// Рекурсивно запрашивает внутренние исключения, чтобы узнать первоисточник исключений.
		/// </summary>
		/// <returns>Исключение, которое не имеет вложенных исключений.</returns>
		private static Exception GetInnerException(Exception exception)
        {
            Exception currentException = exception;
            while (currentException.InnerException is not null)
            {
                currentException = currentException.InnerException;
            }
            return currentException;
        }

        public override byte[]? RecvData(int count)
        {
            if (!pipe.IsConnected) throw new Exception("Connection lost");
            byte[] data = new byte[count];
            using (CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(TimeSpan.FromMilliseconds(100)))
            {
                try
                {
                    var task = pipe.ReadAsync(data, 0, count, cancellationTokenSource.Token);
                    var r = task.Result;
                    return data;
                }
                catch (Exception ex)
                {
                    Exception innerException = GetInnerException(ex);
                    // Если исключение поднято токеном отмены операции - игнорируем.
                    if (innerException as OperationCanceledException is not null)
                    {
                        return null;
                    }
                    Console.WriteLine($"Error read data with pipeline client: {ex}");
                    return null;
                }
            }
        }

        public override bool SendData(byte[] data)
        {
            try
            {
                var res = pipe.WriteAsync(data, 0, data.Length).Wait(100);
                return res;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error write data to pipeLine client: {ex}");
                return false;
            }
        }
    }
}
