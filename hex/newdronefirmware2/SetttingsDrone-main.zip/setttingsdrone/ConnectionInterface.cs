﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SettingsDrone
{
    public abstract class ConnectionInterface
    {
        public bool IsConnected { get; set; }
        public abstract void Connect();
        public abstract void Disconnect();
        public abstract byte[]? RecvData(int count);
        public abstract bool SendData(byte[] data);
    }
}
