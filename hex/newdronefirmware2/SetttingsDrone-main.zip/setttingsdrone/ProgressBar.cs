﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SettingsDrone
{
  public partial class ProgressBar : Form
  {
    public bool active = false;
    int dinoSize;
    int cakeSize;
    int spaceSize;
    int totalSize;

    int countSpace;
    public ProgressBar()
    {
      TopMost = true;
      InitializeComponent();
      this.Text = "Progress load parameters";
      active = true;

      totalSize = (int)(this.Width * 2);

      dinoLabel.Text = "🐀";
      dinoSize = dinoLabel.Width;

      dinoLabel.Text = ".";
      spaceSize = dinoLabel.Width;

      dinoLabel.Text = "🧀";
      cakeSize = dinoLabel.Width;

      countSpace = (totalSize - dinoSize - cakeSize) / spaceSize;

      dinoLabel.Text = "";
    }
    private void OnProgressChanged(int progress)
    {
      progressBar1.Value = progress;
      LoadCatLabel.Text = $"Parameters loaded {progress}/{progressBar1.Maximum}";
      dinoLabel.Text = "";
      float prog = (float)progressBar1.Value / (float)progressBar1.Maximum;
      int index = (int)((float)countSpace * prog);
      index = countSpace - index;
      dinoLabel.Text = "🧀";
      for (int i = 0; i < countSpace + 1; i++)
      {
        if (i == index) dinoLabel.Text += "🐀";
        else dinoLabel.Text += ".";
      }

      if (progress >= progressBar1.Maximum)
      {
        this.Dispose();
      }
      return;
    }
    private void OnProgressMaxChanged(int max)
    {
      progressBar1.Maximum = max;
      LoadCatLabel.Text = $"Parameters loaded {progressBar1.Value}/{max}";
      return;
    }
  }
}
