﻿using System;
using System.Collections.Generic;

namespace SettingsDrone
{
  public struct Point3D
  {
    public double X { get; }
    public double Y { get; }
    public double Z { get; }

    public Point3D(double x, double y, double z)
    {
      X = x;
      Y = y;
      Z = z;
    }
  }

  public struct Sphere
  {
    public Point3D Center { get; }
    public Point3D Radii { get; }

    public bool calc = false;

    public Sphere(Point3D center, Point3D radii, bool calc)
    {
      Center = center;
      Radii = radii;
      this.calc = calc;
    }

    public Sphere() { }
  }

  public class SphereFitter
  {
    public Sphere Fit(List<Point3D> points)
    {
      if (points == null || points.Count < 6)
      {
        throw new ArgumentException("Для расчета эллипсоида требуется как минимум 6 точек.");
      }

      int n = points.Count;

      // Матрица M имеет 6 столбцов для коэффициентов (A, B, C, G, H, I)
      var M = new double[n, 6];
      // Вектор D - это вектор из единиц
      var D = new double[n, 1];

      for (int i = 0; i < n; i++)
      {
        var point = points[i];
        M[i, 0] = point.X * point.X;
        M[i, 1] = point.Y * point.Y;
        M[i, 2] = point.Z * point.Z;
        M[i, 3] = point.X;
        M[i, 4] = point.Y;
        M[i, 5] = point.Z;
        D[i, 0] = 1.0;
      }

      // Решаем систему M*p = D методом наименьших квадратов: p = (M^T * M)^-1 * (M^T * D)
      var Mt = MatrixHelper.Transpose(M);
      var MtM = MatrixHelper.Multiply(Mt, M);
      var MtD = MatrixHelper.Multiply(Mt, D);

      var MtM_inv = MatrixHelper.Invert(MtM);
      var p = MatrixHelper.Multiply(MtM_inv, MtD);

      // Извлекаем коэффициенты A, B, C, G, H, I
      double A = p[0, 0];
      double B = p[1, 0];
      double C = p[2, 0];
      double G = p[3, 0];
      double H = p[4, 0];
      double I = p[5, 0];

      // Преобразуем коэффициенты в параметры эллипсоида (центр и радиусы)
      // Методом "дополнения до полного квадрата"
      double centerX = -G / (2 * A);
      double centerY = -H / (2 * B);
      double centerZ = -I / (2 * C);

      // Вычисляем правую часть уравнения после преобразования
      double k = 1 + A * centerX * centerX + B * centerY * centerY + C * centerZ * centerZ;

      double radiusX = Math.Sqrt(k / A);
      double radiusY = Math.Sqrt(k / B);
      double radiusZ = Math.Sqrt(k / C);

      return new Sphere(new Point3D(centerX, centerY, centerZ), new Point3D(radiusX, radiusY, radiusZ), true);
    }
  }
}
