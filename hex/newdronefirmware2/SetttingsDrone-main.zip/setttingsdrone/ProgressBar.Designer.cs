﻿namespace SettingsDrone
{
  partial class ProgressBar
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;
    public int Progress
    {
      get
      {
        return progressBar1.Value;
      }
      set
      {
        Invoke(OnProgressChanged, value);
      }
    }
    public int ProgressMax
    {
      get
      {
        return progressBar1.Maximum;
      }
      set
      {
        Invoke(OnProgressMaxChanged, value);
      }
    }
    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      LoadCatLabel = new Label();
      dinoLabel = new Label();
      progressBar1 = new System.Windows.Forms.ProgressBar();
      SuspendLayout();
      // 
      // LoadCatLabel
      // 
      LoadCatLabel.AutoSize = true;
      LoadCatLabel.Location = new Point(14, 12);
      LoadCatLabel.Name = "LoadCatLabel";
      LoadCatLabel.Size = new Size(191, 25);
      LoadCatLabel.TabIndex = 1;
      LoadCatLabel.Text = "Parameters loaded 0/0";
      // 
      // dinoLabel
      // 
      dinoLabel.AutoSize = true;
      dinoLabel.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 204);
      dinoLabel.Location = new Point(14, 43);
      dinoLabel.Name = "dinoLabel";
      dinoLabel.Size = new Size(0, 38);
      dinoLabel.TabIndex = 2;
      // 
      // progressBar1
      // 
      progressBar1.Location = new Point(12, 99);
      progressBar1.Name = "progressBar1";
      progressBar1.Size = new Size(776, 26);
      progressBar1.TabIndex = 0;
      // 
      // ProgressBar
      // 
      AutoScaleDimensions = new SizeF(10F, 25F);
      AutoScaleMode = AutoScaleMode.Font;
      ClientSize = new Size(595, 90);
      Controls.Add(dinoLabel);
      Controls.Add(LoadCatLabel);
      Controls.Add(progressBar1);
      Name = "ProgressBar";
      Text = "Prgoress load parameters";
      ResumeLayout(false);
      PerformLayout();
    }

    #endregion
    private Label LoadCatLabel;
    private Label dinoLabel;
    private System.Windows.Forms.ProgressBar progressBar1;
  }
}