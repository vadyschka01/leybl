using GMap.NET;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using MessagePack;
using MessagePack.Resolvers;
using Microsoft.VisualBasic.Logging;
using Plot3D;
using System;
using System.Data.Common;
using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Ports;
using System.Reflection;
using System.Reflection.Metadata;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;

namespace SettingsDrone
{

  public partial class SettingsDrone : Form
  {
    enum AccColibrationState : byte
    {
      Stop,
      PX,
      MX,
      PY,
      MY,
      PZ,
      MZ,
      Complete
    }
    enum DataMode : byte
    {
      Begin,
      Head,
      Data
    };
    enum ConnectionType : byte
    {
      NOT,
      COM,
      Pipe
    }
    DataMode Mode = DataMode.Begin;
    static long Timer;
    static long LastTimeConnect;
    static int Wait = 1000; // ms
    DateTime TIMESTART;
    static long SECOND = 10000;

    static long LastTimeReq = 0;
    static long LastTimeReq2 = 0;
    static long LastTimeRecvMes = 0;
    static long LastTimeStatusCommandChange = 0;

    static int RecvMessages = 0;
    static int RecvBytes = 0;
    static string? CurrentStatusCommandText;

    static int FreqReqTelemGraph = 10; //Hz
    static int FreqReqTelem = 1; //Hz

    static double CurrentFreqRec = 0;
    static double CurrentSpdRecv = 0;

    static byte SRC_ID = 254;
    static int MAX_PAYLOAD_SIZE = 182;
    static byte DST_ID = 1;
    static byte Global_stx = 0xAA;
    static int MaxLength = 1024;
    static byte[] ProtoData = new byte[MaxLength];
    static ulong Length, Index;

    static ulong? LastTimeUsec = null;

    static ConnectionType connectionType = ConnectionType.NOT;
    static Drone drone = new Drone();
    static string LogDirPath = Path.Combine(System.Environment.CurrentDirectory, "logs");
    static string MAP_CACHE_PATH = Path.Combine(System.Environment.CurrentDirectory, "maps");
    ConnectionInterface? connection;
    ProgressBar? progress = null;
    static Thread? connectionHandler = null;
    static Thread? requestTelemetryThread = null;

    static bool recvGPS = false;
    static bool recvBat = false;
    static bool recvSys = false;
    static bool recvInner = false;
    static bool recvGyro = false;
    static bool recvAccel = false;

    static FileInfo logFile;
    static bool Logging = false;

    static bool WaitRequestProcessing = false;

    List<object> answersMessages = new List<object>();

    List<GroupBox> settingsBoxes = new List<GroupBox>();

    GMapMarker? SelectedMarker = null;
    bool isLeftButtonDown = false;
    bool onMarker = false;

    List<Plot3D.Graph3D.cScatter> MagData = new();
    List<Plot3D.Graph3D.cScatter> MagSphereChartData = new();
    List<Point3D> MagSphereData = new List<Point3D>();
    Sphere MagSphere = new Sphere();
    Sphere MagFiltSphere = new Sphere();

    SolidBrush PointColor = new SolidBrush(Color.Red);

    bool MagCharStart = false;

    bool SphereCalculation = false;

    static AccColibrationState ACC_COLIB_STATE = AccColibrationState.Stop;

    List<float> AccPXData = new List<float>();
    List<float> AccMXData = new List<float>();
    List<float> AccPYData = new List<float>();
    List<float> AccMYData = new List<float>();
    List<float> AccPZData = new List<float>();
    List<float> AccMZData = new List<float>();

    static float[] CALIB_X = [0, 0];
    static float[] CALIB_Y = [0, 0];
    static float[] CALIB_Z = [0, 0];

    static bool MAGSPHEREDISP = false;

    GMapOverlay MissionPoints = new GMapOverlay("Mission points");
    GMapOverlay routes = new GMapOverlay("Mission routes");
    List<PointLatLng> points = new List<PointLatLng>();
    static Bitmap DRONEIMAGE;

    public SettingsDrone()
    {
      InitializeComponent();

      //// �������� ������� ����������� ��� ����� �����
      //this.DoubleBuffered = true;

      //// ���� ����� SetStyle (����� ������, �� �������� �����)
      //this.SetStyle(ControlStyles.OptimizedDoubleBuffer |
      //              ControlStyles.AllPaintingInWmPaint |
      //              ControlStyles.UserPaint, true);
      //this.UpdateStyles();

      AddItemToCheckedBox(checkedListBoxGPS, "lat"); //0
      AddItemToCheckedBox(checkedListBoxGPS, "lon"); //1
      AddItemToCheckedBox(checkedListBoxGPS, "absAlt");//2
      AddItemToCheckedBox(checkedListBoxGPS, "realAlt");//3
      AddItemToCheckedBox(checkedListBoxGPS, "hdop");//4
      AddItemToCheckedBox(checkedListBoxGPS, "vdop");//5
      AddItemToCheckedBox(checkedListBoxGPS, "pdop");//6
      AddItemToCheckedBox(checkedListBoxGPS, "noise");//7
      AddItemToCheckedBox(checkedListBoxGPS, "jamming");//8

      AddItemToCheckedBox(checkedListBoxGPS2, "satVisible");//0
      AddItemToCheckedBox(checkedListBoxGPS2, "satUsed"); //1
      AddItemToCheckedBox(checkedListBoxGPS2, "speedGPS");//2
      AddItemToCheckedBox(checkedListBoxGPS2, "fixType");//3
      AddItemToCheckedBox(checkedListBoxGPS2, "timeUTC");//4

      AddItemToCheckedBox(checkedListBoxInertial, "x");//0
      AddItemToCheckedBox(checkedListBoxInertial, "y");//1
      AddItemToCheckedBox(checkedListBoxInertial, "z");//2
      AddItemToCheckedBox(checkedListBoxInertial, "headigDeg");//3
      AddItemToCheckedBox(checkedListBoxInertial, "speedInner");//4
      AddItemToCheckedBox(checkedListBoxInertial, "roll");//5
      AddItemToCheckedBox(checkedListBoxInertial, "pitch");//6
      AddItemToCheckedBox(checkedListBoxInertial, "yaw");//7
      AddItemToCheckedBox(checkedListBoxInertial, "rollVel");//8

      AddItemToCheckedBox(checkedListBoxInertial2, "pitchVel");//0
      AddItemToCheckedBox(checkedListBoxInertial2, "yawVel");//1
      AddItemToCheckedBox(checkedListBoxInertial2, "baroAlt");//2

      AddItemToCheckedBox(checkedListBoxAccel, "yawAccelVel");//0
      AddItemToCheckedBox(checkedListBoxAccel, "pitchAccelVel");//1
      AddItemToCheckedBox(checkedListBoxAccel, "rollAccelVel");//2
      AddItemToCheckedBox(checkedListBoxAccel, "aX");//3
      AddItemToCheckedBox(checkedListBoxAccel, "aY");//4
      AddItemToCheckedBox(checkedListBoxAccel, "aZ");//5
      AddItemToCheckedBox(checkedListBoxAccel, "tempAccel");//6

      AddItemToCheckedBox(checkedListBoxSys, "mode");//0
      AddItemToCheckedBox(checkedListBoxSys, "statusMode");//1
      AddItemToCheckedBox(checkedListBoxSys, "navSys");//2
      AddItemToCheckedBox(checkedListBoxSys, "engineStatus");//3
      AddItemToCheckedBox(checkedListBoxSys, "engineCount");//4
      AddItemToCheckedBox(checkedListBoxSys, "pressureBaro");//5
      AddItemToCheckedBox(checkedListBoxSys, "tempBaro");//6

      AddItemToCheckedBox(checkedListBoxGyro, "yawGyroVel");//0
      AddItemToCheckedBox(checkedListBoxGyro, "pitchGyroVel");//1
      AddItemToCheckedBox(checkedListBoxGyro, "rollGyroVel");//2

      AddItemToCheckedBox(checkedListBoxBattery, "perCharge");//0
      AddItemToCheckedBox(checkedListBoxBattery, "voltageBattery");//1
      AddItemToCheckedBox(checkedListBoxBattery, "amperage");//2
      AddItemToCheckedBox(checkedListBoxBattery, "tempBattery");//3
      AddItemToCheckedBox(checkedListBoxBattery, "totalPower");//4
      AddItemToCheckedBox(checkedListBoxBattery, "timeRemaining");//5

      LastTimeReq = GetTickCount();
      LastTimeReq2 = GetTickCount();
      LastTimeRecvMes = GetTickCount();
      LastTimeStatusCommandChange = GetTickCount();

      if (!Path.Exists(LogDirPath))
      {
        try
        {
          Directory.CreateDirectory(LogDirPath);
        }
        catch (Exception ex)
        {
          MessageBox.Show($"Error create log directory. {ex}", "Error create directory", MessageBoxButtons.OK, MessageBoxIcon.Error);
          textBoxLogFilePath.Enabled = false;
          buttonLogging.Enabled = false;
        }
      }

      DRONEIMAGE = ResizeImage(new Bitmap(Properties.Resources.drone), 100, 100);
      textBoxLogFilePath.Text = Path.Combine(LogDirPath, GetLogFileName());
      panel6.Size = new Size(662, 414);
      Size monitor = SystemInformation.PrimaryMonitorSize;
      if (monitor.Height > 1500)
      {
        panel6.Size = new Size(panel6.Width, panel6.Height + 300);
        DRONEIMAGE = ResizeImage(new Bitmap(Properties.Resources.drone), 200, 200);
      }
      ClientSize = new Size(groupBox1.Location.X + groupBox1.Width + 25, panel2.Location.Y + panel6.Height + groupBox4.Height + 50);
      tabControlSettingsMenu.Dock = DockStyle.Fill;
      TIMESTART = DateTime.Now;

      foreach (String p in SerialPort.GetPortNames())
      {
        COMBOX.Items.Add(p);
      }
      if (COMBOX.Items.Count > 0) COMBOX.SelectedIndex = 0;

      graph3d1.AxisX_Color = Color.Black;
      graph3d1.AxisY_Color = Color.Black;
      graph3d1.AxisZ_Color = Color.Black;
      graph3d1.AxisX_Legend = "X mag";
      graph3d1.AxisY_Legend = "Y mag";
      graph3d1.AxisZ_Legend = "Z mag";

      foreach (Control c in MagColibration.Controls) c.Enabled = false;
      foreach (Control c in AccColib.Controls) c.Enabled = false;
      SetLevelHor.Enabled = true;

      comboBoxSensors.SelectedIndex = 0;

      //panel10.BackColor = Color.FromArgb(127, 0, 0, 0);
      
      panel10.Parent = gMapControl1;
      //gMapControl1.Controls.Add(panel10);
      panel10.BringToFront();

      //gMapControl1.OnMapZoomChanged += () => panel10.Refresh();
      //gMapControl1.OnPositionChanged += (e) => panel10.Refresh();
    }

    //protected override CreateParams CreateParams
    //{
    //  get
    //  {
    //    CreateParams cp = base.CreateParams;
    //    cp.ExStyle |= 0x02000000; // WS_EX_COMPOSITED
    //    return cp;
    //  }
    //}

    public void SetDoubleBuffered(Control control)
  {
    // �������� ������ � ����������� �������� DoubleBuffered
    typeof(Control).InvokeMember("DoubleBuffered",
        BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
        null, control, new object[] { true });
  }
  public static Bitmap ResizeImage(Image image, int width, int height)
    {
      var destRect = new Rectangle(0, 0, width, height);
      var destImage = new Bitmap(width, height);
      destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);
      using (var graphics = Graphics.FromImage(destImage))
      {
        graphics.CompositingMode = CompositingMode.SourceCopy;
        graphics.CompositingQuality = CompositingQuality.HighQuality;
        graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
        graphics.SmoothingMode = SmoothingMode.HighQuality;
        graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
        using (var wrapMode = new ImageAttributes())
        {
          wrapMode.SetWrapMode(WrapMode.TileFlipXY);
          graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
        }
      }
      return destImage;
    }
    private string GetLogFileName()
    {
      return DateTime.Now.ToString().Replace(":", "_").Replace(" ", "_") + ".txt";
    }
    private void AddItemToCheckedBox(CheckedListBox box, string itemName)
    {
      ItemBoxCollection item = new ItemBoxCollection(itemName);
      box.Items.Add(item);
    }
    private void AddItemToCheckedBox(CheckedListBox box, string itemName, int count)
    {
      EngineItemsBoxCollection item = new EngineItemsBoxCollection(itemName, count);
      box.Items.Add(item);
    }
    private void ClearMagnetData()
    {
      MAGSPHEREDISP = false;
      MagCharStart = false;
      StartMagGraph.Text = "Start storage data";
      StartMagGraph.BackColor = Color.Transparent;
      MagSphereData.Clear();
      MagData.Clear();

      MagSphere = new Sphere();
      MagFiltSphere = new Sphere();

      SphereCalculation = false;

      MagSphereChartData.Clear();
      sphereTextBox.Text = "Sphere Radius:\r\n   X:\r\n   Y:\r\n   Z:\r\nSphere Center:\r\n   X:\r\n   Y:\r\n   Z:\r\n";
      textBox2.Text = "Min Sphere:\r\n   X:\r\n   Y:\r\n   Z:\r\nMax Sphere:\r\n   X:\r\n   Y:\r\n   Z:\r\n";
      textBox1.Text = "Filt Sphere Radius:\r\n   X:\r\n   Y:\r\n   Z:\r\nFilt Sphere Center:\r\n   X:\r\n   Y:\r\n   Z:\r\n";
    }
    private void PipeClientActive(bool act)
    {
      COMBOX.Enabled = !act;
      BAUDBOX.Enabled = !act;
      COMConnect.Enabled = !act;
      buttonGoToGlobal.Enabled = act;
      buttonSendGoToLocal.Enabled = act;
      buttonSendLand.Enabled = act;
      buttonSendGoHome.Enabled = act;
      buttonSendStop.Enabled = act;
      buttonChangeNav.Enabled = act;
      buttonSendSetSpeed.Enabled = act;
      foreach (Control c in MagColibration.Controls) c.Enabled = act;
      foreach (Control c in AccColib.Controls) c.Enabled = act;
      if (act) PipeLineConnect.Text = "Disconnect";
      else PipeLineConnect.Text = "Connect";
      if (!act)
      {
        foreach (System.Windows.Forms.DataVisualization.Charting.Series s in chart_Graph.Series)
        {
          s.Points.Clear();
        }
        ClearMagnetData();
      }
    }
    private void COMClientActive(bool act)
    {
      PipeLineConnect.Enabled = !act;
      AddressPipeLine.Enabled = !act;
      buttonGoToGlobal.Enabled = act;
      buttonSendGoToLocal.Enabled = act;
      buttonSendLand.Enabled = act;
      buttonSendGoHome.Enabled = act;
      buttonSendStop.Enabled = act;
      buttonChangeNav.Enabled = act;
      buttonSendSetSpeed.Enabled = act;
      foreach (Control c in MagColibration.Controls) c.Enabled = act;
      foreach (Control c in AccColib.Controls) c.Enabled = act;
      if (act) COMConnect.Text = "Disconnect";
      else COMConnect.Text = "Connect";
      if (!act)
      {
        foreach (System.Windows.Forms.DataVisualization.Charting.Series s in chart_Graph.Series)
        {
          s.Points.Clear();
        }
        ClearMagnetData();
      }
    }
    public static byte[] getBytes(object data)
    {
      int size = Marshal.SizeOf(data);
      byte[] arr = new byte[size];

      IntPtr ptr = IntPtr.Zero;
      try
      {
        ptr = Marshal.AllocHGlobal(size);
        Marshal.StructureToPtr(data, ptr, true);
        Marshal.Copy(ptr, arr, 0, size);
      }
      finally
      {
        Marshal.FreeHGlobal(ptr);
      }
      return arr;
    }
    public static object fromBytes(byte[] arr, int startIndex, Type type)
    {
      object mem = new object();

      int size = Marshal.SizeOf(type);
      IntPtr ptr = IntPtr.Zero;
      try
      {
        ptr = Marshal.AllocHGlobal(size);

        Marshal.Copy(arr, startIndex, ptr, size);

        mem = Marshal.PtrToStructure(ptr, type);
      }
      finally
      {
        Marshal.FreeHGlobal(ptr);
      }

      return mem;
    }
    public byte[] CreateRequestMessage(MESSAGES_ID id, byte[]? payload = null)
    {
      HeaderBegin headerBegin = new HeaderBegin();
      HeaderMessages headerMessages = new HeaderMessages();

      headerBegin.stx = Global_stx;
      ushort payloadSize = 0;
      if (payload != null) payloadSize = (ushort)payload.Length;
      headerBegin.len1 = (ushort)(((ushort)HeaderMessages.StrLen) + payloadSize);
      headerBegin.len2 = headerBegin.len1;

      headerMessages.msgId = id;
      headerMessages.srcId = SRC_ID;
      headerMessages.dstId = DST_ID;
      if (payload != null) headerMessages.len = (byte)payloadSize;
      else headerMessages.len = 0;
      headerMessages.timeusec = (ulong)GetTickCount();

      byte[] head = getBytes(headerMessages);
      if (payload != null) head = head.Concat(payload).ToArray();
      headerBegin.crc = SetCRC(headerBegin.len1, head);
      byte[] begin = getBytes(headerBegin);
      byte[] mes = begin.Concat(head).ToArray();
      return mes;
    }
    public bool CheckCRC(HeaderBegin begin, byte[] packet)
    {
      byte test = 0;
      for (ushort a = 0; a < begin.len1; a++) test ^= packet[a];
      return begin.crc == test;
    }
    public byte SetCRC(ushort len, byte[] packet)
    {
      byte test = 0;
      for (ushort a = 0; a < len; a++) test ^= packet[a];
      return test;
    }
    private void PipeLineConnect_Click(object sender, EventArgs e)
    {
      if (connection == null)
      {
        try
        {
          connection = new PipeLineClient(AddressPipeLine.Text);
          connection.Connect();
          if (connection.IsConnected)
          {
            PipeClientActive(true);
            connectionType = ConnectionType.Pipe;
            PipeLineConnect.BackColor = Color.LimeGreen;
            connectionHandler = new Thread(HandlerProto);
            connectionHandler.Start();
            TIMESTART = DateTime.Now;
            while (!this.IsHandleCreated) Thread.Sleep(100);
            Thread t = new Thread(HandlerShowProgres);
            t.Start();
            while (progress == null) Thread.Sleep(100);
            while (!progress.IsHandleCreated) Thread.Sleep(100);
            if (!SendRequestSettings())
            {
              connection.Disconnect();
              PipeLineConnect.BackColor = Color.Transparent;
              PipeClientActive(false);
              connection = null;
              if (Logging)
              {
                buttonLogging.BackColor = Color.Transparent;
                buttonLogging.Text = "Start log";
                Logging = false;
                textBoxLogFilePath.Text = Path.Combine(LogDirPath, GetLogFileName());
              }
              return;
            }
          }
        }
        catch (TimeoutException)
        {
          MessageBox.Show("Time out connect to Pipe Line.", "Error connect", MessageBoxButtons.OK, MessageBoxIcon.Error);
          connection = null;
          return;
        }
        catch (Exception ex)
        {
          MessageBox.Show($"Error connect to Pipe Line. {ex}", "Error connect", MessageBoxButtons.OK, MessageBoxIcon.Error);
          return;
        }
      }
      else
      {
        connection.Disconnect();
        PipeLineConnect.BackColor = Color.Transparent;
        PipeClientActive(false);
        connection = null;
        if (Logging)
        {
          buttonLogging.BackColor = Color.Transparent;
          buttonLogging.Text = "Start log";
          Logging = false;
          textBoxLogFilePath.Text = Path.Combine(LogDirPath, GetLogFileName());
        }
      }

    }
    private void COMConnect_Click(object sender, EventArgs e)
    {
      if (connection == null)
      {
        connection = new ComClient((string)COMBOX.SelectedItem, int.Parse((string)BAUDBOX.SelectedItem));
        connection.Connect();
        if (connection.IsConnected)
        {
          COMClientActive(true);
          COMConnect.BackColor = Color.LimeGreen;
          connectionType = ConnectionType.COM;
          connectionHandler = new Thread(HandlerProto);
          connectionHandler.Start();
          connectionHandler.Name = "GettingProtoDataThread";
          TIMESTART = DateTime.Now;
          while (!this.IsHandleCreated) Thread.Sleep(100);
          Thread t = new Thread(HandlerShowProgres);
          t.Start();
          while (progress == null) Thread.Sleep(100);
          while (!progress.IsHandleCreated) Thread.Sleep(100);
          if (!SendRequestSettings())
          {
            connection.Disconnect();
            COMConnect.BackColor = Color.Transparent;
            COMClientActive(false);
            connection = null;
            if (Logging)
            {
              buttonLogging.BackColor = Color.Transparent;
              buttonLogging.Text = "Start log";
              Logging = false;
              textBoxLogFilePath.Text = Path.Combine(LogDirPath, GetLogFileName());
            }
            return;
          }
        }
        else
        {
          COMClientActive(false);
          connection = null;
          MessageBox.Show("Error connect to COM port.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
      }
      else
      {
        connection.Disconnect();
        COMConnect.BackColor = Color.Transparent;
        COMClientActive(false);
        connection = null;
        if (Logging)
        {
          buttonLogging.BackColor = Color.Transparent;
          buttonLogging.Text = "Start log";
          Logging = false;
          textBoxLogFilePath.Text = Path.Combine(LogDirPath, GetLogFileName());
        }
      }
    }
    private void COMBOX_DropDown(object sender, EventArgs e)
    {
      COMBOX.Items.Clear();
      foreach (String p in SerialPort.GetPortNames())
      {
        COMBOX.Items.Add(p);
      }
    }
    private void HandlerProto()
    {
      LastTimeReq = GetTickCount();
      requestTelemetryThread = new Thread(RequestTelemetry);
      requestTelemetryThread.Start();
      while (connection != null && connection.IsConnected)
      {
        try
        {
          byte[]? b = connection.RecvData(1);
          if (b != null)
          {
            for (int i = 0; i < b.Length; i++) ProcessingData(b[i]);
          }
        }
        catch (Exception ex)
        {
          MessageBox.Show($"{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
          if (connection == null) return;
          connection.Disconnect();
          connection = null;
        }
      }
    }
    long GetTickCount()
    {
      return (long)(DateTime.Now.Ticks / 1000);
    }
    private bool CheckCheckBox(CheckedListBox box)
    {
      if (box.CheckedItems.Count > 0) return true;
      else return false;
    }
    private bool SendRequestSettings()
    {
      if (connection == null || !connection.IsConnected) return false;
      WaitRequestProcessing = true;

      object? mesObj = null;
      byte[] mes = CreateRequestMessage(MESSAGES_ID.CountMenuCategories);
      mesObj = SendAndWait(mes, typeof(MessageCountMenuCategories), mes);
      if (mesObj == null)
      {
        WaitRequestProcessing = false;
        MessageBox.Show("Error get settings drone. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        if (progress != null) progress.Progress = progress.ProgressMax;
        return false;
      }
      MessageCountMenuCategories catCount = (MessageCountMenuCategories)mesObj;
      drone.settings.countMenuCat = catCount.countCategories;
      MessageCategoriesParameters.param_data = new object[drone.settings.countMenuCat][];
      MessageCategoriesParameters.param_name = new string[drone.settings.countMenuCat][];
      drone.settings.catNamesLens = MessageCountMenuCategories.data;

      List<List<int>> requestPool = new List<List<int>>();
      int size = 1;
      List<int> requestCats = new List<int>();
      for (int id_cat = 0; id_cat < catCount.countCategories; id_cat++)
      {
        size += 3;
        size += drone.settings.catNamesLens[id_cat];
        if (size < MAX_PAYLOAD_SIZE) requestCats.Add(id_cat);
        else
        {
          requestPool.Add([.. requestCats]);
          requestCats.Clear();
          requestCats.Add(id_cat);
          size = 4 + drone.settings.catNamesLens[id_cat];
        }
      }
      requestPool.Add([.. requestCats]);
      requestCats.Clear();

      for (int i = 0; i < requestPool.Count; i++)
      {
        List<int> cats = requestPool[i];
        byte[] payload = new byte[1 + 2 * cats.Count];
        payload[0] = (byte)cats.Count;
        int indexP = 1;
        for (int j = 0; j < cats.Count; j++)
        {

          payload[indexP] = (byte)cats[j];
          payload[indexP + 1] = 0;
          indexP += 2;
        }
        byte[] mesReq = CreateRequestMessage(MESSAGES_ID.CategoriesMenu, payload);
        mesObj = SendAndWait(mesReq, typeof(MessageMenuCategories), payload);
        if (mesObj == null)
        {
          WaitRequestProcessing = false;
          MessageBox.Show("Error get settings drone. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
          if (progress != null) progress.Progress = progress.ProgressMax;
          return false;
        }
        MessageMenuCategories msgMenuCat = (MessageMenuCategories)mesObj;
        drone.settings.update();
      }
      if (progress != null) progress.ProgressMax = drone.settings.countMenuCat;
      for (int catId = 0; catId < drone.settings.countMenuCat; catId++)
      {
        if (progress != null) progress.ProgressMax = progress.ProgressMax + drone.settings.categories[catId].count_param;
        MessageCategoriesParameters.param_data[catId] = new object[drone.settings.categories[catId].count_param];
        MessageCategoriesParameters.param_name[catId] = new string[drone.settings.categories[catId].count_param];
      }

      for (int catId = 0; catId < drone.settings.countMenuCat; catId++)
      {
        for (int paramId = 0; paramId < drone.settings.categories[catId].count_param; paramId++)
        {
          byte[] payload = [(byte)catId, (byte)paramId];
          byte[] mesReq = CreateRequestMessage(MESSAGES_ID.CategoriesParameters, payload);
          mesObj = SendAndWait(mesReq, typeof(MessageCategoriesParameters), payload);
          if (mesObj == null)
          {
            WaitRequestProcessing = false;
            MessageBox.Show("Error get settings drone. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            if (progress != null) progress.Progress = progress.ProgressMax;
            return false;
          }
          MessageCategoriesParameters msgCatParam = (MessageCategoriesParameters)mesObj;
          drone.settings.categories[catId].parameters[paramId].cat_id = msgCatParam.cat_id;
          drone.settings.categories[catId].parameters[paramId].param_id = msgCatParam.param_id;
          drone.settings.categories[catId].parameters[paramId].param_name_len = msgCatParam.param_name_len;
          drone.settings.categories[catId].parameters[paramId].param_len = msgCatParam.param_len;
          drone.settings.categories[catId].parameters[paramId].param_type_code = msgCatParam.param_type_code;
          drone.settings.categories[catId].parameters[paramId].param_name = MessageCategoriesParameters.param_name[msgCatParam.cat_id][msgCatParam.param_id];
          drone.settings.categories[catId].parameters[paramId].param_data = MessageCategoriesParameters.param_data[msgCatParam.cat_id][msgCatParam.param_id];
          drone.settings.categories[catId].parameters[paramId].changed = false;
          if (progress != null) progress.Progress += 1;
        }
        if (progress != null) progress.Progress += 1;
      }
      WaitRequestProcessing = false;
      return true;
    }
    private object? WaitAnswerMessage(Type msgType, byte[] payload, int timeoutmillsec = 1000)
    {
      long TimeStart = GetTickCount();
      while (GetTickCount() - TimeStart < timeoutmillsec)
      {
        if (answersMessages.Count > 0)
        {
          var tempAnswersMessages = answersMessages.ToArray();
          for (int i = 0; i < tempAnswersMessages.Length; i++)
          {
            try
            {
              // ���� ��� ��� ��������
              if (tempAnswersMessages[i] == null) continue;
              if (tempAnswersMessages[i].GetType() == msgType)
              {
                object mes = tempAnswersMessages[i];
                if (msgType == typeof(MessageCategoriesParameters))
                {
                  MessageCategoriesParameters mesObj = (MessageCategoriesParameters)mes;
                  if (mesObj.cat_id != payload[0])
                  {
                    answersMessages.Remove(mes);
                    answersMessages.Clear();
                    continue;
                  }
                  if (mesObj.param_id != payload[1])
                  {
                    answersMessages.Remove(mes);
                    answersMessages.Clear();
                    continue;
                  }
                }
                else if (msgType == typeof(MessageCommandAck))
                {
                  MessageCommandAck mesObj = (MessageCommandAck)mes;
                  if (mesObj.commandId != (COMMANDS_ID)payload[0])
                  {
                    answersMessages.Remove(mes);
                    answersMessages.Clear();
                    continue;
                  }
                }
                else if (msgType == typeof(MessageStatusCommand))
                {
                  MessageStatusCommand mesObj = (MessageStatusCommand)mes;
                  if (mesObj.commandId != (COMMANDS_ID)payload[0])
                  {
                    answersMessages.Remove(mes);
                    answersMessages.Clear();
                    continue;
                  }
                }
                answersMessages.Remove(mes);
                answersMessages.Clear();
                return mes;
              }
            }
            catch (Exception ex)
            {
              continue;
            }
            ;
          }
        }
      }
      return null;
    }
    private object? SendAndWait(byte[] message, Type msgType, byte[] payload, int countAttemps = 100)
    {
      while (countAttemps >= 0)
      {
        if (connection == null || !connection.IsConnected) return null;
        connection.SendData(message);
        object? mesObj = WaitAnswerMessage(msgType, payload);
        if (mesObj == null)
        {
          countAttemps -= 1;
          continue;
        }
        else return mesObj;
      }
      return null;
    }
    private void RequestTelemetry()
    {
      if (connection == null || !connection.IsConnected) return;

      byte[] mes = CreateRequestMessage(MESSAGES_ID.SysInfo);
      connection.SendData(mes);

      while (connection != null && connection.IsConnected)
      {
        if (WaitRequestProcessing)
        {
          Thread.Sleep(500);
          if (connection == null || !connection.IsConnected) return;
          continue;
        }
        List<byte[]> messagesPool = new List<byte[]>();
        long Tick = GetTickCount() - LastTimeReq;
        if (connection != null && (connection.IsConnected) && (Tick >= SECOND / (long)FreqReqTelemGraph))
        {
          if (recvGPS)
          {
            messagesPool.Add(CreateRequestMessage(MESSAGES_ID.GpsInfo));
          }
          if (recvSys)
          {
            messagesPool.Add(CreateRequestMessage(MESSAGES_ID.SysInfo));
          }
          if (recvAccel)
          {
            messagesPool.Add(CreateRequestMessage(MESSAGES_ID.AccelInfo));
          }
          if (recvGyro)
          {
            messagesPool.Add(CreateRequestMessage(MESSAGES_ID.GyroInfo));
          }
          if (recvInner)
          {
            messagesPool.Add(CreateRequestMessage(MESSAGES_ID.InertialInfo));
          }
          if (recvBat)
          {
            messagesPool.Add(CreateRequestMessage(MESSAGES_ID.BatteryInfo));
          }
          LastTimeReq = GetTickCount();
        }
        long Tick2 = GetTickCount() - LastTimeReq2;
        if (connection != null && (connection.IsConnected) && (FreqReqTelem != 0) && (Tick2 >= SECOND / (long)FreqReqTelem))
        {
          if (!recvGPS)
          {
            messagesPool.Add(CreateRequestMessage(MESSAGES_ID.GpsInfo));
          }
          if (!recvSys)
          {
            messagesPool.Add(CreateRequestMessage(MESSAGES_ID.SysInfo));
          }
          if (!recvAccel)
          {
            messagesPool.Add(CreateRequestMessage(MESSAGES_ID.AccelInfo));
          }
          if (!recvGyro)
          {
            messagesPool.Add(CreateRequestMessage(MESSAGES_ID.GyroInfo));
          }
          if (!recvInner)
          {
            messagesPool.Add(CreateRequestMessage(MESSAGES_ID.InertialInfo));
          }
          if (!recvBat)
          {
            messagesPool.Add(CreateRequestMessage(MESSAGES_ID.BatteryInfo));
          }
          LastTimeReq2 = GetTickCount();
        }
        for (int i = 0; i < messagesPool.Count; i++)
        {
          if (connection == null) return;
          connection?.SendData(messagesPool[i]);
        }
      }
    }
    private bool ProcessingData(byte data)
    {
      long tick = GetTickCount();
      //if ((Mode != DataMode.Begin) && (tick - Timer > Wait))
      //{
      //  Mode = DataMode.Begin;
      //  Console.WriteLine("Error: Timeout");
      //}
      Timer = tick;
      switch (Mode)
      {
        case DataMode.Begin:
          {
            if (data != Global_stx) return true;
            Index = 0;
            ProtoData[Index++] = data;
            Length = (ulong)HeaderBegin.StrLen;
            Mode = DataMode.Head;
            return true;
          }

        case DataMode.Head:
          {
            ProtoData[Index++] = data;
            if (Index < Length) return true;

            HeaderBegin begin = (HeaderBegin)fromBytes(ProtoData, 0, typeof(HeaderBegin));

            if ((begin.len1 != begin.len2) || (begin.len1 > MaxLength)
              || (begin.len1 < HeaderMessages.StrLen) || Index < (ulong)HeaderBegin.StrLen)
            {
              Console.WriteLine($"Error: HeaderBegin -> size={begin.len1}");
              Mode = DataMode.Begin;
              return true;
            }

            Mode = DataMode.Data;
            Length += begin.len1;

            return true;
          }

        case DataMode.Data:
          {
            ProtoData[Index++] = data;
            if (Index < Length) return true;

            HeaderBegin begin = (HeaderBegin)fromBytes(ProtoData, 0, typeof(HeaderBegin));

            byte[] headerData = new byte[HeaderMessages.StrLen];
            Array.Copy(ProtoData, HeaderBegin.StrLen, headerData, 0, HeaderMessages.StrLen);

            HeaderMessages header = (HeaderMessages)fromBytes(headerData, 0, typeof(HeaderMessages));

            byte[]? payload = null;
            if (header.len > 0)
            {
              payload = new byte[header.len];
              Array.Copy(ProtoData, (HeaderMessages.StrLen + HeaderBegin.StrLen), payload, 0, header.len);
            }

            if (payload != null) headerData = headerData.Concat(payload).ToArray();

            Mode = DataMode.Begin;
            if (begin.len1 != HeaderMessages.StrLen + header.len)
            {
              Console.WriteLine($"Error: HeaderBegin->len {begin.len1} != HeaderMessages.len + payload_len {HeaderMessages.StrLen + header.len}");
              return false;
            }
            try
            {
              if (!CheckCRC(begin, headerData))
              {
                Console.WriteLine("Error: HeaderBegin -> CRC");
                return true;
              }
            }
            catch (Exception e)
            {
              Console.WriteLine($"Error cheeck CRC: {e.Message}");
              return true;
            }
            RecvMessages += 1;
            if (payload != null) RecvBytes += HeaderBegin.StrLen + HeaderMessages.StrLen + payload.Length;
            else RecvBytes += HeaderBegin.StrLen + HeaderMessages.StrLen;
            ProcessingMessage(header, payload);
            long Tick3 = GetTickCount() - LastTimeRecvMes;
            if (Tick3 >= SECOND)
            {
              CurrentFreqRec = Math.Round((RecvMessages / ((float)Tick3 / SECOND)), 2);
              CurrentSpdRecv = Math.Round(((float)RecvBytes / 1024) / ((float)Tick3 / SECOND), 2);
              RecvMessages = 0;
              RecvBytes = 0;
              LastTimeRecvMes = GetTickCount();
            }
            return true;
          }
      }
      return false;
    }
    // ����������� �������� � �������
    private float Deg2Rad(float Deg)
    {
      return Deg * (float)Math.PI / 180.0f;
    }
    // ����������� ������ � �������
    private float Rad2Deg(float Rad)
    {
      return Rad * 180.0f / (float)Math.PI;
    }
    private void LocalToGlobal(float x, float y, ref float Olat, ref float Olon, out float lat, out float lon)
    {
      // ���������� ����� ������
      lat = Rad2Deg(Deg2Rad(Olat) + (x / 6371000.0f));
      // ���������� ����� ������� (� �������������� ������� ������ ��� ��������)
      lon = Olon + Rad2Deg(y / (6371000.0f * (float)Math.Cos((Deg2Rad(Olat) + (Deg2Rad(Olat) + (x / 6371000.0f))) / 2.0)));
      return;
    }
    public void ProcessingMessage(HeaderMessages header, byte[]? payload)
    {
      drone.Timeusec = header.timeusec;
      switch (header.msgId)
      {
        case MESSAGES_ID.GpsInfo:
          {
            MessageGpsInfo gps = (MessageGpsInfo)fromBytes(payload, 0, typeof(MessageGpsInfo));
            drone.gpsInfo.update(gps);
            if (!drone.NullPoint.saved && drone.sysInfo.statusMode != 0)
            {
              if (drone.sysInfo.statusMode == STATUS_MODE.on_ground)
              {
                drone.NullPoint.saved = true;
                drone.NullPoint.lat = gps.lat;
                drone.NullPoint.lon = gps.lon;
                drone.NullPoint.absAlt = gps.absAlt;
              }
              else
              {
                drone.NullPoint.saved = true;
                float lat = (float)gps.lat;
                float lon = (float)gps.lon;
                float nullLat;
                float nullLon;
                LocalToGlobal(drone.inertialInfo.x, drone.inertialInfo.y, ref lat, ref lon, out nullLat, out nullLon);
                drone.NullPoint.lat = (double)nullLat;
                drone.NullPoint.lon = (double)nullLon;
                drone.NullPoint.absAlt = gps.absAlt - gps.realAlt;
              }
            }
            return;
          }
        case MESSAGES_ID.BatteryInfo:
          {
            MessageBatteryInfo bat = (MessageBatteryInfo)fromBytes(payload, 0, typeof(MessageBatteryInfo));
            drone.batteryInfo.update(bat);
            return;
          }
        case MESSAGES_ID.GyroInfo:
          {
            MessageGyroInfo gyr = (MessageGyroInfo)fromBytes(payload, 0, typeof(MessageGyroInfo));
            drone.gyroInfo.update(gyr);
            return;
          }
        case MESSAGES_ID.AccelInfo:
          {
            MessageAccelInfo accel = (MessageAccelInfo)fromBytes(payload, 0, typeof(MessageAccelInfo));
            drone.accelInfo.update(accel);
            return;
          }
        case MESSAGES_ID.InertialInfo:
          {
            MessageInertialInfo iner = (MessageInertialInfo)fromBytes(payload, 0, typeof(MessageInertialInfo));
            drone.inertialInfo.update(iner);
            return;
          }
        case MESSAGES_ID.SysInfo:
          {
            MessageSysInfo sysInfo = (MessageSysInfo)fromBytes(payload, 0, typeof(MessageSysInfo));
            MessageSysInfo.enginePower = new EnginePowerInfo[sysInfo.engineCount];
            for (int i = 0; i < sysInfo.engineCount; i++)
            {

              EnginePowerInfo eng = (EnginePowerInfo)fromBytes(payload, MessageSysInfo.StrLen + i * EnginePowerInfo.StrLen, typeof(EnginePowerInfo));
              MessageSysInfo.enginePower[i] = eng;
            }
            drone.sysInfo.update(sysInfo);
            return;
          }
        case MESSAGES_ID.CountMenuCategories:
          {
            MessageCountMenuCategories catCount = (MessageCountMenuCategories)fromBytes(payload, 0, typeof(MessageCountMenuCategories));
            MessageCountMenuCategories.data = new int[catCount.countCategories];
            for (int i = 0; i < catCount.countCategories; i++)
            {
              MessageCountMenuCategories.data[i] = (int)payload[i + MessageCountMenuCategories.StrLen];
            }
            answersMessages.Add(catCount);
            return;
          }
        case MESSAGES_ID.CategoriesMenu:
          {
            if (drone.settings.countMenuCat == 0) return;
            MessageMenuCategories msgCatMenu = (MessageMenuCategories)fromBytes(payload, 0, typeof(MessageMenuCategories));

            if (MessageMenuCategories.categories == null)
            {
              MenuCategori.name = new string[drone.settings.countMenuCat];
              MessageMenuCategories.categories = new MenuCategori[drone.settings.countMenuCat];
            }

            int totalNamesLens = 0;
            for (int i = 0; i < msgCatMenu.countCategories; i++)
            {
              int startIndex = MessageMenuCategories.StrLen + i * MenuCategori.StrLen + totalNamesLens;
              MenuCategori cat = (MenuCategori)fromBytes(payload, startIndex, typeof(MenuCategori));

              startIndex += MenuCategori.StrLen;
              string namestr = GetStringByByteArray(payload[startIndex..(startIndex + cat.len_name)]);

              MenuCategori.name[cat.id] = namestr;
              MessageMenuCategories.categories[cat.id] = cat;
              totalNamesLens += cat.len_name;
            }
            answersMessages.Add(msgCatMenu);
            return;
          }
        case MESSAGES_ID.CategoriesParameters:
          {
            MessageCategoriesParameters parameter = (MessageCategoriesParameters)fromBytes(payload, 0, typeof(MessageCategoriesParameters));

            int startIndex = MessageCategoriesParameters.StrLen;
            string namestr = GetStringByByteArray(payload[startIndex..(startIndex + parameter.param_name_len)]);
            startIndex += parameter.param_name_len;

            byte[] param_data = payload[startIndex..(startIndex + parameter.param_len)];
            object? paramObject = null;
            using (BinaryReader reader = new BinaryReader(new MemoryStream(param_data)))
            {
              switch (parameter.param_type_code)
              {
                case DATA_TYPES.dt_int:
                  {
                    paramObject = reader.ReadInt32();
                    break;
                  }
                case DATA_TYPES.dt_char:
                  {
                    paramObject = reader.ReadByte();
                    break;
                  }
                case DATA_TYPES.dt_short:
                  {
                    paramObject = reader.ReadInt16();
                    break;
                  }
                case DATA_TYPES.dt_unsigned_char:
                  {
                    paramObject = reader.ReadByte();
                    break;
                  }
                case DATA_TYPES.dt_unsigned_int:
                  {
                    paramObject = reader.ReadUInt32();
                    break;
                  }
                case DATA_TYPES.dt_long_long:
                  {
                    paramObject = reader.ReadInt64();
                    break;
                  }
                case DATA_TYPES.dt_long:
                  {
                    paramObject = reader.ReadInt32();
                    break;
                  }
                case DATA_TYPES.dt_float_32:
                  {
                    paramObject = reader.ReadSingle();
                    break;
                  }
                case DATA_TYPES.dt_float_64:
                  {
                    paramObject = reader.ReadDouble();
                    break;
                  }
                case DATA_TYPES.dt_bool:
                  {
                    paramObject = reader.ReadBoolean();
                    break;
                  }
                case DATA_TYPES.dt_unsigned_short:
                  {
                    paramObject = reader.ReadUInt16();
                    break;
                  }
                case DATA_TYPES.dt_unsigned_long:
                  {
                    paramObject = reader.ReadUInt32();
                    break;
                  }
                case DATA_TYPES.dt_unsigned_long_long:
                  {
                    paramObject = reader.ReadUInt64();
                    break;
                  }
                case DATA_TYPES.dt_string:
                  {
                    paramObject = reader.ReadString();
                    break;
                  }
              }

            }
            try
            {
              MessageCategoriesParameters.param_data[parameter.cat_id][parameter.param_id] = paramObject;
              MessageCategoriesParameters.param_name[parameter.cat_id][parameter.param_id] = namestr;
            }
            catch (Exception)
            {
              Console.WriteLine($"Error add parameter.. cat_id: {parameter.cat_id}, param_id: {parameter.param_id}");
            }
            answersMessages.Add(parameter);
            return;
          }
        case MESSAGES_ID.Ack:
          {
            MessageCommandAck ack = (MessageCommandAck)fromBytes(payload, 0, typeof(MessageCommandAck));
            answersMessages.Add(ack);
            return;
          }
        case MESSAGES_ID.StatusCommand:
          {
            MessageStatusCommand status = (MessageStatusCommand)fromBytes(payload, 0, typeof(MessageStatusCommand));
            answersMessages.Add(status);
            return;
          }
        case MESSAGES_ID.ConnectionTest:
          {
            LastTimeConnect = GetTickCount();
            return;
          }
        case MESSAGES_ID.RawCalibData:
          {
            MessageRawCalibData calibData = (MessageRawCalibData)fromBytes(payload, 0, typeof(MessageRawCalibData));
            drone.calibData.update(calibData);
            return;
          }
      }
    }
    private string GetStringByByteArray(byte[] bytes)
    {
      string str = "";
      for (int j = 0; j < bytes.Length; j++)
      {
        str += (char)bytes[j];
      }
      return str;
    }
    private void button_Graph_Fixed_Click(object sender, EventArgs e)
    {
      Decimal min = new Decimal(chart_Graph.ChartAreas[0].AxisY.Minimum);
      Decimal max = new Decimal(chart_Graph.ChartAreas[0].AxisY.Maximum);

      numericUpDown_Graph_Min.Value = min;
      numericUpDown_Graph_Max.Value = max;

      checkBox_Graph_Auto.Checked = false;
      checkBox_Graph_Scale.Checked = false;
    }
    private void numericUpDown_Graph_Min_ValueChanged(object sender, EventArgs e)
    {
      chart_Graph.ChartAreas[0].AxisY.Interval = (double)numericUpDown_Graph_Interval.Value;

      if (checkBox_Graph_Auto.Checked)
      {
        chart_Graph.ChartAreas[0].AxisY.Minimum = double.NaN;
        chart_Graph.ChartAreas[0].AxisY.Maximum = double.NaN;

        return;
      }

      double min = (double)numericUpDown_Graph_Min.Value;
      double max = (double)numericUpDown_Graph_Max.Value;

      if (min > max)
      {
        max = (double)numericUpDown_Graph_Min.Value;
        min = (double)numericUpDown_Graph_Max.Value;
      }

      if (min + 1 >= max) max = min + 1;

      chart_Graph.ChartAreas[0].AxisY.Minimum = min;
      chart_Graph.ChartAreas[0].AxisY.Maximum = max;
    }
    private string GraphUpdate(CheckedListBox box, int index, float data, double past, double future)
    {
      ItemBoxCollection item = (ItemBoxCollection)box.Items[index];
      string logItem = "";
      if (item.check)
      {
        System.Windows.Forms.DataVisualization.Charting.DataPointCollection p = item.ser.Points;
        while (p.Count > 0 && p[0].XValue < past) p.RemoveAt(0);

        p.AddXY(future, data);
        logItem = $"{item.name}:{data};";
      }
      return logItem;
    }
    private string GraphUpdate(CheckedListBox box, int index, double[] data, double past, double future)
    {
      string logItem = "";
      EngineItemsBoxCollection item = (EngineItemsBoxCollection)box.Items[index];
      if (item.check)
      {
        for (int i = 0; i < item.ser.Length; i++)
        {
          System.Windows.Forms.DataVisualization.Charting.DataPointCollection p = item.ser[i].Points;
          while (p.Count > 0 && p[0].XValue < past) p.RemoveAt(0);

          p.AddXY(future, data[i]);
          logItem += $"{item.name}_{i}:{data[i]};";
        }
      }
      return logItem;
    }
    private void timer1_Tick(object sender, EventArgs e)
    {
      if (connection == null)
      {
        if (connectionType == ConnectionType.Pipe)
        {
          PipeLineConnect.BackColor = Color.Transparent;
          PipeClientActive(false);
          drone.Timeusec = null;
          connectionType = ConnectionType.NOT;
          if (Logging)
          {
            buttonLogging.BackColor = Color.Transparent;
            buttonLogging.Text = "Start log";
            Logging = false;
            textBoxLogFilePath.Text = Path.Combine(LogDirPath, GetLogFileName());
          }
        }
        else if (connectionType == ConnectionType.COM)
        {
          COMConnect.BackColor = Color.Transparent;
          COMClientActive(false);
          drone.Timeusec = null;
          connectionType = ConnectionType.NOT;
          if (Logging)
          {
            buttonLogging.BackColor = Color.Transparent;
            buttonLogging.Text = "Start log";
            Logging = false;
            textBoxLogFilePath.Text = Path.Combine(LogDirPath, GetLogFileName());
          }
        }
        SetTelemetry(true);
        return;
      }
      if (drone.Timeusec == null) return;

      //long Tick3 = GetTickCount() - LastTimeRecvMes;
      //if (Tick3 >= SECOND)
      //{
      //  CurrentFreqRec = Math.Round((RecvMessages / ((float)Tick3 / SECOND)), 2);
      //  CurrentSpdRecv = Math.Round(((float)RecvBytes / 1024) / ((float)Tick3 / SECOND), 2);
      //  RecvMessages = 0;
      //  RecvBytes = 0;
      //  LastTimeRecvMes = GetTickCount();
      //}

      long Tick4 = GetTickCount() - LastTimeStatusCommandChange;
      if ((Tick4 >= SECOND * 10) && (commandStatusLabel.Text != "-"))
      {
        SetStatusCommandLabel("-", Color.Black, "-");
      }
      else if (commandStatusLabel.Text != "-")
      {
        commandStatusLabel.Text = CurrentStatusCommandText + $" ({(int)((SECOND * 10 - Tick4) / SECOND)}...)";
      }

      SPDRX.Text = $"{CurrentSpdRecv} KB/s";
      HzRecvTelem.Text = $"{CurrentFreqRec} Hz";
      double reqHz = 0;

      if (recvGPS) reqHz += FreqReqTelemGraph;
      else reqHz += FreqReqTelem;
      if (recvSys) reqHz += FreqReqTelemGraph;
      else reqHz += FreqReqTelem;
      if (recvAccel) reqHz += FreqReqTelemGraph;
      else reqHz += FreqReqTelem;
      if (recvGyro) reqHz += FreqReqTelemGraph;
      else reqHz += FreqReqTelem;
      if (recvInner) reqHz += FreqReqTelemGraph;
      else reqHz += FreqReqTelem;
      if (recvBat) reqHz += FreqReqTelemGraph;
      else reqHz += FreqReqTelem;

      if (Math.Abs((reqHz) - CurrentFreqRec) > (reqHz * 0.05)) HzRecvTelem.ForeColor = Color.Red;
      else HzRecvTelem.ForeColor = Color.Green;
      SetDronePositionOnMap(drone.gpsInfo.lat, drone.gpsInfo.lon);
      SetTelemetry();
      if (!checkBox_Graph_Live.Checked) return;

      if (checkedListBoxEngines.Items.Count == 0)
      {
        AddItemToCheckedBox(checkedListBoxEngines, "power", drone.sysInfo.engineCount);//0
        AddItemToCheckedBox(checkedListBoxEngines, "engineSpeed", drone.sysInfo.engineCount);//1
        AddItemToCheckedBox(checkedListBoxEngines, "current", drone.sysInfo.engineCount);//2
        AddItemToCheckedBox(checkedListBoxEngines, "voltage", drone.sysInfo.engineCount);//3
        AddItemToCheckedBox(checkedListBoxEngines, "tempEngine", drone.sysInfo.engineCount);//4
      }
      if (LastTimeUsec == null) LastTimeUsec = drone.Timeusec;
      if (LastTimeUsec > drone.Timeusec)
      {
        foreach (System.Windows.Forms.DataVisualization.Charting.Series s in chart_Graph.Series)
        {
          s.Points.Clear();
        }

      }

      try
      {
        DateTime tim = TIMESTART.AddMilliseconds((double)drone.Timeusec);
        double past = tim.ToOADate();
        double future = tim.AddSeconds((double)numericUpDown_Graph_Time.Value).ToOADate();
        string logData = $"timeusec:{drone.Timeusec};";
        if (CheckCheckBox(checkedListBoxGPS) || CheckCheckBox(checkedListBoxGPS2))
        {
          recvGPS = true;
          logData += GraphUpdate(checkedListBoxGPS, 0, (float)drone.gpsInfo.lat, past, future);
          logData += GraphUpdate(checkedListBoxGPS, 1, (float)drone.gpsInfo.lon, past, future);
          logData += GraphUpdate(checkedListBoxGPS, 2, (float)drone.gpsInfo.absAlt, past, future);
          logData += GraphUpdate(checkedListBoxGPS, 3, (float)drone.gpsInfo.realAlt, past, future);
          logData += GraphUpdate(checkedListBoxGPS, 4, (float)drone.gpsInfo.hdop, past, future);
          logData += GraphUpdate(checkedListBoxGPS, 5, (float)drone.gpsInfo.vdop, past, future);
          logData += GraphUpdate(checkedListBoxGPS, 6, (float)drone.gpsInfo.pdop, past, future);
          logData += GraphUpdate(checkedListBoxGPS, 7, (float)drone.gpsInfo.noise, past, future);
          logData += GraphUpdate(checkedListBoxGPS, 8, (float)drone.gpsInfo.jamming, past, future);
          logData += GraphUpdate(checkedListBoxGPS2, 0, (float)drone.gpsInfo.satVisible, past, future);
          logData += GraphUpdate(checkedListBoxGPS2, 1, (float)drone.gpsInfo.satUsed, past, future);
          logData += GraphUpdate(checkedListBoxGPS2, 2, (float)drone.gpsInfo.speed, past, future);
          logData += GraphUpdate(checkedListBoxGPS2, 3, (float)drone.gpsInfo.fixType, past, future);
          logData += GraphUpdate(checkedListBoxGPS2, 4, (float)drone.gpsInfo.timeUTC, past, future);
        }
        else recvGPS = false;
        if (CheckCheckBox(checkedListBoxSys) || CheckCheckBox(checkedListBoxEngines))
        {
          recvSys = true;
          logData += GraphUpdate(checkedListBoxSys, 0, (float)drone.sysInfo.mode, past, future);
          logData += GraphUpdate(checkedListBoxSys, 1, (float)drone.sysInfo.statusMode, past, future);
          logData += GraphUpdate(checkedListBoxSys, 2, (float)drone.sysInfo.navSys, past, future);
          logData += GraphUpdate(checkedListBoxSys, 3, (float)drone.sysInfo.engineStatus, past, future);
          logData += GraphUpdate(checkedListBoxSys, 4, (float)drone.sysInfo.engineCount, past, future);
          logData += GraphUpdate(checkedListBoxSys, 5, (float)drone.sysInfo.pressureBaro, past, future);
          logData += GraphUpdate(checkedListBoxSys, 6, (float)drone.sysInfo.tempBaro, past, future);

          double[] data = new double[drone.sysInfo.engineCount];
          for (int i = 0; i < data.Length; i++)
          {
            data[i] = drone.sysInfo.enginePower[i].power;
          }
          logData += GraphUpdate(checkedListBoxEngines, 0, data, past, future); //power
          for (int i = 0; i < data.Length; i++)
          {
            data[i] = drone.sysInfo.enginePower[i].engineSpeed;
          }
          logData += GraphUpdate(checkedListBoxEngines, 1, data, past, future); //engineSpeed
          for (int i = 0; i < data.Length; i++)
          {
            data[i] = drone.sysInfo.enginePower[i].current;
          }
          logData += GraphUpdate(checkedListBoxEngines, 2, data, past, future); //current
          for (int i = 0; i < data.Length; i++)
          {
            data[i] = drone.sysInfo.enginePower[i].voltage;
          }
          logData += GraphUpdate(checkedListBoxEngines, 3, data, past, future); //voltage
          for (int i = 0; i < data.Length; i++)
          {
            data[i] = drone.sysInfo.enginePower[i].temp;
          }
          logData += GraphUpdate(checkedListBoxEngines, 4, data, past, future); //temp
        }
        else recvSys = false;
        if (CheckCheckBox(checkedListBoxAccel))
        {
          recvAccel = true;
          logData += GraphUpdate(checkedListBoxAccel, 0, (float)drone.accelInfo.yawAccelVel, past, future);
          logData += GraphUpdate(checkedListBoxAccel, 1, (float)drone.accelInfo.pitchAccelVel, past, future);
          logData += GraphUpdate(checkedListBoxAccel, 2, (float)drone.accelInfo.rollAccelVel, past, future);
          logData += GraphUpdate(checkedListBoxAccel, 3, (float)drone.accelInfo.aX, past, future);
          logData += GraphUpdate(checkedListBoxAccel, 4, (float)drone.accelInfo.aY, past, future);
          logData += GraphUpdate(checkedListBoxAccel, 5, (float)drone.accelInfo.aZ, past, future);
          logData += GraphUpdate(checkedListBoxAccel, 6, (float)drone.accelInfo.tempAccel, past, future);
        }
        else recvAccel = false;
        if (CheckCheckBox(checkedListBoxGyro))
        {
          recvGyro = true;
          logData += GraphUpdate(checkedListBoxGyro, 0, (float)drone.gyroInfo.yawGyroVel, past, future);
          logData += GraphUpdate(checkedListBoxGyro, 1, (float)drone.gyroInfo.pitchGyroVel, past, future);
          logData += GraphUpdate(checkedListBoxGyro, 2, (float)drone.gyroInfo.rollGyroVel, past, future);
        }
        else recvGyro = false;
        if (CheckCheckBox(checkedListBoxInertial) || CheckCheckBox(checkedListBoxInertial2))
        {
          recvInner = true;
          logData += GraphUpdate(checkedListBoxInertial, 0, (float)drone.inertialInfo.x, past, future);
          logData += GraphUpdate(checkedListBoxInertial, 1, (float)drone.inertialInfo.y, past, future);
          logData += GraphUpdate(checkedListBoxInertial, 2, (float)drone.inertialInfo.z, past, future);
          logData += GraphUpdate(checkedListBoxInertial, 3, (float)drone.inertialInfo.headingDeg, past, future);
          logData += GraphUpdate(checkedListBoxInertial, 4, (float)drone.inertialInfo.speed, past, future);
          logData += GraphUpdate(checkedListBoxInertial, 5, (float)drone.inertialInfo.roll, past, future);
          logData += GraphUpdate(checkedListBoxInertial, 6, (float)drone.inertialInfo.pitch, past, future);
          logData += GraphUpdate(checkedListBoxInertial, 7, (float)drone.inertialInfo.yaw, past, future);
          logData += GraphUpdate(checkedListBoxInertial, 8, (float)drone.inertialInfo.rollVel, past, future);

          logData += GraphUpdate(checkedListBoxInertial2, 0, (float)drone.inertialInfo.pitchVel, past, future);
          logData += GraphUpdate(checkedListBoxInertial2, 1, (float)drone.inertialInfo.yawVel, past, future);
          logData += GraphUpdate(checkedListBoxInertial2, 2, (float)drone.inertialInfo.baroAlt, past, future);
        }
        else recvInner = false;
        if (CheckCheckBox(checkedListBoxBattery))
        {
          recvBat = true;
          logData += GraphUpdate(checkedListBoxBattery, 0, (float)drone.batteryInfo.perCharge, past, future);
          logData += GraphUpdate(checkedListBoxBattery, 1, (float)drone.batteryInfo.voltage, past, future);
          logData += GraphUpdate(checkedListBoxBattery, 2, (float)drone.batteryInfo.amperage, past, future);
          logData += GraphUpdate(checkedListBoxBattery, 3, (float)drone.batteryInfo.temp, past, future);
          logData += GraphUpdate(checkedListBoxBattery, 4, (float)drone.batteryInfo.totalPower, past, future);
          logData += GraphUpdate(checkedListBoxBattery, 5, (float)drone.batteryInfo.timeRemaining, past, future);
        }
        else recvBat = false;

        if (Logging && (recvAccel || recvBat || recvGPS || recvInner || recvSys || recvGyro))
        {
          using (StreamWriter writer = logFile.AppendText())
          {
            try
            {
              writer.WriteLine(logData);
            }
            catch (Exception ex)
            {
              writer.WriteLine($"Error logging.{ex.Message}");
              return;
            }
          }
        }
        ProcessingAccColibrateDataRecv();
        if (MagCharStart)
        {
          Plot3D.Graph3D.cScatter cScatter = new(drone.calibData.X, drone.calibData.Y, drone.calibData.Z, PointColor);
          MagData.Add(cScatter);
          MagSphereData.Add(new Point3D(drone.calibData.X, drone.calibData.Y, drone.calibData.Z));
          graph3d1.SetScatterPoints(MagData.ToArray(), Plot3D.Graph3D.eNormalize.Separate);
          graph3d1.Raster = Graph3D.eRaster.Labels;
        }
        if (MagSphere.calc && SphereCalculation == false)
        {
          sphereTextBox.Text = $"Sphere Radius:\r\n   X:{MagSphere.Radii.X}\r\n   Y:{MagSphere.Radii.Y}\r\n   Z:{MagSphere.Radii.Z}\r\nSphere Center:\r\n   X:{MagSphere.Center.X}\r\n   Y:{MagSphere.Center.Y}\r\n   Z:{MagSphere.Center.Z}\r\n";

        }
        if (MagFiltSphere.calc && SphereCalculation == false && !MAGSPHEREDISP)
        {
          MAGSPHEREDISP = true;
          textBox2.Text = $"Min Sphere:\r\n   X:{MagFiltSphere.Center.X - MagFiltSphere.Radii.X}\r\n   Y:{MagFiltSphere.Center.Y - MagFiltSphere.Radii.Y}\r\n   Z:{MagFiltSphere.Center.Z - MagFiltSphere.Radii.Z}\r\nMax Sphere:\r\n   X:{MagFiltSphere.Center.X + MagFiltSphere.Radii.X}\r\n   Y:{MagFiltSphere.Center.Y + MagFiltSphere.Radii.Y}\r\n   Z:{MagFiltSphere.Center.Z + MagFiltSphere.Radii.Z}\r\n";
          textBox1.Text = $"Filt Sphere Radius:\r\n   X:{MagFiltSphere.Radii.X}\r\n   Y:{MagFiltSphere.Radii.Y}\r\n   Z:{MagFiltSphere.Radii.Z}\r\nFilt Sphere Center:\r\n   X:{MagFiltSphere.Center.X}\r\n   Y:{MagFiltSphere.Center.Y}\r\n   Z:{MagFiltSphere.Center.Z}\r\n";

          if (connection == null || !connection.IsConnected) return;
          WaitRequestProcessing = true;

          byte[] commandBytes = new byte[26];
          BinaryWriter writer = new BinaryWriter(new MemoryStream(commandBytes));
          writer.Write((byte)COMMANDS_ID.SetCalibrationData);
          writer.Write((byte)(comboBoxSensors.SelectedIndex + 1));
          writer.Write((float)(MagFiltSphere.Center.X - MagFiltSphere.Radii.X));
          writer.Write((float)(MagFiltSphere.Center.X + MagFiltSphere.Radii.X));
          writer.Write((float)(MagFiltSphere.Center.Y - MagFiltSphere.Radii.Y));
          writer.Write((float)(MagFiltSphere.Center.Y + MagFiltSphere.Radii.Y));
          writer.Write((float)(MagFiltSphere.Center.Z - MagFiltSphere.Radii.Z));
          writer.Write((float)(MagFiltSphere.Center.Z + MagFiltSphere.Radii.Z));
          writer.Dispose();

          byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
          object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
          if (ackObj == null)
          {
            WaitRequestProcessing = false;
            MessageBox.Show("Error send SetMagCalibrationData. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            SendMagCalibData.Enabled = true;
            return;
          }
          MessageCommandAck ack = (MessageCommandAck)ackObj;
          if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
          {
            bool wait = true;
            while (wait && connection != null && connection.IsConnected)
            {
              byte[] payload = [(byte)COMMANDS_ID.SetCalibrationData];
              byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
              object statusObj = SendAndWait(reqStatus, typeof(MessageStatusCommand), commandBytes);
              if (statusObj == null)
              {
                wait = false;
                WaitRequestProcessing = false;
                MessageBox.Show("Error send SetMagCalibrationData. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                SendMagCalibData.Enabled = true;
                return;
              }
              MessageStatusCommand status = (MessageStatusCommand)statusObj;
              if (status.executionCode == EXEC_CODE_COMMAND.completed)
              {
                wait = false;
                MessageBox.Show($"Mag calibration data send succses.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
              }
              else if (status.executionCode == EXEC_CODE_COMMAND.error)
              {
                MessageBox.Show($"Error send SetMagCalibrationData. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                wait = false;
                WaitRequestProcessing = false;
                SendMagCalibData.Enabled = true;
                return;
              }
            }
          }
          else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
          {
            MessageBox.Show($"Error send SetMagCalibrationData. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            WaitRequestProcessing = false;
            SendMagCalibData.Enabled = true;
            return;
          }
          WaitRequestProcessing = false;
          SendMagCalibData.Enabled = false;
        }

        if (SphereCalculation)
        {
          graph3d1.SetScatterPoints(MagData.ToArray().Concat(MagSphereChartData.ToArray()).ToArray(), Plot3D.Graph3D.eNormalize.Separate);
          graph3d1.Raster = Graph3D.eRaster.Labels;
        }

        if (checkBox_Graph_Scale.Checked && !checkBox_Graph_Auto.Checked)
        {
          double min = 1000000, max = -1000000;
          foreach (System.Windows.Forms.DataVisualization.Charting.Series s in chart_Graph.Series)
          {
            foreach (System.Windows.Forms.DataVisualization.Charting.DataPoint p in s.Points)
            {
              if (p.YValues[0] > max) max = p.YValues[0];
              if (p.YValues[0] < min) min = p.YValues[0];
            }
          }

          chart_Graph.ChartAreas[0].AxisY.Maximum = Math.Truncate(max) + (double)numericUpDown_Graph_Scale.Value;
          chart_Graph.ChartAreas[0].AxisY.Minimum = Math.Truncate(min) - (double)numericUpDown_Graph_Scale.Value;
        }

        chart_Graph.ChartAreas[0].AxisX.Maximum = future;
        chart_Graph.ChartAreas[0].AxisX.Minimum = past;
      }
      catch (Exception ex) { return; }
      LastTimeUsec = drone.Timeusec;
    }
    private void ProcessingAccColibrateDataRecv()
    {
      if (ACC_COLIB_STATE is AccColibrationState.Stop || ACC_COLIB_STATE is AccColibrationState.Complete) return;
      float accX = drone.calibData.X;
      float accY = drone.calibData.Y;
      float accZ = drone.calibData.Z;
      switch (ACC_COLIB_STATE)
      {
        case AccColibrationState.PX:
          {
            if (AccPXData.Count < numericUpCountValueAcc.Value)
            {
              textBoxPluseX.Text = $"+X (Y:{Math.Round(accY, 1)}, Z:{Math.Round(accZ, 1)})";
              if (accX > 0.0f && Math.Abs(accY) < (float)numericUpDownBorderAccValue.Value && Math.Abs(accZ) < (float)numericUpDownBorderAccValue.Value)
              {
                textBoxPluseX.BackColor = Color.Yellow;
                if (AccPXData.Count == 0) AccPXData.Add(accX);
                else if (AccPXData.Last() != accX) AccPXData.Add(accX);
              }
              else textBoxPluseX.BackColor = Color.Red;

            }
            else
            {
              float accD = 0.0f;
              foreach (float a in AccPXData)
              {
                accD += a;
              }
              accD /= AccPXData.Count;
              textBoxPluseX.Text = $"+X ( {accD} )";
              CALIB_X[1] = accD;
              textBoxPluseX.BackColor = Color.LimeGreen;
              ACC_COLIB_STATE = AccColibrationState.MX;
            }
            break;
          }
        case AccColibrationState.MX:
          {
            if (AccMXData.Count < numericUpCountValueAcc.Value)
            {
              textBoxMinuseX.Text = $"-X (Y:{Math.Round(accY, 1)}, Z:{Math.Round(accZ, 1)})";
              if (accX < 0.0f && Math.Abs(accY) < (float)numericUpDownBorderAccValue.Value && Math.Abs(accZ) < (float)numericUpDownBorderAccValue.Value)
              {
                textBoxMinuseX.BackColor = Color.Yellow;
                if (AccMXData.Count == 0) AccMXData.Add(accX);
                else if (AccMXData.Last() != accX) AccMXData.Add(accX);
              }
              else textBoxMinuseX.BackColor = Color.Red;

            }
            else
            {
              float accD = 0.0f;
              foreach (float a in AccMXData)
              {
                accD += a;
              }
              accD /= AccMXData.Count;
              textBoxMinuseX.Text = $"-X ( {accD} )";
              CALIB_X[0] = accD;
              textBoxMinuseX.BackColor = Color.LimeGreen;
              ACC_COLIB_STATE = AccColibrationState.PY;
            }
            break;
          }
        case AccColibrationState.PY:
          {
            if (AccPYData.Count < numericUpCountValueAcc.Value)
            {
              textBoxPluseY.Text = $"+Y (X:{Math.Round(accX, 1)}, Z:{Math.Round(accZ, 1)})";
              if (accY > 0.0f && Math.Abs(accX) < (float)numericUpDownBorderAccValue.Value && Math.Abs(accZ) < (float)numericUpDownBorderAccValue.Value)
              {
                textBoxPluseY.BackColor = Color.Yellow;
                if (AccPYData.Count == 0) AccPYData.Add(accY);
                else if (AccPYData.Last() != accY) AccPYData.Add(accY);
              }
              else textBoxPluseY.BackColor = Color.Red;

            }
            else
            {
              float accD = 0.0f;
              foreach (float a in AccPYData)
              {
                accD += a;
              }
              accD /= AccPYData.Count;
              textBoxPluseY.Text = $"+Y ( {accD} )";
              CALIB_Y[1] = accD;
              textBoxPluseY.BackColor = Color.LimeGreen;
              ACC_COLIB_STATE = AccColibrationState.MY;
            }
            break;
          }
        case AccColibrationState.MY:
          {
            if (AccMYData.Count < numericUpCountValueAcc.Value)
            {
              textBoxMinuseY.Text = $"-Y (X:{Math.Round(accX, 1)}, Z:{Math.Round(accZ, 1)})";
              if (accY < 0.0f && Math.Abs(accX) < (float)numericUpDownBorderAccValue.Value && Math.Abs(accZ) < (float)numericUpDownBorderAccValue.Value)
              {
                textBoxMinuseY.BackColor = Color.Yellow;
                if (AccMYData.Count == 0) AccMYData.Add(accY);
                else if (AccMYData.Last() != accY) AccMYData.Add(accY);
              }
              else textBoxMinuseY.BackColor = Color.Red;

            }
            else
            {
              float accD = 0.0f;
              foreach (float a in AccMYData)
              {
                accD += a;
              }
              accD /= AccMYData.Count;
              textBoxMinuseY.Text = $"-Y ( {accD} )";
              CALIB_Y[0] = accD;
              textBoxMinuseY.BackColor = Color.LimeGreen;
              ACC_COLIB_STATE = AccColibrationState.PZ;
            }
            break;
          }
        case AccColibrationState.PZ:
          {
            if (AccPZData.Count < numericUpCountValueAcc.Value)
            {
              textBoxPluseZ.Text = $"+Z (X:{Math.Round(accX, 1)}, Y:{Math.Round(accY, 1)})";
              if (accZ > 0.0f && Math.Abs(accY) < (float)numericUpDownBorderAccValue.Value && Math.Abs(accX) < (float)numericUpDownBorderAccValue.Value)
              {
                textBoxPluseZ.BackColor = Color.Yellow;
                if (AccPZData.Count == 0) AccPZData.Add(accZ);
                else if (AccPZData.Last() != accZ) AccPZData.Add(accZ);
              }
              else textBoxPluseZ.BackColor = Color.Red;

            }
            else
            {
              float accD = 0.0f;
              foreach (float a in AccPZData)
              {
                accD += a;
              }
              accD /= AccPZData.Count;
              textBoxPluseZ.Text = $"+Z ( {accD} )";
              CALIB_Z[1] = accD;
              textBoxPluseZ.BackColor = Color.LimeGreen;
              ACC_COLIB_STATE = AccColibrationState.MZ;
            }
            break;
          }
        case AccColibrationState.MZ:
          {
            if (AccMZData.Count < numericUpCountValueAcc.Value)
            {
              textBoxMinuseZ.Text = $"-Z (X:{Math.Round(accX, 1)}, Y:{Math.Round(accY, 1)})";
              if (accZ < 0.0f && Math.Abs(accY) < (float)numericUpDownBorderAccValue.Value && Math.Abs(accX) < (float)numericUpDownBorderAccValue.Value)
              {
                textBoxMinuseZ.BackColor = Color.Yellow;
                if (AccMZData.Count == 0) AccMZData.Add(accZ);
                else if (AccMZData.Last() != accZ) AccMZData.Add(accZ);
              }
              else textBoxMinuseZ.BackColor = Color.Red;

            }
            else
            {
              float accD = 0.0f;
              foreach (float a in AccMZData)
              {
                accD += a;
              }
              accD /= AccMZData.Count;
              textBoxMinuseZ.Text = $"-Z ( {accD} )";
              CALIB_Z[0] = accD;
              textBoxMinuseZ.BackColor = Color.LimeGreen;
              ACC_COLIB_STATE = AccColibrationState.Complete;
              buttonStartAccColib.Text = "Start Acc Calibrate";
              buttonStartAccColib.BackColor = Color.Transparent;
              numericUpDownBorderAccValue.Enabled = true;
              numericUpCountValueAcc.Enabled = true;

              if (connection == null || !connection.IsConnected) return;
              WaitRequestProcessing = true;

              byte[] commandBytes = new byte[26];
              BinaryWriter writer = new BinaryWriter(new MemoryStream(commandBytes));
              writer.Write((byte)COMMANDS_ID.SetCalibrationData);
              writer.Write((byte)SENSOR_ID.ACC);
              writer.Write(CALIB_X[0]);
              writer.Write(CALIB_X[1]);
              writer.Write(CALIB_Y[0]);
              writer.Write(CALIB_Y[1]);
              writer.Write(CALIB_Z[0]);
              writer.Write(CALIB_Z[1]);
              writer.Dispose();

              byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
              object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
              if (ackObj == null)
              {
                WaitRequestProcessing = false;
                MessageBox.Show("Error send SetAccCalibrationData. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                SendAccColibData.Enabled = true;
                return;
              }
              MessageCommandAck ack = (MessageCommandAck)ackObj;
              if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
              {
                bool wait = true;
                while (wait && connection != null && connection.IsConnected)
                {
                  byte[] payload = [(byte)COMMANDS_ID.SetCalibrationData];
                  byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
                  object statusObj = SendAndWait(reqStatus, typeof(MessageStatusCommand), commandBytes);
                  if (statusObj == null)
                  {
                    WaitRequestProcessing = false;
                    wait = false;
                    MessageBox.Show("Error send SetAccCalibrationData. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    SendAccColibData.Enabled = true;
                    return;
                  }
                  MessageStatusCommand status = (MessageStatusCommand)statusObj;
                  if (status.executionCode == EXEC_CODE_COMMAND.completed)
                  {
                    wait = false;
                    MessageBox.Show($"Acc calibration data send succses.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
                  }
                  else if (status.executionCode == EXEC_CODE_COMMAND.error)
                  {
                    MessageBox.Show($"Error send SetAccCalibrationData. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    wait = false;
                    WaitRequestProcessing = false;
                    SendAccColibData.Enabled = true;
                    return;
                  }
                }
              }
              else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
              {
                MessageBox.Show($"Error send SetAccCalibrationData. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                WaitRequestProcessing = false;
                SendAccColibData.Enabled = true;
                return;
              }
              WaitRequestProcessing = false;
              SendAccColibData.Enabled = false;
            }
            break;
          }
      }
    }
    private void SetTelemetry(bool clear = false)
    {
      if (clear)
      {
        TelemStatusMode.Text = "null";
        TelemMode.Text = "null";
        TelemNavSys.Text = "null";
        TelemEngineStatus.Text = "null";
        TelemEngineStatus.ForeColor = Color.Black;
        TelemEngineCount.Text = "null";
        TelemPressureBaro.Text = "null";
        TelemTempBaro.Text = "null";
        TelemPerCharge.Text = "null";
        TelemPerCharge.ForeColor = Color.Black;
        TelemVoltageBat.Text = "null";
        TelemAmperageBat.Text = "null";
        TelemBatTemp.Text = "null";
        TelemTotalPower.Text = "null";
        TelemTimeRemBat.Text = "null";
        TelemLat.Text = "null";
        TelemLon.Text = "null";
        TelemAbsAlt.Text = "null";
        TelemRealAlt.Text = "null";
        TelemHdop.Text = "null";
        TelemVdop.Text = "null";
        TelemPdop.Text = "null";
        TelemNoise.Text = "null";
        TelemJamming.Text = "null";
        TelemSatVisible.Text = "null";
        TelemSatUsed.Text = "null";
        TelemGPSFixType.Text = "null";
        TelemTimeUTC.Text = "null";
        TelemX.Text = "null";
        TelemY.Text = "null";
        TelemZ.Text = "null";
        TelemHeadingDeg.Text = "null";
        TelemGPSspeed.Text = "null";
        TelemSpeedINS.Text = "null";
        TelemRoll.Text = "null";
        TelemPitch.Text = "null";
        TelemYaw.Text = "null";
        TelemRollVel.Text = "null";
        TelemPitchVel.Text = "null";
        TelemYawVel.Text = "null";
        TelemBaroAlt.Text = "null";
        SPDRX.Text = "0 KB/s";
        HzRecvTelem.Text = "0 Hz";
        HzRecvTelem.ForeColor = Color.Black;
        return;
      }
      if (drone.sysInfo.statusMode == STATUS_MODE.fly) TelemStatusMode.Text = "fly";
      if (drone.sysInfo.statusMode == STATUS_MODE.taking_off) TelemStatusMode.Text = "taking_off";
      if (drone.sysInfo.statusMode == STATUS_MODE.on_ground) TelemStatusMode.Text = "on_ground";
      if (drone.sysInfo.statusMode == STATUS_MODE.landing) TelemStatusMode.Text = "landing";

      if (drone.sysInfo.mode == SYS_MODE.land) TelemMode.Text = "land";
      if (drone.sysInfo.mode == SYS_MODE.take_off) TelemMode.Text = "take_off";
      if (drone.sysInfo.mode == SYS_MODE.hold) TelemMode.Text = "hold";
      if (drone.sysInfo.mode == SYS_MODE.go_home) TelemMode.Text = "go_home";
      if (drone.sysInfo.mode == SYS_MODE.auto_mode) TelemMode.Text = "auto_mode";
      if (drone.sysInfo.mode == SYS_MODE.manual) TelemMode.Text = "manual";

      if (drone.sysInfo.navSys == NAV_SYS_MODE.inertial) TelemNavSys.Text = "inertial";
      if (drone.sysInfo.navSys == NAV_SYS_MODE.gps) TelemNavSys.Text = "gps";
      if (drone.sysInfo.navSys == NAV_SYS_MODE.Optical_flow) TelemNavSys.Text = "optical_flow";

      if (drone.sysInfo.engineStatus == ENGINE_STATUS.enable)
      {
        TelemEngineStatus.Text = "on";
        TelemEngineStatus.ForeColor = Color.Green;
      }
      if (drone.sysInfo.engineStatus == ENGINE_STATUS.disable)
      {
        TelemEngineStatus.Text = "off";
        TelemEngineStatus.ForeColor = Color.Red;
      }

      TelemEngineCount.Text = drone.sysInfo.engineCount.ToString();
      TelemPressureBaro.Text = drone.sysInfo.pressureBaro.ToString();
      TelemTempBaro.Text = drone.sysInfo.tempBaro.ToString();
      TelemPerCharge.Text = drone.batteryInfo.perCharge.ToString();
      if ((int)(drone.batteryInfo.perCharge) > 80) TelemPerCharge.ForeColor = Color.Green;
      else if ((int)(drone.batteryInfo.perCharge) > 60) TelemPerCharge.ForeColor = Color.YellowGreen;
      else if ((int)(drone.batteryInfo.perCharge) > 40) TelemPerCharge.ForeColor = Color.Orange;
      else if ((int)(drone.batteryInfo.perCharge) > 20) TelemPerCharge.ForeColor = Color.OrangeRed;
      else if ((int)(drone.batteryInfo.perCharge) >= 0) TelemPerCharge.ForeColor = Color.Red;
      TelemVoltageBat.Text = drone.batteryInfo.voltage.ToString();
      TelemAmperageBat.Text = drone.batteryInfo.amperage.ToString();
      TelemBatTemp.Text = drone.batteryInfo.temp.ToString();
      TelemTotalPower.Text = drone.batteryInfo.totalPower.ToString();
      TelemTimeRemBat.Text = drone.batteryInfo.timeRemaining.ToString();
      TelemLat.Text = drone.gpsInfo.lat.ToString();
      TelemLon.Text = drone.gpsInfo.lon.ToString();
      TelemAbsAlt.Text = drone.gpsInfo.absAlt.ToString();
      TelemRealAlt.Text = drone.gpsInfo.realAlt.ToString();
      TelemHdop.Text = drone.gpsInfo.hdop.ToString();
      TelemVdop.Text = drone.gpsInfo.vdop.ToString();
      TelemPdop.Text = drone.gpsInfo.pdop.ToString();
      TelemNoise.Text = drone.gpsInfo.noise.ToString();
      TelemJamming.Text = drone.gpsInfo.jamming.ToString();
      TelemSatVisible.Text = drone.gpsInfo.satVisible.ToString();
      TelemSatUsed.Text = drone.gpsInfo.satUsed.ToString();
      TelemGPSspeed.Text = drone.gpsInfo.speed.ToString();

      if (drone.gpsInfo.fixType == GPS_FIX_TYPE.NO_GPS) TelemGPSFixType.Text = "NO_GPS";
      if (drone.gpsInfo.fixType == GPS_FIX_TYPE.NO_FIX) TelemGPSFixType.Text = "NO_FIX";
      if (drone.gpsInfo.fixType == GPS_FIX_TYPE.TWO_D_FIX) TelemGPSFixType.Text = "TWO_D_FIX";
      if (drone.gpsInfo.fixType == GPS_FIX_TYPE.THREE_D_FIX) TelemGPSFixType.Text = "THREE_D_FIX";
      if (drone.gpsInfo.fixType == GPS_FIX_TYPE.DGPS) TelemGPSFixType.Text = "DGPS";
      if (drone.gpsInfo.fixType == GPS_FIX_TYPE.RTK_FLOAT) TelemGPSFixType.Text = "RTK_FLOAT";
      if (drone.gpsInfo.fixType == GPS_FIX_TYPE.RTK_FIXED) TelemGPSFixType.Text = "RTK_FIXED";
      if (drone.gpsInfo.fixType == GPS_FIX_TYPE.STATIC) TelemGPSFixType.Text = "STATIC";
      if (drone.gpsInfo.fixType == GPS_FIX_TYPE.PPP) TelemGPSFixType.Text = "PPP";

      TelemTimeUTC.Text = drone.gpsInfo.timeUTC.ToString();

      TelemX.Text = drone.inertialInfo.x.ToString();
      TelemY.Text = drone.inertialInfo.y.ToString();
      TelemZ.Text = drone.inertialInfo.z.ToString();
      TelemHeadingDeg.Text = drone.inertialInfo.headingDeg.ToString();
      TelemSpeedINS.Text = drone.inertialInfo.speed.ToString();
      TelemRoll.Text = drone.inertialInfo.roll.ToString();
      TelemPitch.Text = drone.inertialInfo.pitch.ToString();
      TelemYaw.Text = drone.inertialInfo.yaw.ToString();
      TelemRollVel.Text = drone.inertialInfo.rollVel.ToString();
      TelemPitchVel.Text = drone.inertialInfo.pitchVel.ToString();
      TelemYawVel.Text = drone.inertialInfo.yawVel.ToString();
      TelemBaroAlt.Text = drone.inertialInfo.baroAlt.ToString();
    }
    private void numericUpDown_Freq_req_telem_ValueChanged(object sender, EventArgs e)
    {
      FreqReqTelemGraph = (int)numericUpDown_Freq_req_telem.Value;
    }
    private void checkedListBoxTelemetry_ItemCheck(object sender, ItemCheckEventArgs e)
    {
      ItemBoxCollection? item = (ItemBoxCollection?)((CheckedListBox)sender).SelectedItem;
      if (item == null) return;

      if (e.NewValue == CheckState.Unchecked)
      {
        item.check = false;
        item.ser.Points.Clear();
        chart_Graph.Series.Remove(item.ser);
      }
      else
      {
        chart_Graph.Series.Add(item.ser);
        item.check = true;
      }
    }
    private void checkedListBoxEngines_ItemCheck(object sender, ItemCheckEventArgs e)
    {
      EngineItemsBoxCollection? item = (EngineItemsBoxCollection?)((CheckedListBox)sender).SelectedItem;
      if (item == null) return;

      if (e.NewValue == CheckState.Unchecked)
      {
        item.check = false;
        for (int i = 0; i < drone.sysInfo.engineCount; i++)
        {
          item.ser[i].Points.Clear();
          chart_Graph.Series.Remove(item.ser[i]);
        }

      }
      else
      {
        for (int i = 0; i < drone.sysInfo.engineCount; i++)
        {
          chart_Graph.Series.Add(item.ser[i]);
        }
        item.check = true;
      }
    }
    private void numericUpDownFreqReqOthreTelem_ValueChanged(object sender, EventArgs e)
    {
      FreqReqTelem = (int)numericUpDownFreqReqOthreTelem.Value;
    }
    private void buttonLogging_Click(object sender, EventArgs e)
    {
      if (!Logging)
      {
        buttonLogging.BackColor = Color.LimeGreen;
        buttonLogging.Text = "Stop log";
        Logging = true;
        logFile = new FileInfo(textBoxLogFilePath.Text);
      }
      else
      {
        buttonLogging.BackColor = Color.Transparent;
        buttonLogging.Text = "Start log";
        Logging = false;
        textBoxLogFilePath.Text = Path.Combine(LogDirPath, GetLogFileName());
      }
    }
    private void CreateSettingsViewItem(ref TabPage page, ParamCatMenu param)
    {
      //bool active = false;
      //string ParamName = "Not Loaded";
      //if (param != null)
      //{
      //  string ParamName = "Unknown";
      //}
      Panel panel = new Panel();
      panel.Size = new Size(page.Width, page.Height + 20);
      panel.Dock = DockStyle.Top;
      panel.BorderStyle = BorderStyle.FixedSingle;
      panel.BackColor = Color.LightGray;
      page.Controls.Add(panel);

      bool Motor = param.param_name.StartsWith("Motor_");
      int Width = page.Width / 5;
      int Count = 2;
      if (Motor) Width = page.Width / 6;
      int Height = 30;

      Label paramName = new Label();
      paramName.Size = new Size(Width, Height);
      paramName.Location = new Point(5, 15);
      paramName.Text = param.param_name;
      paramName.Font = new Font(paramName.Font, FontStyle.Bold);
      paramName.TextAlign = ContentAlignment.MiddleCenter;
      panel.Controls.Add(paramName);

      TextBox paramValue = new TextBox();
      paramValue.Size = new Size(Width, Height);
      paramValue.Location = new Point((int)(Width) + 5, 15);
      paramValue.Text = param.param_data.ToString();
      paramValue.TextAlign = HorizontalAlignment.Center;
      paramValue.ReadOnly = true;
      paramValue.Font = new Font(paramValue.Font, FontStyle.Bold);
      paramValue.BorderStyle = BorderStyle.None;
      if (param.changed) paramValue.ForeColor = Color.Red;
      paramValue.BackColor = Color.LightGray;
      panel.Controls.Add(paramValue);

      NewTextBox newTextBox = new NewTextBox();
      newTextBox.Size = new Size(Width, Height);
      newTextBox.Location = new Point((int)(Width * Count) + 5, 15);
      newTextBox.Text = "";
      newTextBox.param_name = param.param_name;
      newTextBox.cat_id = param.cat_id;
      newTextBox.param_id = param.param_id;
      newTextBox.TextAlign = HorizontalAlignment.Center;
      newTextBox.Font = new Font(newTextBox.Font, FontStyle.Bold);
      if (param.param_type_code == DATA_TYPES.dt_char) newTextBox.KeyPress += _KeyPressChar;
      else if (param.param_type_code == DATA_TYPES.dt_float_32 || param.param_type_code == DATA_TYPES.dt_float_64) newTextBox.KeyPress += _KeyPressFloat;
      else if (param.param_type_code == DATA_TYPES.dt_bool) newTextBox.KeyPress += _KeyPressBool;
      else if (param.param_type_code != DATA_TYPES.dt_string) newTextBox.KeyPress += _KeyPressDigit;
      newTextBox.TextChanged += valueParametrsChanged;
      Count++;
      panel.Controls.Add(newTextBox);
      if (Motor)
      {
        NewButton buttonM = new NewButton();
        buttonM.Text = "Test Motor";
        buttonM.Size = new Size(Width, 40);
        buttonM.Location = new Point((int)(Width * Count) + 45, 15);
        buttonM.Click += buttonMotionTestClick;
        buttonM.Font = new Font(buttonM.Font, FontStyle.Bold);
        buttonM.BackColor = Color.FromKnownColor(KnownColor.ButtonFace);
        buttonM.FlatStyle = FlatStyle.Flat;
        Count++;
        panel.Controls.Add(buttonM);
      }

      NewButton button = new NewButton();
      button.Text = "UPDATE PARAMETER";
      button.Size = new Size(Width, 40);
      if (Motor) button.Location = new Point((int)(Width * Count) + 90, 15);
      else button.Location = new Point((int)(Width * Count) + 45, 15);
      button.Click += buttonApplySettings_Click2;
      button.Font = new Font(button.Font, FontStyle.Bold);
      button.BackColor = Color.FromKnownColor(KnownColor.ButtonFace);
      button.FlatStyle = FlatStyle.Flat;
      panel.Controls.Add(button);
      return;
    }
    private void buttonMotionTestClick(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      NewButton clickedButton = (NewButton)sender;
      Control parentControl = clickedButton.Parent;
      TextBox currentValLabel = (TextBox)parentControl.Controls[1];
      NewTextBox textBox = (NewTextBox)parentControl.Controls[2];
      ParamCatMenu param = drone.settings.categories[textBox.cat_id].parameters[textBox.param_id];

      MessageCommandMotorMoutionTest command = new MessageCommandMotorMoutionTest();
      command.commandId = COMMANDS_ID.MotorMoutionTest;
      command.motor_id = byte.Parse(currentValLabel.Text);
      byte[] commandBytes = getBytes(command);

      byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
      connection.SendData(mesReq);

      object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
      if (ackObj == null)
      {
        MessageBox.Show("Error send command motor moution test. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        textBox.Text = "";
        return;
      }
      MessageCommandAck ack = (MessageCommandAck)ackObj;
      if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
      {
        MessageBox.Show($"Send command motor moution test successfully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
      }
      else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
      {
        MessageBox.Show($"Error send command motor moution test. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      return;
    }

    private void _KeyPressFloat(object sender, KeyPressEventArgs e)
    {
      if (char.IsControl(e.KeyChar)) return;
      NewTextBox textBox = (NewTextBox)sender;
      if (!char.IsDigit(e.KeyChar) && !(e.KeyChar == ','))
      {
        e.Handled = true;
      }
      if ((e.KeyChar == ',') && textBox.Text.Contains(',')) e.Handled = true;
    }
    private void _KeyTextBoxPressFloat(object sender, KeyPressEventArgs e)
    {
      if (char.IsControl(e.KeyChar)) return;
      TextBox textBox = (TextBox)sender;
      if (!char.IsDigit(e.KeyChar) && !(e.KeyChar == ','))
      {
        e.Handled = true;
      }
      if ((e.KeyChar == ',') && textBox.Text.Contains(',')) e.Handled = true;
    }
    private void _KeyPressDigit(object sender, KeyPressEventArgs e)
    {
      if (char.IsControl(e.KeyChar)) return;
      if (!char.IsDigit(e.KeyChar))
      {
        e.Handled = true;
      }
    }
    private void _KeyPressBool(object sender, KeyPressEventArgs e)
    {
      if (char.IsControl(e.KeyChar)) return;
      NewTextBox textBox = (NewTextBox)sender;
      if (!(e.KeyChar == '0') && !(e.KeyChar == '1'))
      {
        e.Handled = true;
      }
      if (textBox.Text.Length == 1) e.Handled = true;
    }
    private void _KeyPressChar(object sender, KeyPressEventArgs e)
    {
      if (char.IsControl(e.KeyChar)) return;
      NewTextBox textBox = (NewTextBox)sender;
      if (!char.IsDigit(e.KeyChar) || (textBox.Text.Length > 4 && textBox.Text[0] != '-'))
      {
        e.Handled = true;
      }
    }
    private void valueParametrsChanged(object sender, EventArgs e)
    {
      NewTextBox box = (NewTextBox)sender;
      if (box.Text == "") return;
      bool Motor = box.param_name.StartsWith("Motor_");
      drone.settings.categories[box.cat_id].parameters[box.param_id].changed = true;
      DATA_TYPES type = drone.settings.categories[box.cat_id].parameters[box.param_id].param_type_code;
      object new_value = null;
      try
      {
        if (type == DATA_TYPES.dt_bool) new_value = Convert.ToBoolean(int.Parse(box.Text));
        else if (type == DATA_TYPES.dt_int) new_value = int.Parse(box.Text);
        else if (type == DATA_TYPES.dt_char) new_value = char.Parse(box.Text);
        else if (type == DATA_TYPES.dt_unsigned_char) new_value = byte.Parse(box.Text);
        else if (type == DATA_TYPES.dt_float_32) new_value = float.Parse(box.Text);
        else if (type == DATA_TYPES.dt_short) new_value = short.Parse(box.Text);
        else if (type == DATA_TYPES.dt_float_64) new_value = double.Parse(box.Text);
        else if (type == DATA_TYPES.dt_unsigned_short) new_value = ushort.Parse(box.Text);
        else if (type == DATA_TYPES.dt_unsigned_int) new_value = uint.Parse(box.Text);
        else if (type == DATA_TYPES.dt_long) new_value = long.Parse(box.Text);
        else if (type == DATA_TYPES.dt_long_long) new_value = Int64.Parse(box.Text);
        else if (type == DATA_TYPES.dt_unsigned_long) new_value = ulong.Parse(box.Text);
        else if (type == DATA_TYPES.dt_unsigned_long_long) new_value = UInt64.Parse(box.Text);
        else new_value = box.Text;
      }
      catch (Exception ex) { }
      ;
      if (Motor)
      {
        if ((byte)new_value >= drone.sysInfo.engineCount || (byte)new_value < 0)
        {
          box.Text = "";
          MessageBox.Show($"Error set parameter. Motor index must be >=0 and <{drone.sysInfo.engineCount}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
          return;
        }
      }
      drone.settings.categories[box.cat_id].parameters[box.param_id].new_data = new_value;
      return;
    }
    private void ReInitSettingsView()
    {
      if (drone.settings.categories == null)
      {
        return;
      }
      int indexPage = 0;
      tabControlSettingsMenu.TabPages.Clear();
      for (int j = 0; j < drone.settings.categories.Length; j++)
      {
        TabPage page = new TabPage();
        page.Size = new(tabControlSettingsMenu.Size.Width, page.Size.Height / 2);
        page.AutoScroll = true;
        page.Text = drone.settings.categories[j].name;

        Label fill = new Label();
        fill.Size = new Size(100, 30);
        fill.Dock = DockStyle.Top;

        Button button = new Button();
        button.Text = "Save all parameters";
        button.Font = new Font(this.Font, FontStyle.Bold);
        button.Click += buttonApplySettings_Click;
        button.Size = new Size(100, 50);
        button.Dock = DockStyle.Top;
        button.FlatStyle = FlatStyle.Flat;

        page.Controls.Add(fill);
        page.Controls.Add(button);
        page.Controls.Add(fill);

        for (int i = drone.settings.categories[j].parameters.Length - 1; i > -1; i--)
        {
          CreateSettingsViewItem(ref page, drone.settings.categories[j].parameters[i]);
        }

        Panel panelTitle = new Panel();
        panelTitle.BackColor = Color.White;
        panelTitle.Size = new Size(page.Width, page.Height);
        panelTitle.Dock = DockStyle.Top;
        panelTitle.Font = new Font(this.Font, FontStyle.Bold);
        panelTitle.BorderStyle = BorderStyle.FixedSingle;

        int Width = page.Width / 5;
        int Height = 30;
        Label name = new Label();
        name.Text = "Parameter name";
        name.TextAlign = ContentAlignment.MiddleCenter;
        name.Size = new Size(Width, Height);
        name.Location = new Point(5, 10);

        Label current = new Label();
        current.Text = "Current value";
        current.TextAlign = ContentAlignment.MiddleCenter;
        current.Size = new Size(Width, Height);
        current.Location = new Point((int)(Width) + 5, 10);

        Label newVal = new Label();
        newVal.Text = "New value";
        newVal.TextAlign = ContentAlignment.MiddleCenter;
        newVal.Size = new Size(Width, Height);
        newVal.Location = new Point((int)(Width * 2) + 5, 10);

        panelTitle.Controls.Add(newVal);
        panelTitle.Controls.Add(current);
        panelTitle.Controls.Add(name);
        page.Controls.Add(panelTitle);
        tabControlSettingsMenu.TabPages.Add(page);
      }
    }
    private bool UpdateSettingsView()
    {
      //ClientSize = new Size(groupBox1.Location.X + groupBox1.Width + 25, panel2.Location.Y + panel6.Height + groupBox4.Height + 50);
      if (connection == null) return false;
      ReInitSettingsView();
      return true;
    }
    private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
    {
      TabControl tab = (TabControl)sender;
      if (tab.TabPages[tab.SelectedIndex].Text == "Settings")
      {
        foreach (Control cont in tab.TabPages[tab.SelectedIndex].Controls)
        {
          cont.Enabled = false;
        }
        if (UpdateSettingsView())
        {
          foreach (Control cont in tab.TabPages[tab.SelectedIndex].Controls)
          {
            cont.Enabled = true;
          }
          WaitRequestProcessing = true;
        }
        this.Visible = true;
      }
      else
      {
        WaitRequestProcessing = false;
        //ClientSize = new Size(groupBox1.Location.X + groupBox1.Width + 25, panel2.Location.Y + panel6.Height + groupBox4.Height + 50);
        //groupBox6.Location = new Point(0, 0);
      }
    }
    private void HandlerShowProgres()
    {
      progress = new ProgressBar();
      progress.ShowDialog();
      progress = null;
    }
    private void buttonApplySettings_Click2(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      NewButton clickedButton = (NewButton)sender;
      Control parentControl = clickedButton.Parent;
      TextBox currentValLabel = (TextBox)parentControl.Controls[1];
      NewTextBox textBox = (NewTextBox)parentControl.Controls[2];
      ParamCatMenu param = drone.settings.categories[textBox.cat_id].parameters[textBox.param_id];
      if (param.changed && param.new_data != null)
      {
        MessageCommandSetParameter command = new MessageCommandSetParameter();
        command.commandId = COMMANDS_ID.SetParameter;
        command.cat_id = param.cat_id;
        command.param_id = param.param_id;
        command.param_type_code = param.param_type_code;
        command.param_len = param.param_len;
        byte[] commandBytes = getBytes(command);
        byte[] param_data = new byte[command.param_len];

        if (param.param_type_code == DATA_TYPES.dt_bool) param_data = BitConverter.GetBytes((bool)param.new_data);
        else if (param.param_type_code == DATA_TYPES.dt_int) param_data = BitConverter.GetBytes((int)param.new_data);
        else if (param.param_type_code == DATA_TYPES.dt_char) param_data = BitConverter.GetBytes((char)param.new_data);
        else if (param.param_type_code == DATA_TYPES.dt_unsigned_char) param_data[0] = (byte)param.new_data;
        else if (param.param_type_code == DATA_TYPES.dt_float_32) param_data = BitConverter.GetBytes((float)param.new_data);
        else if (param.param_type_code == DATA_TYPES.dt_short) param_data = BitConverter.GetBytes((short)param.new_data);
        else if (param.param_type_code == DATA_TYPES.dt_float_64) param_data = BitConverter.GetBytes((double)param.new_data);
        else if (param.param_type_code == DATA_TYPES.dt_unsigned_short) param_data = BitConverter.GetBytes((ushort)param.new_data);
        else if (param.param_type_code == DATA_TYPES.dt_unsigned_int) param_data = BitConverter.GetBytes((uint)param.new_data);
        else if (param.param_type_code == DATA_TYPES.dt_long) param_data = BitConverter.GetBytes((long)param.new_data);
        else if (param.param_type_code == DATA_TYPES.dt_long_long) param_data = BitConverter.GetBytes((Int64)param.new_data);
        else if (param.param_type_code == DATA_TYPES.dt_unsigned_long) param_data = BitConverter.GetBytes((ulong)param.new_data);
        else if (param.param_type_code == DATA_TYPES.dt_unsigned_long_long) param_data = BitConverter.GetBytes((UInt64)param.new_data);
        else
        {
          var d = ((string)param.new_data).ToCharArray();
          for (int id = 0; id < param.param_len; id++)
          {
            param_data[id] = (byte)d[id];
          }
        }


        byte[] payload = commandBytes.Concat(param_data).ToArray();
        byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, payload);
        connection.SendData(mesReq);
        object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
        if (ackObj == null)
        {
          MessageBox.Show("Error set parameters drone. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
          textBox.Text = "";
          return;
        }
        MessageCommandAck ack = (MessageCommandAck)ackObj;
        if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
        {
          bool wait = true;
          while (wait && connection != null && connection.IsConnected)
          {
            payload = [(byte)COMMANDS_ID.SetParameter];
            byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
            object statusObj = SendAndWait(reqStatus, typeof(MessageStatusCommand), commandBytes);
            if (statusObj == null)
            {
              MessageBox.Show("Error set parameters drone. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
              textBox.Text = "";
              return;
            }
            MessageStatusCommand status = (MessageStatusCommand)statusObj;
            if (status.executionCode == EXEC_CODE_COMMAND.completed)
            {
              wait = false;
              currentValLabel.Text = param.new_data.ToString();
              currentValLabel.ForeColor = Color.Red;
              MessageBox.Show($"{param.param_name} were installed successfully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
              drone.settings.categories[textBox.cat_id].parameters[textBox.param_id].changed = true;
              drone.settings.categories[textBox.cat_id].parameters[textBox.param_id].param_data = param.new_data;
            }
            else if (status.executionCode == EXEC_CODE_COMMAND.error)
            {
              MessageBox.Show($"Error set parameter. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
              wait = false;
            }
          }
        }
        else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
        {
          MessageBox.Show($"Error set parameter. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        textBox.Text = "";
        return;
      }
      else if (param.changed && param.new_data == null)
      {
        MessageBox.Show("Error set parameters drone. Param new data is null.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        textBox.Text = "";
        return;
      }
      else
      {
        MessageBox.Show($"The parameter: {param.param_name} has not changed", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        textBox.Text = "";
        return;
      }
    }
    private void buttonApplySettings_Click(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      WaitRequestProcessing = true;
      MessageCommandSetParameter command = new MessageCommandSetParameter();
      command.commandId = COMMANDS_ID.SetParameter;
      command.cat_id = 255;
      command.param_id = 255;
      command.param_type_code = DATA_TYPES.dt_bool;
      command.param_len = 1;
      byte[] commandBytes = getBytes(command);
      byte[] param_data = new byte[command.param_len];

      byte[] payload = commandBytes.Concat(param_data).ToArray();
      byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, payload);
      connection.SendData(mesReq);
      object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
      if (ackObj == null)
      {
        WaitRequestProcessing = false;
        MessageBox.Show("Error save parameters. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }
      MessageCommandAck ack = (MessageCommandAck)ackObj;
      if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
      {
        bool wait = true;
        while (wait && connection != null && connection.IsConnected)
        {
          payload = [(byte)COMMANDS_ID.SetParameter];
          byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
          object statusObj = SendAndWait(reqStatus, typeof(MessageStatusCommand), commandBytes);
          if (statusObj == null)
          {
            WaitRequestProcessing = false;
            MessageBox.Show("Error save parameters. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
          }
          MessageStatusCommand status = (MessageStatusCommand)statusObj;
          if (status.executionCode == EXEC_CODE_COMMAND.completed)
          {
            wait = false;
            WaitRequestProcessing = false;
            MessageBox.Show($"Saving parameters successfully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            foreach (TabPage page in tabControlSettingsMenu.TabPages)
            {
              foreach (Control panel in page.Controls)
              {
                try
                {
                  Panel p = (Panel)panel;
                  TextBox paramValue = (TextBox)p.Controls[1];
                  NewTextBox textBox = (NewTextBox)p.Controls[2];
                  paramValue.ForeColor = Color.Black;
                  drone.settings.categories[textBox.cat_id].parameters[textBox.param_id].changed = false;
                }
                catch (Exception ex) { continue; }
              }
            }
          }
          else if (status.executionCode == EXEC_CODE_COMMAND.error)
          {
            MessageBox.Show($"Error save parameters. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            wait = false;
            WaitRequestProcessing = false;
          }
        }
      }
      else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
      {
        MessageBox.Show($"Error save parameters. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        WaitRequestProcessing = false;
      }
      return;
    }
    private void SetStatusCommandLabel(string command_status, Color color, string? command_name = null)
    {
      if (command_name != null) commandLabel.Text = command_name;
      commandStatusLabel.Text = command_status;
      commandStatusLabel.ForeColor = color;
      LastTimeStatusCommandChange = GetTickCount();
      CurrentStatusCommandText = command_status;
    }
    private void SendCommandGoToLocal(float x, float y, float z, float speed)
    {
      if (connection == null || !connection.IsConnected) return;
      WaitRequestProcessing = true;

      MessageCommandGoToLocal command = new MessageCommandGoToLocal();
      command.commandId = COMMANDS_ID.GoToLocal;
      command.x = x;
      command.y = y;
      command.z = z;
      command.speed = speed;
      byte[] commandBytes = getBytes(command);
      byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
      object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
      if (ackObj == null)
      {
        WaitRequestProcessing = false;
        SetStatusCommandLabel("Error", Color.Red);
        MessageBox.Show("Error send GoToLocal. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }
      MessageCommandAck ack = (MessageCommandAck)ackObj;
      if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
      {
        bool wait = true;
        SetStatusCommandLabel("Accept", Color.Black);
        while (wait && connection != null && connection.IsConnected)
        {
          byte[] payload = [(byte)COMMANDS_ID.GoToLocal];
          byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
          object statusObj = SendAndWait(reqStatus, typeof(MessageStatusCommand), commandBytes);
          if (statusObj == null)
          {
            WaitRequestProcessing = false;
            SetStatusCommandLabel("Error", Color.Red);
            MessageBox.Show("Error send GoToLocal. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
          }
          MessageStatusCommand status = (MessageStatusCommand)statusObj;
          if (status.executionCode == EXEC_CODE_COMMAND.completed)
          {
            wait = false;
            SetStatusCommandLabel("Complete", Color.Green);
          }
          else if (status.executionCode == EXEC_CODE_COMMAND.error)
          {
            SetStatusCommandLabel("Error", Color.Red);
            MessageBox.Show($"Error send GoToLocal. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            wait = false;
          }
        }
      }
      else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
      {
        SetStatusCommandLabel("Error", Color.Red);
        MessageBox.Show($"Error send GoToLocal. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      WaitRequestProcessing = false;
    }
    private void buttonSendGoToLocal_Click(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      SetStatusCommandLabel("Processing...", Color.Black, "GoToLocal");
      SendCommandGoToLocal((float)numericUpDownX.Value, (float)numericUpDownY.Value, (float)numericUpDownZ.Value, (float)numericUpDownSpeed.Value);
    }
    private void buttonGoToGlobal_Click(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      WaitRequestProcessing = true;
      SetStatusCommandLabel("Processing...", Color.Black, "GoToGlobal");
      MessageCommandGoToGlobal command = new MessageCommandGoToGlobal();
      command.commandId = COMMANDS_ID.GoToGlobal;
      command.lat = (float)numericUpDownX.Value;
      command.lon = (float)numericUpDownY.Value;
      command.absAlt = (float)drone.NullPoint.absAlt + (float)numericUpDownZ.Value;
      command.speed = (float)numericUpDownSpeed.Value;
      byte[] commandBytes = getBytes(command);
      byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
      object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
      if (ackObj == null)
      {
        WaitRequestProcessing = false;
        SetStatusCommandLabel("Error", Color.Red);
        MessageBox.Show("Error send GoToGlobal. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }
      MessageCommandAck ack = (MessageCommandAck)ackObj;
      if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
      {
        bool wait = true;
        SetStatusCommandLabel("Accept", Color.Black);
        while (wait && connection != null && connection.IsConnected)
        {
          byte[] payload = [(byte)COMMANDS_ID.GoToGlobal];
          byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
          object statusObj = SendAndWait(reqStatus, typeof(MessageStatusCommand), commandBytes);
          if (statusObj == null)
          {
            WaitRequestProcessing = false;
            SetStatusCommandLabel("Error", Color.Red);
            MessageBox.Show("Error send GoToGlobal. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
          }
          MessageStatusCommand status = (MessageStatusCommand)statusObj;
          if (status.executionCode == EXEC_CODE_COMMAND.completed)
          {
            wait = false;
            SetStatusCommandLabel("Complete", Color.Green);
          }
          else if (status.executionCode == EXEC_CODE_COMMAND.error)
          {
            SetStatusCommandLabel("Error", Color.Red);
            MessageBox.Show($"Error send GoToGlobal. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            wait = false;
          }
        }
      }
      else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
      {
        SetStatusCommandLabel("Error", Color.Red);
        MessageBox.Show($"Error send GoToGlobal. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      WaitRequestProcessing = false;
    }
    private void buttonSendLand_Click(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      WaitRequestProcessing = true;
      SetStatusCommandLabel("Processing...", Color.Black, "Land");
      MessageCommandLand command = new MessageCommandLand();
      command.commandId = COMMANDS_ID.Land;

      byte[] commandBytes = getBytes(command);
      byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
      object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
      if (ackObj == null)
      {
        WaitRequestProcessing = false;
        SetStatusCommandLabel("Error", Color.Red);
        MessageBox.Show("Error send Land. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }
      MessageCommandAck ack = (MessageCommandAck)ackObj;
      if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
      {
        SetStatusCommandLabel("Complete", Color.Green);
        //bool wait = true;
        //while (wait && connection != null && connection.IsConnected)
        //{
        //  byte[] payload = [(byte)COMMANDS_ID.Land];
        //  byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
        //  connection.SendData(reqStatus);
        //  object statusObj = WaitAnswerMessage(typeof(MessageStatusCommand));
        //  if (statusObj == null)
        //  {
        //    WaitRequestProcessing = false;
        //    MessageBox.Show("Error send Land. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    return;
        //  }
        //  MessageStatusCommand status = (MessageStatusCommand)statusObj;
        //  if (status.executionCode == EXEC_CODE_COMMAND.completed)
        //  {
        //    wait = false;
        //  }
        //  else if (status.executionCode == EXEC_CODE_COMMAND.error)
        //  {
        //    MessageBox.Show($"Error send Land. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    wait = false;
        //  }
        //}
      }
      else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
      {
        SetStatusCommandLabel("Error", Color.Red);
        MessageBox.Show($"Error send Land. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      WaitRequestProcessing = false;
    }
    private void buttonSendGoHome_Click(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      WaitRequestProcessing = true;
      SetStatusCommandLabel("Processing...", Color.Black, "GoHome");
      MessageCommandGoHome command = new MessageCommandGoHome();
      command.commandId = COMMANDS_ID.GoHome;

      byte[] commandBytes = getBytes(command);
      byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
      object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
      if (ackObj == null)
      {
        WaitRequestProcessing = false;
        SetStatusCommandLabel("Error", Color.Red);
        MessageBox.Show("Error send GoHome. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }
      MessageCommandAck ack = (MessageCommandAck)ackObj;
      if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
      {
        SetStatusCommandLabel("Complete", Color.Green);
        //bool wait = true;
        //while (wait && connection != null && connection.IsConnected)
        //{
        //  byte[] payload = [(byte)COMMANDS_ID.GoHome];
        //  byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
        //  object statusObj = SendAndWait(reqStatus, typeof(MessageStatusCommand), commandBytes);
        //  if (statusObj == null)
        //  {
        //    WaitRequestProcessing = false;
        //    MessageBox.Show("Error send GoHome. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    return;
        //  }
        //  MessageStatusCommand status = (MessageStatusCommand)statusObj;
        //  if (status.executionCode == EXEC_CODE_COMMAND.completed)
        //  {
        //    wait = false;
        //  }
        //  else if (status.executionCode == EXEC_CODE_COMMAND.error)
        //  {
        //    MessageBox.Show($"Error send GoHome. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    wait = false;
        //  }
        //}
      }
      else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
      {
        SetStatusCommandLabel("Error", Color.Red);
        MessageBox.Show($"Error send GoHome. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      WaitRequestProcessing = false;
    }
    private void buttonChangeNav_Click(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      WaitRequestProcessing = true;
      SetStatusCommandLabel("Processing...", Color.Black, "ChangeNav");
      MessageCommandChangeNav command = new MessageCommandChangeNav();
      command.commandId = COMMANDS_ID.ChangeNav;
      if (drone.sysInfo.navSys == NAV_SYS_MODE.inertial) command.navMode = NAV_SYS_MODE.gps;
      else if (drone.sysInfo.navSys == NAV_SYS_MODE.gps) command.navMode = NAV_SYS_MODE.inertial;

      byte[] commandBytes = getBytes(command);
      byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
      object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
      if (ackObj == null)
      {
        WaitRequestProcessing = false;
        SetStatusCommandLabel("Error", Color.Red);
        MessageBox.Show("Error send ChangeNav. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }
      MessageCommandAck ack = (MessageCommandAck)ackObj;
      if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
      {
        bool wait = true;
        SetStatusCommandLabel("Accept", Color.Black);
        while (wait && connection != null && connection.IsConnected)
        {
          byte[] payload = [(byte)COMMANDS_ID.ChangeNav];
          byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
          object statusObj = SendAndWait(reqStatus, typeof(MessageStatusCommand), commandBytes);
          if (statusObj == null)
          {
            WaitRequestProcessing = false;
            SetStatusCommandLabel("Error", Color.Red);
            MessageBox.Show("Error send ChangeNav. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
          }
          MessageStatusCommand status = (MessageStatusCommand)statusObj;
          if (status.executionCode == EXEC_CODE_COMMAND.completed)
          {
            wait = false;
            SetStatusCommandLabel("Complete", Color.Green);
          }
          else if (status.executionCode == EXEC_CODE_COMMAND.error)
          {
            SetStatusCommandLabel("Error", Color.Red);
            MessageBox.Show($"Error send ChangeNav. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            wait = false;
          }
        }
      }
      else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
      {
        SetStatusCommandLabel("Error", Color.Red);
        MessageBox.Show($"Error send ChangeNav. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      WaitRequestProcessing = false;
    }
    private void buttonSendStop_Click(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      SetStatusCommandLabel("Processing...", Color.Black, "Pause");
      SendCommandGoToLocal(drone.inertialInfo.x, drone.inertialInfo.y, drone.inertialInfo.z, drone.inertialInfo.speed);
    }
    private void buttonSendSetSpeed_Click(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      WaitRequestProcessing = true;
      SetStatusCommandLabel("Processing...", Color.Black, "SetSpeed");
      MessageCommandSetSpeed command = new MessageCommandSetSpeed();
      command.commandId = COMMANDS_ID.ChangeSpeed;
      command.speed = (float)numericUpDownSpeed.Value;

      byte[] commandBytes = getBytes(command);
      byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
      object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
      if (ackObj == null)
      {
        WaitRequestProcessing = false;
        SetStatusCommandLabel("Error", Color.Red);
        MessageBox.Show("Error send ChangeSpeed. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }
      MessageCommandAck ack = (MessageCommandAck)ackObj;
      if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
      {
        bool wait = true;
        SetStatusCommandLabel("Accept", Color.Black);
        while (wait && connection != null && connection.IsConnected)
        {
          byte[] payload = [(byte)COMMANDS_ID.ChangeSpeed];
          byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
          object statusObj = SendAndWait(reqStatus, typeof(MessageStatusCommand), commandBytes);
          if (statusObj == null)
          {
            WaitRequestProcessing = false;
            SetStatusCommandLabel("Error", Color.Red);
            MessageBox.Show("Error send ChangeSpeed. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
          }
          MessageStatusCommand status = (MessageStatusCommand)statusObj;
          if (status.executionCode == EXEC_CODE_COMMAND.completed)
          {
            wait = false;
            SetStatusCommandLabel("Complete", Color.Green);
          }
          else if (status.executionCode == EXEC_CODE_COMMAND.error)
          {
            SetStatusCommandLabel("Error", Color.Red);
            MessageBox.Show($"Error send ChangeSpeed. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            wait = false;
          }
        }
      }
      else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
      {
        SetStatusCommandLabel("Error", Color.Red);
        MessageBox.Show($"Error send ChangeSpeed. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      WaitRequestProcessing = false;
    }
    private void StartMagGraph_Click(object sender, EventArgs e)
    {
      if (MagCharStart)
      {
        MagCharStart = false;
        StartMagGraph.Text = "Start storage data";
        StartMagGraph.BackColor = Color.Transparent;
        comboBoxSensors.Enabled = true;
        SendMagCalibData.Enabled = false;
        if (connection == null || !connection.IsConnected) return;
        WaitRequestProcessing = true;
        MessageCommandProcessingCalibration command = new MessageCommandProcessingCalibration();
        command.commandId = COMMANDS_ID.ProcessingCalibration;
        command.sensor_id = (SENSOR_ID)comboBoxSensors.SelectedIndex + 1;
        command.start = false;

        byte[] commandBytes = getBytes(command);
        byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
        object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
        if (ackObj == null)
        {
          WaitRequestProcessing = false;
          MessageBox.Show("Error send StopMagCalibration. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
          return;
        }
        MessageCommandAck ack = (MessageCommandAck)ackObj;
        if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
        {
          MessageBox.Show($"Error send StopMagCalibration. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        WaitRequestProcessing = false;
      }
      else
      {
        ClearMagnetData();
        StartMagGraph.Text = "Stop storage data";
        comboBoxSensors.Enabled = false;
        StartMagGraph.BackColor = Color.LimeGreen;
        MagCharStart = true;

        SendMagCalibData.Enabled = false;
        if (connection == null || !connection.IsConnected) return;
        WaitRequestProcessing = true;
        MessageCommandProcessingCalibration command = new MessageCommandProcessingCalibration();
        command.commandId = COMMANDS_ID.ProcessingCalibration;
        command.sensor_id = (SENSOR_ID)comboBoxSensors.SelectedIndex + 1;
        command.start = true;

        byte[] commandBytes = getBytes(command);
        byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
        object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
        if (ackObj == null)
        {
          WaitRequestProcessing = false;
          ClearMagnetData();
          MagCharStart = false;
          StartMagGraph.Text = "Start storage data";
          StartMagGraph.BackColor = Color.Transparent;
          comboBoxSensors.Enabled = true;
          MessageBox.Show("Error send StartMagCalibration. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
          return;
        }
        MessageCommandAck ack = (MessageCommandAck)ackObj;
        if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
        {
          ClearMagnetData();
          MagCharStart = false;
          StartMagGraph.Text = "Start storage data";
          StartMagGraph.BackColor = Color.Transparent;
          comboBoxSensors.Enabled = true;
          MessageBox.Show($"Error send StartMagCalibration. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        WaitRequestProcessing = false;
      }
    }
    public static List<Point3D> GenerateSpherePoints(Sphere sphere, int latitudeSteps, int longitudeSteps)
    {
      var points = new List<Point3D>();
      var center = sphere.Center;
      var radii = sphere.Radii;

      for (int i = 0; i <= latitudeSteps; i++)
      {
        double phi = Math.PI * i / latitudeSteps; // �������� ����
        for (int j = 0; j <= longitudeSteps; j++)
        {
          double theta = 2 * Math.PI * j / longitudeSteps; // ������������ ����

          // ������� ��� ���������� - ���������� ������ �������
          double x = center.X + radii.X * Math.Sin(phi) * Math.Cos(theta);
          double y = center.Y + radii.Y * Math.Sin(phi) * Math.Sin(theta);
          double z = center.Z + radii.Z * Math.Cos(phi);

          points.Add(new Point3D(x, y, z));
        }
      }
      return points;
    }
    private void CalculateSphere_Click(object sender, EventArgs e)
    {
      if (MagSphereData.Count > 6)
      {
        Thread t = new Thread(GetSphere);
        t.Start();
      }
      else
      {
        MagSphere.calc = false;
        MessageBox.Show($"Error calculation sphere. Number point < 6.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
    }
    private void GetSphere()
    {
      var Filter = new SphereFitter();
      Sphere calculatedSphere = Filter.Fit(MagSphereData);
      MagSphere = calculatedSphere;
      int latitudeSteps = 18; // 180 / 10 = 18
      int longitudeSteps = 36; // 360 / 10 = 36

      List<Point3D> sphereSurfacePoints = GenerateSpherePoints(calculatedSphere, latitudeSteps, longitudeSteps);

      Graph3D.cScatter center = new(calculatedSphere.Center.X, calculatedSphere.Center.Y, calculatedSphere.Center.Z, new SolidBrush(Color.LimeGreen));
      MagData.Add(center);
      SphereCalculation = true;

      Random rnd = new Random();
      HashSet<int> usedIndices = new HashSet<int>();
      while (usedIndices.Count != sphereSurfacePoints.Count)
      {
        int randomIndex = rnd.Next(sphereSurfacePoints.Count);
        if (usedIndices.Add(randomIndex))
        {
          SolidBrush PointColor = new SolidBrush(Color.Blue);
          Graph3D.cScatter point = new(sphereSurfacePoints[randomIndex].X, sphereSurfacePoints[randomIndex].Y, sphereSurfacePoints[randomIndex].Z, PointColor);
          MagSphereChartData.Add(point);
          Thread.Sleep(10);
        }
      }
      SphereCalculation = false;
    }
    private void GetFiltSphere()
    {
      List<Graph3D.cScatter> indexes = new List<Graph3D.cScatter>();
      List<Point3D> points = new List<Point3D>();
      for (int i = 0; i < MagData.Count; i++)
      {
        if (MagData[i].mi_Point3D.md_X > MagSphere.Radii.X)
        {
          points.Add(MagSphereData[i]);
          indexes.Add(MagData[i]);
        }
        if (MagData[i].mi_Point3D.md_Y > MagSphere.Radii.Y)
        {
          points.Add(MagSphereData[i]);
          indexes.Add(MagData[i]);
        }
        if (MagData[i].mi_Point3D.md_Z > MagSphere.Radii.Z)
        {
          points.Add(MagSphereData[i]);
          indexes.Add(MagData[i]);
        }
      }
      SphereCalculation = true;
      for (int i = 0; i < indexes.Count; i++)
      {
        MagData.Remove(indexes[i]);
        MagSphereData.Remove(points[i]);
        Thread.Sleep(10);
      }

      var Filter = new SphereFitter();
      Sphere calculatedSphere = Filter.Fit(MagSphereData);
      MagFiltSphere = calculatedSphere;
      int latitudeSteps = 18; // 180 / 10 = 18
      int longitudeSteps = 36; // 360 / 10 = 36

      List<Point3D> sphereSurfacePoints = GenerateSpherePoints(calculatedSphere, latitudeSteps, longitudeSteps);

      Graph3D.cScatter center = new(calculatedSphere.Center.X, calculatedSphere.Center.Y, calculatedSphere.Center.Z, new SolidBrush(Color.Orange));
      MagData.Add(center);


      Random rnd = new Random();
      HashSet<int> usedIndices = new HashSet<int>();
      while (usedIndices.Count != sphereSurfacePoints.Count)
      {
        int randomIndex = rnd.Next(sphereSurfacePoints.Count);
        if (usedIndices.Add(randomIndex))
        {
          SolidBrush PointColor = new SolidBrush(Color.HotPink);
          Graph3D.cScatter point = new(sphereSurfacePoints[randomIndex].X, sphereSurfacePoints[randomIndex].Y, sphereSurfacePoints[randomIndex].Z, PointColor);
          MagSphereChartData.Add(point);
          Thread.Sleep(10);
        }
      }
      SphereCalculation = false;
    }
    private void CalCulateFiltSphere_Click(object sender, EventArgs e)
    {
      if (MagFiltSphere.calc || !MagSphere.calc)
      {
        MessageBox.Show($"Error calculation filtered sphere. This sphere already calculated or RawSphere not calculated.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }
      else
      {
        Thread t = new Thread(GetFiltSphere);
        t.Start();
      }
    }
    private void SetLocalCoord_Click(object sender, EventArgs e)
    {
      numericUpDownX.Value = (decimal)drone.inertialInfo.x;
      numericUpDownY.Value = (decimal)drone.inertialInfo.y;
      numericUpDownZ.Value = (decimal)drone.inertialInfo.z;
    }
    private void ClearAccColibData()
    {
      AccPXData.Clear();
      AccMXData.Clear();
      AccPYData.Clear();
      AccMYData.Clear();
      AccPZData.Clear();
      AccMZData.Clear();

      buttonStartAccColib.Text = "Start Acc Calibrate";
      buttonStartAccColib.BackColor = Color.Transparent;

      textBoxPluseX.Text = "+X";
      textBoxPluseX.BackColor = Color.White;
      textBoxMinuseX.Text = "-X";
      textBoxMinuseX.BackColor = Color.White;

      textBoxPluseY.Text = "+Y";
      textBoxPluseY.BackColor = Color.White;
      textBoxMinuseY.Text = "-Y";
      textBoxMinuseY.BackColor = Color.White;

      textBoxPluseZ.Text = "+Z";
      textBoxPluseZ.BackColor = Color.White;
      textBoxMinuseZ.Text = "-Z";
      textBoxMinuseZ.BackColor = Color.White;
    }
    private void buttonStartAccColib_Click(object sender, EventArgs e)
    {
      if (ACC_COLIB_STATE is AccColibrationState.Stop || ACC_COLIB_STATE is AccColibrationState.Complete)
      {
        ClearAccColibData();
        buttonStartAccColib.Text = "Stop Acc Calibrate";
        buttonStartAccColib.BackColor = Color.LimeGreen;
        ACC_COLIB_STATE = AccColibrationState.PX;
        numericUpDownBorderAccValue.Enabled = false;
        numericUpCountValueAcc.Enabled = false;

        SendAccColibData.Enabled = false;
        if (connection == null || !connection.IsConnected) return;
        WaitRequestProcessing = true;
        MessageCommandProcessingCalibration command = new MessageCommandProcessingCalibration();
        command.commandId = COMMANDS_ID.ProcessingCalibration;
        command.sensor_id = SENSOR_ID.ACC;
        command.start = true;

        byte[] commandBytes = getBytes(command);
        byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
        object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
        if (ackObj == null)
        {
          WaitRequestProcessing = false;
          ClearAccColibData();
          ACC_COLIB_STATE = AccColibrationState.Stop;
          numericUpDownBorderAccValue.Enabled = true;
          numericUpCountValueAcc.Enabled = true;
          MessageBox.Show("Error send StartAccCalibration. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
          return;
        }
        MessageCommandAck ack = (MessageCommandAck)ackObj;
        if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
        {
          ClearAccColibData();
          ACC_COLIB_STATE = AccColibrationState.Stop;
          numericUpDownBorderAccValue.Enabled = true;
          numericUpCountValueAcc.Enabled = true;
          MessageBox.Show($"Error send StartAccCalibration. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        WaitRequestProcessing = false;
      }
      else
      {
        ClearAccColibData();
        ACC_COLIB_STATE = AccColibrationState.Stop;
        numericUpDownBorderAccValue.Enabled = true;
        numericUpCountValueAcc.Enabled = true;

        SendAccColibData.Enabled = false;
        if (connection == null || !connection.IsConnected) return;
        WaitRequestProcessing = true;
        MessageCommandProcessingCalibration command = new MessageCommandProcessingCalibration();
        command.commandId = COMMANDS_ID.ProcessingCalibration;
        command.sensor_id = SENSOR_ID.ACC;
        command.start = false;

        byte[] commandBytes = getBytes(command);
        byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
        object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
        if (ackObj == null)
        {
          WaitRequestProcessing = false;
          MessageBox.Show("Error send StoptAccCalibration. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
          return;
        }
        MessageCommandAck ack = (MessageCommandAck)ackObj;
        if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
        {
          MessageBox.Show($"Error send StoptAccCalibration. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        WaitRequestProcessing = false;
      }
    }
    private void button1_Click(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      WaitRequestProcessing = true;

      byte[] commandBytes = new byte[26];
      BinaryWriter writer = new BinaryWriter(new MemoryStream(commandBytes));
      writer.Write((byte)COMMANDS_ID.SetCalibrationData);
      writer.Write((byte)SENSOR_ID.ACC);
      writer.Write(CALIB_X[0]);
      writer.Write(CALIB_X[1]);
      writer.Write(CALIB_Y[0]);
      writer.Write(CALIB_Y[1]);
      writer.Write(CALIB_Z[0]);
      writer.Write(CALIB_Z[1]);
      writer.Dispose();

      byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
      object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
      if (ackObj == null)
      {
        WaitRequestProcessing = false;
        MessageBox.Show("Error send SetAccCalibrationData. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }
      MessageCommandAck ack = (MessageCommandAck)ackObj;
      if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
      {
        bool wait = true;
        while (wait && connection != null && connection.IsConnected)
        {
          byte[] payload = [(byte)COMMANDS_ID.SetCalibrationData];
          byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
          object statusObj = SendAndWait(reqStatus, typeof(MessageStatusCommand), commandBytes);
          if (statusObj == null)
          {
            WaitRequestProcessing = false;
            MessageBox.Show("Error send SetAccCalibrationData. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
          }
          MessageStatusCommand status = (MessageStatusCommand)statusObj;
          if (status.executionCode == EXEC_CODE_COMMAND.completed)
          {
            wait = false;
            MessageBox.Show($"Acc calibration data send succses.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
          }
          else if (status.executionCode == EXEC_CODE_COMMAND.error)
          {
            MessageBox.Show($"Error send SetAccCalibrationData. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            wait = false;
            WaitRequestProcessing = false;
            return;
          }
        }
      }
      else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
      {
        MessageBox.Show($"Error send SetAccCalibrationData. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        WaitRequestProcessing = false;
        return;
      }
      WaitRequestProcessing = false;
      SendAccColibData.Enabled = false;
    }
    private void SendMagCalibData_Click(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      WaitRequestProcessing = true;

      byte[] commandBytes = new byte[26];
      BinaryWriter writer = new BinaryWriter(new MemoryStream(commandBytes));
      writer.Write((byte)COMMANDS_ID.SetCalibrationData);
      writer.Write((byte)(comboBoxSensors.SelectedIndex + 1));
      writer.Write((float)(MagFiltSphere.Center.X - MagFiltSphere.Radii.X));
      writer.Write((float)(MagFiltSphere.Center.X + MagFiltSphere.Radii.X));
      writer.Write((float)(MagFiltSphere.Center.Y - MagFiltSphere.Radii.Y));
      writer.Write((float)(MagFiltSphere.Center.Y + MagFiltSphere.Radii.Y));
      writer.Write((float)(MagFiltSphere.Center.Z - MagFiltSphere.Radii.Z));
      writer.Write((float)(MagFiltSphere.Center.Z + MagFiltSphere.Radii.Z));
      writer.Dispose();

      byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
      object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
      if (ackObj == null)
      {
        WaitRequestProcessing = false;
        MessageBox.Show("Error send SetMagCalibrationData. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }
      MessageCommandAck ack = (MessageCommandAck)ackObj;
      if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
      {
        bool wait = true;
        while (wait && connection != null && connection.IsConnected)
        {
          byte[] payload = [(byte)COMMANDS_ID.SetCalibrationData];
          byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
          object statusObj = SendAndWait(reqStatus, typeof(MessageStatusCommand), commandBytes);
          if (statusObj == null)
          {
            WaitRequestProcessing = false;
            MessageBox.Show("Error send SetMagCalibrationData. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
          }
          MessageStatusCommand status = (MessageStatusCommand)statusObj;
          if (status.executionCode == EXEC_CODE_COMMAND.completed)
          {
            wait = false;
            MessageBox.Show($"Mag calibration data send succses.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
          }
          else if (status.executionCode == EXEC_CODE_COMMAND.error)
          {
            MessageBox.Show($"Error send SetMagCalibrationData. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            wait = false;
            WaitRequestProcessing = false;
            return;
          }
        }
      }
      else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
      {
        MessageBox.Show($"Error send SetMagCalibrationData. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        WaitRequestProcessing = false;
        return;
      }
      WaitRequestProcessing = false;
      SendMagCalibData.Enabled = false;
    }
    private void SetLevelHor_Click(object sender, EventArgs e)
    {
      if (connection == null || !connection.IsConnected) return;
      WaitRequestProcessing = true;

      byte[] commandBytes = new byte[26];
      BinaryWriter writer = new BinaryWriter(new MemoryStream(commandBytes));
      writer.Write((byte)COMMANDS_ID.SetCalibrationData);
      writer.Write((byte)SENSOR_ID.LEVEL_HOR);
      writer.Write(drone.inertialInfo.pitch);
      writer.Write(drone.inertialInfo.roll);
      writer.Write(drone.inertialInfo.yaw);
      writer.Write(0.0f);
      writer.Write(0.0f);
      writer.Write(0.0f);
      writer.Dispose();

      byte[] mesReq = CreateRequestMessage(MESSAGES_ID.Command, commandBytes);
      object ackObj = SendAndWait(mesReq, typeof(MessageCommandAck), commandBytes);
      if (ackObj == null)
      {
        WaitRequestProcessing = false;
        MessageBox.Show("Error send SetLevelHor. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }
      MessageCommandAck ack = (MessageCommandAck)ackObj;
      if (ack.status == FEASIBILITY_CODE_COMMAND.accepted)
      {
        bool wait = true;
        while (wait && connection != null && connection.IsConnected)
        {
          byte[] payload = [(byte)COMMANDS_ID.SetCalibrationData];
          byte[] reqStatus = CreateRequestMessage(MESSAGES_ID.StatusCommand, payload);
          object statusObj = SendAndWait(reqStatus, typeof(MessageStatusCommand), commandBytes);
          if (statusObj == null)
          {
            WaitRequestProcessing = false;
            MessageBox.Show("Error send SetLevelHor. Time out wait answer message.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
          }
          MessageStatusCommand status = (MessageStatusCommand)statusObj;
          if (status.executionCode == EXEC_CODE_COMMAND.completed)
          {
            wait = false;
            MessageBox.Show($"Set level hor succses.", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
          }
          else if (status.executionCode == EXEC_CODE_COMMAND.error)
          {
            MessageBox.Show($"Error send SetLevelHor. Error code: {status.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            wait = false;
            WaitRequestProcessing = false;
            return;
          }
        }
      }
      else if (ack.status == FEASIBILITY_CODE_COMMAND.cannot_be_performed)
      {
        MessageBox.Show($"Error send SetLevelHor. Error code: {ack.errorCode}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        WaitRequestProcessing = false;
        return;
      }
      WaitRequestProcessing = false;
    }
    private void TopWindow_CheckedChanged(object sender, EventArgs e)
    {
      this.TopMost = TopWindow.Checked;
    }
    private void gMapControl1_Load(object sender, EventArgs e)
    {
      GMap.NET.GMaps.Instance.Mode = GMap.NET.AccessMode.ServerAndCache; //����� ��������� ����� � ������ ��� �� ��������
      gMapControl1.MapProvider = GMap.NET.MapProviders.BingHybridMapProvider.Instance; //����� ��������� ���� ������������
      gMapControl1.MapProvider.Copyright = "";
      gMapControl1.MinZoom = 2; //����������� ���
      gMapControl1.MaxZoom = 32; //������������ ���
      gMapControl1.Zoom = 16; // ����� ������������ ��� ��� ��������
      gMapControl1.Position = new GMap.NET.PointLatLng(47.324417, 38.775671);// ����� � ������ ����� ��� ��������
      gMapControl1.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter; // ��� ���������� 

      gMapControl1.CanDragMap = true; // �������������� ����� �����
      gMapControl1.DragButton = MouseButtons.Left; // ����� ������� �������������� ��������������
      gMapControl1.ShowCenter = false; //���������� ��� �������� ������� ������� � ������
      gMapControl1.ShowTileGridLines = false; //���������� ��� �������� �����

      if (!Path.Exists(MAP_CACHE_PATH))
      {
        try
        {
          Directory.CreateDirectory(MAP_CACHE_PATH);
        }
        catch (Exception ex)
        {
          MessageBox.Show($"Error create map cache directory. {ex}", "Error create directory", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
      }
      GMapOverlay overlay = new GMapOverlay("Drone");
      gMapControl1.Overlays.Add(overlay);
      gMapControl1.CacheLocation = MAP_CACHE_PATH;
      gMapControl1.Overlays.Add(MissionPoints);
      gMapControl1.Overlays.Add(routes);
      gMapControl1.EmptyTileColor = Color.Black;
      gMapControl1.EmptyTileText = "Loading...";
      gMapControl1.FillEmptyTiles = true;
      gMapControl1.EmptyMapBackground = Color.Black;
    }
    private void SetDronePositionOnMap(double lat, double lon)
    {
      foreach (GMapOverlay overlay in gMapControl1.Overlays)
      {
        if (overlay.Id == "Drone")
        {
          if (overlay.Markers.Count != 0 && overlay.Markers[0].Position.Lat != lat && overlay.Markers[0].Position.Lng != lon)
          {
            GMapMarker marker = new GMarkerGoogle(new GMap.NET.PointLatLng(lat, lon), DRONEIMAGE);
            marker.Offset = new Point(-DRONEIMAGE.Width / 2, -DRONEIMAGE.Height / 2);
            overlay.Markers[0] = marker;
            gMapControl1.Update();
          }
          else if (overlay.Markers.Count == 0 && lat != 0.0 && lon != 0.0)
          {
            PointLatLng point = new GMap.NET.PointLatLng(lat, lon);

            GMapMarker marker = new GMarkerGoogle(point, DRONEIMAGE);
            gMapControl1.Position = point;
            gMapControl1.Zoom = 20;
            marker.Offset = new Point(-DRONEIMAGE.Width / 2, -DRONEIMAGE.Height / 2);
            overlay.Markers.Add(marker);
            gMapControl1.Update();
          }
        }
      }
    }
    private void gMapControl1_OnMapClick(GMap.NET.PointLatLng pointClick, MouseEventArgs e)
    {
      GMarkerGoogle marker = new GMarkerGoogle(pointClick, GMarkerGoogleType.orange);
      MissionPoints.Markers.Add(marker);
      SelectMarker(marker);
      RestructMissionRoute();

      NewPanel PointPanel = CreateMissionItemPanel(marker, "Point");
      PointPanel.Marker = marker;
      panel10.Controls.Add(PointPanel);
      if (panel10.Controls.Count > 1)
      {
        ((NewPanel)panel10.Controls[0]).SelectPanel = false;
        ((NewPanel)panel10.Controls[0]).Controls[0].Visible = false;
      }
      panel10.Controls.SetChildIndex(PointPanel, 0);
    }

    NewPanel CreateMissionItemPanel(GMapMarker marker, string ItemName)
    {
      Font font = new Font(new FontFamily("Times New Roman"), 10, FontStyle.Regular);
      Color LabelColor = Color.FromArgb(0, Color.Black);
      int Width = 200;

      NewPanel panel = new NewPanel();
      panel.SelectPanel = true;
      panel.AutoSize = true;
      panel.Font = font;
      panel.BackColor = Color.Transparent;
      panel.Dock = DockStyle.Top;

      Panel space = new Panel();
      space.Dock = DockStyle.Top;
      space.Size = new Size(Width, 15);

      Panel Top = new Panel();
      Top.Click += Top_Click;
      Top.Dock = DockStyle.Top;
      Top.Size = new Size(Width, 30);
      Top.Font = font;
      Top.ForeColor = Color.White;
      Top.BackColor = Color.FromArgb(255, 88, 93, 131);
      Top.Parent = panel;

      Button DeleteButton = new Button();
      DeleteButton.Text = "Del";
      DeleteButton.ForeColor = Color.Black;
      DeleteButton.BackColor = Color.Transparent;
      DeleteButton.Click += DeleteButton_Click;
      DeleteButton.Size = new Size(50, 20);
      DeleteButton.Dock = DockStyle.Left;
      DeleteButton.Font = font;

      Label Name = new Label();
      Name.Size = new Size(Width, 25);
      Name.BackColor = Color.Transparent;
      Name.Font = new Font(new FontFamily("Times New Roman"), 12, FontStyle.Bold); ;
      Name.Text = ItemName;
      Name.Dock = DockStyle.Left;
      Name.Click += Top_Click;
      Name.TextAlign = ContentAlignment.MiddleLeft;

      Top.Controls.Add(Name);
      Top.Controls.Add(DeleteButton);

      BorderedPanel Body = new BorderedPanel();
      Body.AutoSize = true;
      Body.Dock = DockStyle.Top;
      Body.BackColor = Color.FromArgb(255, Color.Black);
      Body.BorderColor = Color.FromArgb(255, 88, 93, 131);
      Body.BorderWidth = 2;
      
      Body.Font = font;
      Body.Parent = panel;

      Label AltName = new Label();
      AltName.Text = $"Alt";
      AltName.BackColor = LabelColor;
      AltName.ForeColor = Color.White;
      AltName.Dock = DockStyle.Top;
      AltName.TextAlign = ContentAlignment.MiddleLeft;
      AltName.Font = font;

      TextBox Alt = new TextBox();
      Alt.Text = "50.0";
      Alt.TextAlign = HorizontalAlignment.Left;
      Alt.Font = font;
      Alt.Dock = DockStyle.Top;

      Label LatName = new Label();
      LatName.Text = $"Lat";
      LatName.BackColor = LabelColor;
      LatName.ForeColor = Color.White;
      LatName.Dock = DockStyle.Top;
      LatName.TextAlign = ContentAlignment.MiddleLeft;
      LatName.Font = font;

      TextBox Lat = new TextBox();
      Lat.Text = marker.Position.Lat.ToString();
      Lat.TextAlign = HorizontalAlignment.Left;
      Lat.Font = font;
      Lat.Dock = DockStyle.Top;

      Label LonName = new Label();
      LonName.Text = $"Lon";
      LonName.BackColor = LabelColor;
      LonName.ForeColor = Color.White;
      LonName.Dock = DockStyle.Top;
      LonName.TextAlign = ContentAlignment.MiddleLeft;
      LonName.Font = font;

      TextBox Lon = new TextBox();
      Lon.Text = marker.Position.Lng.ToString(); ;
      Lon.TextAlign = HorizontalAlignment.Left;
      Lon.Font = font;
      Lon.Dock = DockStyle.Top;

      Panel yawPanel = new Panel();
      yawPanel.BackColor = LabelColor;
      yawPanel.Size = new Size(Width, 40);
      yawPanel.Dock = DockStyle.Top;
      yawPanel.Font = font;

      CheckBox yawCheck = new CheckBox();
      yawCheck.Dock = DockStyle.Left;
      yawCheck.BackColor = LabelColor;
      yawCheck.ForeColor = Color.White;
      yawCheck.Text = "Yaw";
      yawCheck.Font = font;
      yawCheck.CheckStateChanged += YawCheck_EnabledChanged;

      TextBox Yaw = new TextBox();
      Yaw.Dock = DockStyle.Left;
      Yaw.PlaceholderText = "-- deg";
      Yaw.Font = font;
      Yaw.Enabled = false;

      yawPanel.Controls.Add(Yaw);
      yawPanel.Controls.Add(yawCheck);

      Panel speedPanel = new Panel();
      speedPanel.BackColor = LabelColor;
      speedPanel.Dock = DockStyle.Top;
      speedPanel.Size = new Size(Width, 40);
      speedPanel.Font = font;

      CheckBox speedCheck = new CheckBox();
      speedCheck.BackColor = LabelColor;
      speedCheck.ForeColor = Color.White;
      speedCheck.Dock = DockStyle.Left;
      speedCheck.Text = "Speed";
      speedCheck.Font = font;
      speedCheck.CheckStateChanged += YawCheck_EnabledChanged;

      TextBox Speed = new TextBox();
      Speed.Dock = DockStyle.Left;
      Speed.PlaceholderText = "-- m/s";
      Speed.Font = font;
      Speed.Enabled = false;

      speedPanel.Controls.Add(Speed);
      speedPanel.Controls.Add(speedCheck);

      yawPanel.Padding = new Padding(0, 10, 0, 0);
      speedPanel.Padding = new Padding(0, 10, 0, 0);

      Body.Controls.Add(speedPanel);
      Body.Controls.Add(yawPanel);
      Body.Controls.Add(Lon);
      Body.Controls.Add(LonName);
      Body.Controls.Add(Lat);
      Body.Controls.Add(LatName);
      Body.Controls.Add(Alt);
      Body.Controls.Add(AltName);
      Body.Padding = new Padding(10, 10, 10, 10);

      panel.Controls.Add(Body);
      panel.Controls.Add(Top);
      panel.Controls.Add(space);

      return panel;
    }

    private void YawCheck_EnabledChanged(object? sender, EventArgs e)
    {
      CheckBox box = (CheckBox)sender;
      if (box.Checked)
      {
        box.Parent.Controls[0].Enabled = true;
      }
      else
      {
        box.Parent.Controls[0].Enabled = false;
      }
    }

    private void Top_Click(object? sender, EventArgs e)
    {
      GMapMarker? MarkerSelect = null;
      NewPanel? panel = null;
      Type type = sender.GetType();
      if (type == typeof(Panel)) panel = (NewPanel)(((Panel)sender).Parent);
      if (type == typeof(Label)) panel = (NewPanel)(((Label)sender).Parent.Parent);
      if (panel == null) return;
      for (int i = 0; i < MissionPoints.Markers.Count; i++)
      {
        if (MissionPoints.Markers[i].Position == panel.Marker.Position)
        {
          MarkerSelect = MissionPoints.Markers[i];
        }
      }
      if (MarkerSelect != null) SelectMarker(MarkerSelect);
    }

    private void DeleteButton_Click(object? sender, EventArgs e)
    {
      NewPanel panel = (NewPanel)((((Button)sender).Parent).Parent);
      GMapMarker marker = panel.Marker;
      
      GMapMarker? markerDelete = null;
      for (int i = 0; i < MissionPoints.Markers.Count; i ++)
      {
        if (MissionPoints.Markers[i].Position ==  marker.Position)
        {
          markerDelete = MissionPoints.Markers[i];
        }
      }
      if (markerDelete != null) MissionPoints.Markers.Remove(markerDelete);

      if (SelectedMarker != null && marker.Position == SelectedMarker.Position && MissionPoints.Markers.Count > 0) SelectMarker(MissionPoints.Markers[MissionPoints.Markers.Count - 1]);
      panel10.Controls.Remove(panel);
      RestructMissionRoute();
    }

    private void checkBox1_CheckedChanged(object sender, EventArgs e)
    {
      if (checkBox1.Checked)
      {
        gMapControl1.Visible = false;
        panel10.Visible = false;
        chart_Graph.Visible = true;
        return;
      }
      gMapControl1.Visible = true;
      panel10.Visible = true;

      chart_Graph.Visible = false;
      if (drone.gpsInfo.lat != 0.0 && drone.gpsInfo.lon != 0.0) gMapControl1.Position = new GMap.NET.PointLatLng(drone.gpsInfo.lat, drone.gpsInfo.lon);
      gMapControl1.Zoom = 16;
    }
    private void gMapControl1_KeyPress(object sender, KeyPressEventArgs e)
    {

    }

    private void RestructMissionRoute()
    {
      List<PointLatLng> points = new List<PointLatLng>();
      foreach (var point in MissionPoints.Markers)
      {
        points.Add(point.Position);
      }
      GMapRoute route = new GMapRoute(points, "Mission route");
      route.Stroke = new Pen(Color.Orange, 4);
      if (routes.Routes.Count == 0) routes.Routes.Add(route);
      else routes.Routes[0] = route;
      gMapControl1.Update();
    }

    private void gMapControl1_OnMarkerClick(GMapMarker item, MouseEventArgs e)
    {
      if (e.Button == MouseButtons.Left)
      {
        SelectMarker(item);
      }
      else if (e.Button == MouseButtons.Right)
      {
        //MissionPoints.Markers.Remove(item);
        //RestructMissionRoute();
      }
    }

    private void SelectMarker(GMapMarker Marker)
    {
      if (SelectedMarker == Marker) return;
      UnSelectMarker();
      for (int i = 0; i < panel10.Controls.Count; i++)
      {
        if (((NewPanel)panel10.Controls[i]).Marker.Position == Marker.Position)
        {
          ((NewPanel)panel10.Controls[i]).SelectPanel = true;
          ((NewPanel)panel10.Controls[i]).Controls[0].Visible = true;
          ((BorderedPanel)(((NewPanel)panel10.Controls[i]).Controls[0])).BorderColor = Color.FromArgb(255,88,93,131);
          ((NewPanel)panel10.Controls[i]).Controls[1].ForeColor = Color.White;
          ((NewPanel)panel10.Controls[i]).Controls[1].BackColor = Color.FromArgb(255, 88, 93, 131);
          ((NewPanel)panel10.Controls[i]).Controls[1].Controls[1].Visible = true;
        }
      }
      int ind = MissionPoints.Markers.IndexOf(Marker);
      MissionPoints.Markers.Remove(Marker);
      GMarkerGoogle marker = new GMarkerGoogle(Marker.Position, GMarkerGoogleType.red);
      MissionPoints.Markers.Insert(ind, marker);
      SelectedMarker = marker;
    }

    private void UnSelectMarker()
    {
      if (SelectedMarker == null) return;
      if (MissionPoints.Markers.Contains(SelectedMarker))
      {
        for (int i = 0; i < panel10.Controls.Count; i++)
        {
          if (((NewPanel)panel10.Controls[i]).Marker.Position == SelectedMarker.Position)
          {
            ((NewPanel)panel10.Controls[i]).SelectPanel = false;
            ((NewPanel)panel10.Controls[i]).Controls[0].Visible = false;
            ((BorderedPanel)(((NewPanel)panel10.Controls[i]).Controls[0])).BorderColor = Color.FromArgb(255, 0, 0, 0);
            ((NewPanel)panel10.Controls[i]).Controls[1].ForeColor = Color.DarkGray;
            ((NewPanel)panel10.Controls[i]).Controls[1].BackColor = Color.FromArgb(127, Color.Black);
            ((NewPanel)panel10.Controls[i]).Controls[1].Controls[1].Visible = false;
          }
        }

        int index = MissionPoints.Markers.IndexOf(SelectedMarker);
        MissionPoints.Markers.Remove(SelectedMarker);
        GMarkerGoogle marker1 = new GMarkerGoogle(SelectedMarker.Position, GMarkerGoogleType.orange);
        MissionPoints.Markers.Insert(index, marker1);
      }
      SelectedMarker = null;
    }

    private void gMapControl1_MouseDown(object sender, MouseEventArgs e)
    {
      if (e.Button == MouseButtons.Left && SelectedMarker != null && onMarker)
      {
        isLeftButtonDown = true;
      }
    }

    private void gMapControl1_MouseUp(object sender, MouseEventArgs e)
    {
      if (e.Button == MouseButtons.Left)
      {
        isLeftButtonDown = false;
      }
    }

    private void gMapControl1_MouseMove(object sender, MouseEventArgs e)
    {
      if (e.Button == System.Windows.Forms.MouseButtons.Left && isLeftButtonDown)
      {
        if (SelectedMarker != null)
        {
          PointLatLng point = gMapControl1.FromLocalToLatLng(e.X, e.Y);
          //��������� ��������� �������.
          int? idx = null;
          for (int i = 0; i < panel10.Controls.Count; i++)
          {
            if (((NewPanel)panel10.Controls[i]).Marker.Position == SelectedMarker.Position)
            {
              idx = i;
            }
          }
          if (idx != null) ((NewPanel)panel10.Controls[(int)idx]).Controls[0].Controls[2].Text = $"{point.Lng}";
          if (idx != null) ((NewPanel)panel10.Controls[(int)idx]).Controls[0].Controls[4].Text = $"{point.Lat}";
          SelectedMarker.Position = point;
          if (idx != null) ((NewPanel)panel10.Controls[(int)idx]).Marker = SelectedMarker;
          RestructMissionRoute();
        }
      }
    }

    private void gMapControl1_OnMarkerEnter(GMapMarker item)
    {
      if (SelectedMarker != null && SelectedMarker == item) onMarker = true;
    }

    private void gMapControl1_OnMarkerLeave(GMapMarker item)
    {
      if (SelectedMarker != null && SelectedMarker == item) onMarker = false;
    }
  }
}
